
# VR4DEAF SUCCESS PROTOCOL: INSTITUTIONAL CONTEXT (v3.5)

## 1. MISSION DEFINITION
VR4Deaf is a Vocational Rehabilitation (VR) infrastructure. 
CORE TRUTH: VR != VIRTUAL REALITY. 
VR = Institutional workforce development, state-agency coordination, and competitive integrated employment (CIE).

## 2. MACRO-ECONOMIC PARAMETERS
- Source: WHO World Report on Hearing (2021).
- Global Productivity Loss: $645 Billion USD annually.
- ROI Goal: Recover lost capital via optimized Deaf-first career pods.

## 3. POD PROTOCOL ROLES (WORKERS)
- JOB SPECIALIST: Auditor of CIE standards. Authorizes JST (Job Success Tranches).
- JOB COACH: Implementation lead. Captures 360-Proof retention data.
- BUSINESS SPECIALIST: Feasibility architect for entrepreneurship. Maps GUs to milestones.
- BUSINESS COACH: Revenue stabilizer. Monitors 90-day post-closure sustainability.
- DIRECTOR: Governance node. Final auditor for RSA-911 synchronization.

## 4. COMPUTATIONAL RULES (WASM ENGINE)
- Unit of Account: Global Unit (GU).
- 1 GU = $2.50 USD (Weighted service value).
- Milestone Validation: Must match the IPE (Individualized Plan for Employment) signature.
- Pinksync: Mandatory 100% visual accessibility for all UI/UX nodes.

## 5. VERSIONING GOVERNANCE (SEMVER 2.0.0)
- Major: Breaking protocol/API shifts.
- Minor: Feature additions (backward compatible).
- Patch: Remediation and UI fixes.
- Requirement: All bot-generated reports must reference the current Semantic Version of the Success Protocol.

## 6. BOT BEHAVIORAL GUARDRAILS
- No Hallucination: If a VR policy is unknown, request manual counselor sync.
- Data Privacy: Never output PII (Names/SSNs) in diagnostic logs.
- Technical Transparency: Provide "B-ROLL" code-level explanation for every logic shift.
