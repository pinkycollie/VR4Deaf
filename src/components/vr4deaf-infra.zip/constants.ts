
import { UserRole, AppLanguage, UrlStatus, MilestoneStatus, Client, VendorRole, ChangelogEntry, ReferralPartner, Job, Vendor } from './types';

export const EXTERNAL_INTAKE_URL = 'https://intake.vr4deaf.org';

/** 
 * VERIFIED DATA SOURCE: World Health Organization (WHO) 2021
 * Global annual loss due to unaddressed hearing loss: $980 Billion.
 * Productivity loss component: $645 Billion.
 * 
 * INFRASTRUCTURE: MBTQ Success Protocol v3.4 (Wasm Foundational)
 * ADHERENCE: Semantic Versioning 2.0.0 (SemVer)
 */
export const STATS_TRUTH = {
    GLOBAL_PRODUCTIVITY_LOSS: "$645B",
    TARGET_PLACEMENT_VELOCITY: "42 Days",
    RSA_COMPLIANCE_RATE: "98.4%",
    FEDERAL_ROI_MULTIPLIER: "1.4x",
    WASM_LOGIC_VERSION: "3.4.0",
    SEMVER_STANDARD: "2.0.0"
};

export const TRANSLATIONS: Record<AppLanguage, Record<string, string>> = {
  [AppLanguage.EN]: {
    'nav.home': 'Gateway Home',
    'hero.title': 'VOCATIONAL REHABILITATION INFRASTRUCTURE',
    'hero.subtitle': 'Authorized workforce systems for state agencies and Deaf professionals.',
    'geo.status.active': 'System Active: Authorized Provisioning',
    'cta.initiate': 'INITIALIZE CASE INTAKE',
  },
  [AppLanguage.ES]: {
    'nav.home': 'Inicio',
    'hero.title': 'INFRAESTRUCTURA DE REHABILITACIÓN VOCACIONAL',
    'hero.subtitle': 'Sistemas autorizados para agencias estatales y profesionales sordos.',
    'geo.status.active': 'Sistema Activo: Suministro Autorizado',
    'cta.initiate': 'INICIAR ADMISIÓN',
  },
  [AppLanguage.ASL]: {
    'nav.home': 'Home (Visual)',
    'hero.title': 'VOCATIONAL REHABILITATION',
    'hero.subtitle': 'Official Support Protocol.',
    'geo.status.active': 'Live: Ready',
    'cta.initiate': 'START INTAKE',
  }
};

export const PUBLIC_PAGES: UserRole[] = [
  UserRole.HOME,
  UserRole.BUSINESS_HUB,
  UserRole.JOB_PLACEMENT,
  UserRole.STORE,
  UserRole.PROTOCOL_SCHEME,
  UserRole.STATE_PROGRAMS,
  UserRole.FOUNDER_STORY,
  UserRole.WHITE_PAPER,
  UserRole.VERSION_POLICY,
  UserRole.POLICY_PULSE,
  UserRole.PROVIDER_INTEGRITY,
  UserRole.GOVERNANCE_NODE,
  UserRole.GOOGLE_DRIVE,
];

export const SERVICES_PAGES: UserRole[] = [
    UserRole.THE_PROCESS,
    UserRole.HOUSING,
    UserRole.CAREER_RESOURCES,
];

export const DASHBOARD_ROLES: UserRole[] = [
    UserRole.VR_PARTNER,
    UserRole.VR_COUNSELOR,
    UserRole.ENTREPRENEUR,
    UserRole.BUSINESS_SPECIALIST,
];

export const roleToPath = (role: UserRole): string => {
  if (role === UserRole.HOME) return '/';
  return role.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
};

const pathRoleMap = new Map<string, UserRole>();
for (const role of Object.values(UserRole)) {
    pathRoleMap.set(roleToPath(role as UserRole), role as UserRole);
}

export const pathToRole = (path: string): UserRole | undefined => {
    const cleanPath = path.startsWith('/') ? path.substring(1) : path;
    if (cleanPath === '') return UserRole.HOME;
    return pathRoleMap.get(cleanPath);
};

export const slugifyState = (state: string) => state.toLowerCase().replace(/\s+/g, '-');

export const US_STATES = [
  'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado',
  'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho',
  'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana',
  'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota',
  'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada',
  'New Hampshire', 'New Jersey', 'New Mexico', 'New York',
  'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon',
  'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota',
  'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington',
  'West Virginia', 'Wisconsin', 'Wyoming'
];

export const MOCK_CLIENTS: Client[] = [
  {
    id: 'client-9912',
    name: 'Verified Node Alpha',
    email: 'node@authorized.org',
    businessIdea: 'Technical Infrastructure Deployment.',
    vrPartnerId: 'vr-1',
    specialistId: 'bs-1',
    intakeDate: '2024-01-15',
    milestones: [],
    monitoredUrls: [{ id: 'url-1', label: 'Authorized Case Node', url: 'https://vault.vr4deaf.org', status: UrlStatus.ONLINE }]
  }
];

export const MOCK_MILESTONES_TEMPLATE = [
    { id: 'm1', title: 'RSA-911 Data Sync', description: 'Federal reporting alignment.', status: MilestoneStatus.PENDING },
    { id: 'm2', title: 'Modality Authorization', description: 'Communication tool approval.', status: MilestoneStatus.PENDING },
];

export const MOCK_CHANGELOG: ChangelogEntry[] = [
    {
        version: '3.4.0',
        date: '2024-03-25',
        changes: [
            { type: 'Protocol Update', description: 'Initialized VURI™ Wasm Core as foundational compute anchor for financial tranches.' },
            { type: 'System Enhancement', description: 'Updated GCP secret manager integrations for zero-trust API orchestration.' },
            { type: 'Logic Correction', description: 'Verified RSA-911 data hashing logic for state-level auditing.' }
        ]
    },
    {
        version: '3.3.1',
        date: '2024-02-10',
        changes: [
            { type: 'Logic Correction', description: 'Patched integer overflow in GU unit conversion for high-volume state agencies.' },
            { type: 'System Enhancement', description: 'Optimized ASL video frame processing latency by 15%.' }
        ]
    },
    {
        version: '3.3.0',
        date: '2024-01-05',
        changes: [
            { type: 'Protocol Update', description: 'Added 1619(b) Threshold monitoring for SSI/SSDI benefit protection sync.' },
            { type: 'System Enhancement', description: 'Released State-Level Node Directory for all 50 US agencies.' }
        ]
    }
];

export const ECOSYSTEM_DATA = {
    sections: [
        {
            header: "State VR Agencies",
            icon: 'map' as const,
            items: ["IPE Funding Tranches", "Unit Cost Authorization", "Case Data Sync"]
        },
        {
            header: "Private Employers",
            icon: 'briefcase' as const,
            items: ["Retention Tax Credits", "Workplace Accommodation Bundles", "Diversity Data Nodes"]
        },
        {
            header: "Philanthropic Nodes",
            icon: 'heart' as const,
            items: ["Venture Seed Grants", "Educational Scholarships", "Accessibility Pilots"]
        }
    ]
};

export const MOCK_JOBS: Job[] = [
    {
        id: 'job-1',
        title: 'Senior Software Engineer',
        company: 'InclusionTech',
        location: 'Remote',
        type: 'Full-time',
        description: 'Leading accessible UI development for state-level reporting tools.',
        url: 'https://example.com'
    },
    {
        id: 'job-2',
        title: 'ASL Content Strategist',
        company: 'Visual Connect',
        location: 'Austin, TX',
        type: 'Contract',
        description: 'Creating visual-first communication strategies for corporate environments.',
        url: 'https://example.com'
    }
];

export const MOCK_REFERRAL_PARTNERS: ReferralPartner[] = [
    {
        id: 'ref-1',
        name: 'DeafLink Specialists',
        state: 'Texas',
        contact: 'contact@deaflink.org',
        serviceCategory: 'Vocational Coaching',
        description: 'Authorized providers for ASL-native business strategy.',
        verified: true,
        tier: 'Premium'
    }
];

export const MOCK_VENDORS: Vendor[] = [
    {
        id: 'v-1',
        name: 'Success Metrics LLC',
        role: VendorRole.SPECIALIST,
        rating: 4.8,
        avgClientSuccessRate: 92,
        availability: 'Available',
        specialties: ['Data Analysis', 'RSA-911 Compliance']
    }
];
