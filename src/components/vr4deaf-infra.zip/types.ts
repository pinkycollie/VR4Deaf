
import { Session, User } from '@supabase/supabase-js';

export enum UserRole {
  HOME = 'Home',
  THE_PROCESS = 'Service Framework',
  STORE = 'Procurement',
  BUSINESS_HUB = 'Business Pod',
  AI_TOOLKITS = 'Resources',
  CHANGELOG = 'System Updates',
  API_DOCS = 'Developer Hub',
  AUTO_DEVOPS = 'Security & Ops',
  PLATFORM_ARCHITECTURE = 'Architecture',
  EMPLOYER_JOURNEY = "Employers",
  JOB_PLACEMENT = 'Career Pod',
  HOUSING = 'Housing Hub',
  LOGIN = 'Portal Login',
  SIGN_UP = 'Join Us',
  MY_ACCOUNT = 'My Profile',
  SETTINGS = 'Configuration',
  CAREER_RESOURCES = 'Learning',
  ECOSYSTEM_DIRECTORY = 'Partner Network',
  STATE_PROGRAMS = 'State Agencies',
  ECOSYSTEM = 'Eco-System',
  VR_PARTNER = 'Agency Partner',
  VR_COUNSELOR = 'Success Coach',
  ENTREPRENEUR = 'Founder',
  BUSINESS_SPECIALIST = 'Consultant',
  VENDOR_JOURNEY = "Service Provider",
  VR_COUNSELOR_JOURNEY = "Counselor Portal",
  DEVELOPER_JOURNEY = "Technical Center",
  JOURNEYS = 'Site Map',
  AI_STORE_BLUEPRINT = "Store Logic",
  FINANCIAL_SYSTEM = "Finance & GU",
  STORE_BLUEPRINT = "Blueprint",
  FOUNDER_STORY = 'Our Mission',
  BUSINESS_MAGICIAN = "Service Architects",
  COMPLIANCE_HUB = "Compliance",
  EXPANSION_VISION = "Roadmap",
  COMMAND_CENTER = "Analytics",
  WHY_HUMAN_AI = "Human-Led AI",
  WEBHOOK_CONFIG = "Integrations",
  PROTOCOL_SCHEME = "Success Manifest",
  WHITE_PAPER = "White Paper",
  MESH_GATEWAY = "Partner Gateway",
  SUCCESS_REPORT = "Outcome Report",
  VERSION_POLICY = "SemVer Standard",
  SUCCESS_LEDGER = "Success Ledger",
  POLICY_PULSE = "Policy Pulse",
  PROVIDER_INTEGRITY = "Provider Gateway",
  GOVERNANCE_NODE = "Master Node",
  GOOGLE_DRIVE = "Google Drive Hub"
}

export interface MeshTelemetry {
    totalGUCirculation: number;
    activeTrajectories: number;
    globalIntegrityScore: number;
    nodeHealth: Record<string, 'Optimal' | 'Degraded' | 'Offline'>;
}

export interface StateAnalytics {
  placementRate: number;
  engagementScore: number;
  avgVelocityDays: number;
  activeTranches: number;
  complianceRating: string;
}

export enum VR4DeafEventType {
  VR_CASE_CREATED = 'vr_case.created',
  VR_CASE_ASSIGNED = 'vr_case.assigned',
  VR_CASE_APPROVED = 'vr_case.approved',
  VR_CASE_DENIED = 'vr_case.denied',
  PROJECT_DEPLOYED = 'project.deployed',
  DOCUMENT_UPLOADED = 'document.uploaded',
  PAYMENT_PROCESSED = 'payment.processed',
  PROVIDER_REGISTERED = 'provider.registered'
}

export interface WebhookSubscription {
    id: string;
    url: string;
    events: VR4DeafEventType[];
    status: 'Active' | 'Inactive' | 'Failing';
    lastPulse: string;
    secret: string;
}

export interface WebhookEventLog {
    id: string;
    type: VR4DeafEventType;
    payload: any;
    timestamp: string;
    responseCode: number;
}

export enum AppLanguage {
  EN = 'English',
  ES = 'Español',
  ASL = 'Visual/ASL'
}

export interface GeoNode {
  lat: number;
  lng: number;
  isTexas: boolean;
  city?: string;
  status: 'active' | 'expanding' | 'convertible';
}

export enum AgencyTrack {
    DEAF_FIRST = 'Deaf-First Services',
    LGBTQIA_INCLUSIVE = 'Inclusive Career Tracks',
    GOVERNMENT_UNIVERSAL = 'Universal VR Support',
}

export enum VendorRole {
    COACH = 'Success Coach',
    SPECIALIST = 'Implementation Specialist',
    CONSULTANT = 'Strategy Consultant',
    PROVIDER = 'Service Partner',
    ASSISTIVE_TECH = 'Technology Vendor',
    EMPLOYMENT_NETWORK = 'Placement Partner',
}

export interface ComplianceAuditRecord {
    timestamp: string;
    action: string;
    nodeId: string;
    integrityHash: string;
    standard: 'RSA-911' | 'WCAG-2.2' | 'HIPAA' | 'NIST';
}

export interface ComplianceMetric {
    label: string;
    value: number | string;
    status: 'optimal' | 'warning' | 'critical';
    description: string;
    govRef?: string; // e.g., §856.53
}

export interface Vendor {
    id: string;
    name: string;
    role: VendorRole;
    rating: number; 
    avgClientSuccessRate: number; 
    availability: 'Available' | 'Limited' | 'Unavailable';
    specialties: string[];
}

export enum MilestoneStatus {
  PENDING = 'Awaiting Action',
  IN_PROGRESS = 'Active Service',
  IN_REVIEW = 'Pending Approval',
  COMPLETED = 'Goal Achieved',
  STUCK = 'Requires Attention',
}

export enum UrlStatus {
  PENDING = 'Syncing',
  ONLINE = 'Active',
  OFFLINE = 'Inactive',
}

export interface WeeklyBriefing {
  highlights: string[];
  suggestions: string[];
  attentionItems: {
    clientId: string;
    clientName: string;
    reason: string;
  }[];
}

export interface LearningResource {
    id: string;
    title: string;
    topic: string;
}

export interface Job {
    id: string;
    title: string;
    company: string;
    location: string;
    type: 'Full-time' | 'Part-time' | 'Contract' | 'Remote';
    description: string;
    url: string;
}

export interface ChangelogEntry {
    version: string;
    date: string;
    changes: {
        type: 'Protocol Update' | 'System Enhancement' | 'Logic Correction';
        description: string;
    }[];
}

export interface ReferralPartner {
    id: string;
    name: string;
    state: string;
    contact: string;
    serviceCategory: string;
    description: string;
    verified: boolean;
    tier?: 'Premium' | 'Verified';
}

export enum ClientDashboardMode {
  JOB_SEEKER = 'Employment',
  BUSINESS_OWNER = 'Entrepreneurship',
  NEW_VENTURE = 'Strategy',
}

export interface DigitalTwin {
    persona: string;
    tone: string;
    trajectorySummary: string;
    predictedObstacles: string[];
    recommendedModality: string;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  businessIdea: string;
  vrPartnerId: string;
  specialistId: string;
  intakeDate: string;
  monitoredUrls?: MonitoredUrl[];
  milestones: Milestone[];
  equipmentOrders?: EquipmentOrder[];
  digitalTwin?: DigitalTwin;
}

export interface MonitoredUrl {
  id: string;
  label: string;
  url: string;
  status: UrlStatus;
}

export interface Milestone {
  id: string;
  title: string;
  description: string;
  status: MilestoneStatus;
}

export interface EquipmentOrder {
    id: string;
    itemName: string;
    status: 'Queued' | 'Authorized' | 'En Route' | 'Deployed';
    date: string;
}

export interface AuthenticatedUser {
    uid: string;
    email: string;
    displayName: string;
    primaryRole: UserRole.VR_PARTNER | UserRole.ENTREPRENEUR | UserRole.BUSINESS_SPECIALIST | UserRole.VR_COUNSELOR;
    vendorRole?: VendorRole;
}

export interface VuriAdvice {
    summary: string;
    actions: { label: string; priority: 'low' | 'medium' | 'high' }[];
    insight: string;
}

export interface AgencyOutcome {
    projectedSuccess: string;
    riskLevel: 'Low' | 'Medium' | 'High';
    bottlenecks: string[];
    recommendations: string[];
}

export interface StateDetails {
    programName: string;
    description: string;
    contactInfo: {
        phone: string;
        email: string;
        website: string;
        officeAddress: string;
    };
    successStories: {
        title: string;
        story: string;
        outcome: string;
    }[];
}
