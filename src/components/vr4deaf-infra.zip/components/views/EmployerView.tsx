
import React from 'react';
import { Icon, IconName } from '../ui/Icon';
import { UserRole } from '../../types';
import { roleToPath, EXTERNAL_INTAKE_URL } from '../../constants';

interface EmployerViewProps {
  navigate: (path: string) => void;
}

const IntegrationNode = ({ icon, title, description }: { icon: IconName, title: string, description: string }) => (
    <div className="group bg-brand-primary/20 backdrop-blur-3xl p-10 rounded-[3rem] border border-white/5 hover:border-brand-accent/30 transition-all flex flex-col h-full">
        <div className="p-4 bg-white/5 rounded-3xl w-fit mb-8 group-hover:bg-brand-accent group-hover:text-brand-dark transition-all duration-500">
            <Icon name={icon} className="w-10 h-10" />
        </div>
        <h3 className="text-2xl font-black text-white uppercase tracking-tighter mb-4 leading-none">{title}</h3>
        <p className="text-brand-muted text-sm font-medium leading-relaxed flex-grow">{description}</p>
    </div>
);

export const EmployerView: React.FC<EmployerViewProps> = ({ navigate }) => {
  return (
    <div className="bg-[#020617] min-h-screen text-brand-light pb-20">
      <header className="relative h-[35vh] min-h-[300px] overflow-hidden flex items-center justify-center border-b border-white/5">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#020617] z-10"></div>
          <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=2069&auto=format&fit=crop')] bg-cover"></div>
        </div>
        <div className="relative z-20 text-center px-6">
           <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-accent/5 border border-brand-accent/20 text-brand-accent text-[10px] font-black uppercase tracking-[0.4em] mb-4">
              <Icon name="users" className="w-3 h-3" />
              Corporate Integration Portal
           </div>
           <h1 className="text-4xl md:text-6xl font-black text-white tracking-tighter uppercase leading-none">Inclusion <span className="text-brand-accent">Infrastructure</span></h1>
        </div>
      </header>

      <div className="max-w-[1400px] mx-auto px-6 -mt-16 relative z-30">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <IntegrationNode 
                icon="specialist"
                title="Node Integration"
                description="Secure uplink to a vetted pool of Deaf and Hard-of-Hearing professionals. Synchronize inclusive job roles across the network."
            />
            <IntegrationNode 
                icon="shield-check"
                title="Compliance Vault"
                description="Automated reporting for diversity benchmarks. Every placement verified by RSA-911 and CIE standards."
            />
            <IntegrationNode 
                icon="link"
                title="Strategic Ally Node"
                description="Join the multi-agency network. Fund specific workforce trajectories and receive high-integrity talent data."
            />
        </div>

        <section className="mt-24 p-12 bg-brand-primary/40 backdrop-blur-xl border border-brand-accent/20 rounded-[4rem] text-center shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 p-12 opacity-5">
                <Icon name="chart-bar" className="w-60 h-60 text-brand-accent" />
            </div>
            <div className="relative z-10">
                <h2 className="text-4xl font-black text-white uppercase tracking-tighter mb-6"> Generational Workforce Standards</h2>
                <p className="text-brand-muted max-w-3xl mx-auto text-lg font-medium leading-relaxed mb-12">
                    We've solved the communication barrier by building the infrastructure first. Corporate partners receive pre-vetted nodes ready for integration into competitive integrated environments.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-left">
                    {[
                        { label: 'Integrity', icon: 'shield-check', desc: 'Verified communication modalities.' },
                        { label: 'Retention', icon: 'heart', desc: '90-day trajectory monitoring.' },
                        { label: 'ROI Path', icon: 'currency-dollar', desc: 'Automated tax credit reporting.' },
                        { label: 'Speed', icon: 'rocket-launch', desc: 'Zero-friction uplink to talent.' }
                    ].map((item, i) => (
                        <div key={i} className="p-6 bg-brand-dark/50 rounded-3xl border border-white/5">
                            <Icon name={item.icon as any} className="w-8 h-8 text-brand-accent mb-4" />
                            <h4 className="text-sm font-black text-white uppercase tracking-widest mb-1">{item.label}</h4>
                            <p className="text-[11px] text-brand-muted uppercase tracking-wider">{item.desc}</p>
                        </div>
                    ))}
                </div>
                <a 
                    href={EXTERNAL_INTAKE_URL}
                    className="inline-block mt-16 bg-brand-accent text-brand-dark font-black py-5 px-12 rounded-2xl uppercase tracking-widest hover:scale-105 transition-all shadow-glow-cyan"
                >
                    Initiate Corporate Uplink
                </a>
            </div>
        </section>
      </div>
    </div>
  );
};
