
import React, { ReactNode } from 'react';
import { Icon, IconName } from '../ui/Icon';
import { UserRole } from '../../types';
import { roleToPath } from '../../constants';

const ProcurementNode: React.FC<{ title: string; icon: IconName; children: ReactNode; accent?: boolean }> = ({ title, icon, children, accent = false }) => (
    <div className={`group relative p-10 rounded-[3rem] border transition-all flex flex-col w-full ${accent ? 'bg-brand-accent/5 border-brand-accent/30 shadow-glow-cyan' : 'bg-brand-primary/20 border-white/5 hover:border-white/10'}`}>
        <div className="flex items-center gap-5 mb-8">
            <div className={`p-4 rounded-2xl ring-1 transition-all group-hover:rotate-12 ${accent ? 'bg-brand-accent text-brand-dark ring-brand-accent/50' : 'bg-white/5 text-brand-accent ring-white/10'}`}>
                 <Icon name={icon} className="w-10 h-10" />
            </div>
            <div>
                <h3 className="text-3xl font-black text-white uppercase tracking-tighter leading-none">{title}</h3>
                <span className="text-[10px] font-black text-brand-muted uppercase tracking-[0.3em]">Protocol Integration Point</span>
            </div>
        </div>
        <div className="text-brand-muted space-y-4 text-sm font-medium leading-relaxed">{children}</div>
    </div>
);

const NeuralConnector: React.FC<{ label?: string }> = ({ label }) => (
    <div className="flex flex-col items-center py-6">
        <div className="w-px h-16 bg-gradient-to-b from-brand-accent/50 to-transparent"></div>
        {label && <span className="my-2 text-[10px] font-black text-brand-accent uppercase tracking-widest px-3 py-1 bg-brand-accent/10 border border-brand-accent/20 rounded-full">{label}</span>}
        <div className="w-px h-16 bg-gradient-to-t from-brand-accent/50 to-transparent"></div>
    </div>
);

interface StoreViewProps {
    navigate: (path: string) => void;
}

const StoreView: React.FC<StoreViewProps> = ({ navigate }) => {
    return (
        <div className="bg-[#020617] min-h-screen text-brand-light pb-20">
            <header className="relative h-[40vh] min-h-[300px] overflow-hidden flex items-center justify-center border-b border-white/5">
                <div className="absolute inset-0 z-0">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#020617] z-10"></div>
                    <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1557804506-669a67965ba0?q=80&w=2074&auto=format&fit=crop')] bg-cover grayscale"></div>
                    <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:50px_50px]"></div>
                </div>
                <div className="relative z-20 text-center px-6">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-accent/5 border border-brand-accent/20 text-brand-accent text-[10px] font-black uppercase tracking-[0.4em] mb-6">
                        <Icon name="shopping-cart" className="w-3 h-3" />
                        Procurement Protocol v1.4
                    </div>
                    <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter uppercase leading-none">The Store <br/><span className="text-brand-accent">Blueprint</span></h1>
                </div>
            </header>

            <div className="max-w-5xl mx-auto px-6 -mt-20 relative z-30 space-y-4">
                <ProcurementNode title="Node Identity Layer" icon="user">
                    <p>The entry point for every user. Authentication via DeafAUTH verifies the profile and pulls authorized IPE requirements directly into the marketplace dashboard.</p>
                </ProcurementNode>

                <NeuralConnector label="Initialize Selection" />

                <ProcurementNode title="AI Funding Engine" icon="cpu-chip" accent>
                    <p><strong>Neural Eligibility:</strong> VURI™ instantly cross-references the shopping cart against multi-source funding tranches (VR, Employer, Grants).</p>
                    <p><strong>Unit Conversion:</strong> Costs are converted to Generative Units (GU), ensuring 1:1 value parity across all 50 state nodes.</p>
                </ProcurementNode>

                <NeuralConnector label="Authorization Loop" />

                <div className="grid md:grid-cols-2 gap-8">
                     <ProcurementNode title="Logistics Node" icon="server-stack">
                        <p>Automated deployment of hardware and digital access keys. Every order is tracked via a blockchain-verified delivery path to the client's home or office.</p>
                    </ProcurementNode>
                     <ProcurementNode title="Compliance Audit" icon="clipboard-list">
                        <p>Real-time data streams update the TWC/RSA reporting vault. One-click justification for every allocated unit of capital.</p>
                    </ProcurementNode>
                </div>
            </div>
            
            <section className="mt-32 px-6">
                <div className="max-w-5xl mx-auto text-center bg-brand-primary/40 backdrop-blur-3xl rounded-[4rem] p-16 border border-brand-accent/30 shadow-glow-cyan relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-12 opacity-5">
                         <Icon name="rocket-launch" className="w-64 h-64 text-brand-accent" />
                    </div>
                    <h2 className="text-4xl font-black text-white uppercase tracking-tighter mb-6 leading-none">Ready to <span className="text-brand-accent">Uplink?</span></h2>
                     <p className="text-brand-muted mb-12 max-w-2xl mx-auto text-lg font-medium leading-relaxed">
                        The live procurement hub is active for verified nodes. Initialize your pathway or explore the technical build logic.
                    </p>
                    <div className="flex flex-col sm:flex-row justify-center items-center gap-6">
                        <button onClick={() => window.open('https://store.vr4deaf.org', '_blank')} className="w-full sm:w-auto bg-white text-brand-dark font-black py-5 px-12 rounded-2xl uppercase text-xs tracking-widest hover:scale-105 transition-all shadow-2xl">
                            Procure Resources
                        </button>
                         <button onClick={() => navigate(roleToPath(UserRole.AI_STORE_BLUEPRINT))} className="w-full sm:w-auto bg-brand-primary/60 border border-brand-accent/50 text-brand-accent font-black py-5 px-12 rounded-2xl uppercase text-xs tracking-widest hover:bg-brand-accent hover:text-brand-dark transition-all">
                            View AI Logic
                        </button>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default StoreView;
