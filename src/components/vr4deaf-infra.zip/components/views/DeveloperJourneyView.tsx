
import React, { useEffect } from 'react';
import { Icon, IconName } from '../ui/Icon';
import { UserRole } from '../../types';
import { roleToPath } from '../../constants';
import mermaid from 'mermaid';

interface DeveloperJourneyViewProps {
  navigate: (path: string) => void;
}

const DocCard: React.FC<{ icon: IconName, title: string, description: string, role: UserRole, navigate: (path: string) => void }> = ({ icon, title, description, role, navigate }) => (
    <button
        onClick={() => navigate(roleToPath(role))}
        className="group text-left p-8 bg-brand-primary/50 backdrop-blur-md rounded-2xl border-2 border-brand-secondary hover:border-brand-accent transition-all transform hover:-translate-y-1 w-full h-full flex flex-col"
    >
        <Icon name={icon} className="w-12 h-12 text-brand-accent mb-4 transition-transform group-hover:scale-110" />
        <h3 className="text-2xl font-bold text-white">{title}</h3>
        <p className="text-brand-muted mt-2 flex-grow">{description}</p>
        <span className="mt-4 text-sm font-semibold text-brand-accent group-hover:underline">View Documentation &rarr;</span>
    </button>
);


const DeveloperJourneyView: React.FC<DeveloperJourneyViewProps> = ({ navigate }) => {
    
    const resources = [
        {
            icon: 'server-stack' as const,
            title: "Platform Architecture",
            description: "Get a high-level overview of our end-to-end system, from the frontend to our backend services and AI integrations.",
            role: UserRole.PLATFORM_ARCHITECTURE,
        },
        {
            icon: 'currency-dollar' as const,
            title: "Financial System",
            description: "Understand our milestone-driven funding model, from the AI-governed treasury to the client's stable credit wallet.",
            role: UserRole.FINANCIAL_SYSTEM,
        },
        {
            icon: 'code-bracket' as const,
            title: "API & Docs",
            description: "Explore our headless API endpoints, authentication methods, and example requests to start building integrations.",
            role: UserRole.API_DOCS,
        },
        {
            icon: 'cog' as const,
            title: "Automated DevOps",
            description: "Learn about our CI/CD pipeline, automated testing, security scanning, and containerized deployment strategy.",
            role: UserRole.AUTO_DEVOPS,
        },
        {
            icon: 'list-bullet' as const,
            title: "Changelog",
            description: "Track our progress and see detailed release notes for every version of the platform.",
            role: UserRole.CHANGELOG,
        },
        {
            icon: 'clipboard-list' as const,
            title: "AI Store Blueprint",
            description: "A developer's guide to building the VR4Deaf Store, complete with AI-powered insights and code examples.",
            role: UserRole.AI_STORE_BLUEPRINT,
        },
    ];

    const masterBlueprintDiagram = `
graph TD
    subgraph Actors
        direction LR
        User[/"👤<br/>Deaf Client, Founder, Professional"/]
        Partner[/"🤝<br/>VR Counselor, Vendor, Employer"/]
    end

    subgraph VR4Deaf_Platform [VR4Deaf Platform]
        direction TB
        subgraph VURI_Core [VURI™ AI Core]
             VURI("🧠 VURI™ Master AI")
        end

        subgraph Vertical_AI [Vertical AI Co-Pilots]
            direction LR
            BizAI(Business AI)
            JobAI(Job Seeker AI)
            SkillAI(Upskilling AI)
            CreativeAI(Freelance AI)
        end

        Store_Services("🛒 Store & Services Hub<br/>(Equipment, Labor, Biz Setup, Tax, etc.)")

        VURI --> Vertical_AI
        Vertical_AI -- "Recommends" --> Store_Services
    end

    subgraph MBTQ_Modules [MBTQ.dev Foundational Modules]
        direction TB
        DeafAuth("🔐 DeafAUTH<br/>Central Memory, Files & Identity")
        PinkSync("👁️ PinkSync<br/>Accessibility Engine")
        Fibonrose("📜 Fibonrose<br/>Trust & Ethics AI")
        Magicians("🔮 360Magicians<br/>Business/Job Logic Engine")
    end

    subgraph Funding_Layer [Funding Layer]
        direction TB
        DAO("🏦 DAO Funding<br/>Decentralized Treasury")
        Traditional_Funders("💼 Traditional Funders<br/>(State VR, Employers, Grants)")
    end

    %% Connections
    User -- "Interacts with" --> Store_Services
    Partner -- "Manages through" --> Store_Services

    Store_Services -- "User Action" --> VURI
    VURI -- "Queries User Data & History" --> DeafAuth
    VURI -- "Governed by" --> Fibonrose
    VURI -- "Executes Logic via" --> Magicians

    Store_Services -- "Requests Funds" --> DAO
    Store_Services -- "Requests Funds" --> Traditional_Funders
    DAO -- "Funds" --> Store_Services
    Traditional_Funders -- "Funds" --> Store_Services

    Store_Services -- "Verifies Identity & Eligibility via" --> DeafAuth

    VR4Deaf_Platform -- "Secured by" --> DeafAuth
    VR4Deaf_Platform -- "Made Accessible by" --> PinkSync

    %% Styling
    classDef actors fill:#00B8D4,stroke:#E0F7FA,stroke-width:2px,color:#0D1A2E,fontWeight:bold
    classDef platform fill:#1A2C47,stroke:#00B8D4,stroke-width:2px,color:#E0F7FA
    classDef modules fill:#0D1A2E,stroke:#96B3D9,stroke-width:2px,color:#E0F7FA
    classDef funding fill:#2A3F5E,stroke:#96B3D9,stroke-width:1px,color:#E0F7FA

    class User,Partner actors
    class VR4Deaf_Platform,VURI_Core,Vertical_AI,Store_Services platform
    class MBTQ_Modules,DeafAuth,PinkSync,Fibonrose,Magicians modules
    class Funding_Layer,DAO,Traditional_Funders funding
    `;

    useEffect(() => {
        mermaid.initialize({
            startOnLoad: false,
            theme: 'base',
            fontFamily: 'Inter, sans-serif',
            themeVariables: {
                background: '#1A2C47',
                primaryColor: '#0D1A2E',
                primaryTextColor: '#E0F7FA',
                primaryBorderColor: '#00B8D4',
                lineColor: '#96B3D9',
                secondaryColor: '#2A3F5E',
                tertiaryColor: '#1A2C47',
                fontSize: '14px',
                clusterBkg: '#0D1A2E90',
                clusterBorder: '#96B3D9',
                edgeLabelBackground: '#1A2C47',
                nodeBorder: '#00B8D4',
            }
        });
        mermaid.run();
    }, []);
    
    return (
        <div className="bg-brand-dark">
            {/* Hero Section */}
            <section className="bg-brand-primary/50 text-white py-16 px-4 text-center rounded-b-2xl">
                <div className="w-16 h-16 mx-auto mb-4 bg-brand-accent/10 rounded-full flex items-center justify-center ring-2 ring-brand-accent/30">
                    <Icon name="code-bracket" className="w-10 h-10 text-brand-accent" />
                </div>
                <h1 className="text-4xl font-extrabold tracking-tight">The Developer's Journey</h1>
                <p className="mt-4 text-lg text-brand-muted max-w-3xl mx-auto">
                    A central resource for developers, technical partners, and new hires to understand, integrate with, and contribute to the VR4Deaf platform.
                </p>
            </section>

            {/* Resources Grid */}
            <section className="py-20 px-4">
                <div className="max-w-7xl mx-auto">
                     <h2 className="text-3xl font-bold text-center text-white mb-12">Developer Resources</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 items-stretch">
                        {resources.map(resource => (
                            <DocCard
                                key={resource.role}
                                {...resource}
                                navigate={navigate}
                            />
                        ))}
                    </div>

                    <div className="mt-20">
                         <h2 className="text-3xl font-bold text-center text-white mb-4">Master Blueprint: The Full 360Magicians Ecosystem</h2>
                         <p className="text-center text-brand-muted mb-12 max-w-4xl mx-auto">This master blueprint illustrates the complete, integrated ecosystem. A critical concept is that <strong className="text-brand-light">VURI™ AI knows every single person authenticated by DeafAUTH</strong>, creating a unified profile for each user. Key components include <strong className="text-brand-light">DeafAUTH</strong> as the central user memory, file store, and identity provider, and a multi-source <strong className="text-brand-light">Funding Layer</strong> featuring a decentralized DAO.</p>
                         <div className="bg-brand-primary/50 backdrop-blur-md p-4 sm:p-8 rounded-2xl shadow-2xl border border-brand-secondary overflow-x-auto">
                            <div className="mermaid flex justify-center">
                                {masterBlueprintDiagram}
                            </div>
                         </div>
                    </div>

                </div>
            </section>
        </div>
    );
};

export default DeveloperJourneyView;