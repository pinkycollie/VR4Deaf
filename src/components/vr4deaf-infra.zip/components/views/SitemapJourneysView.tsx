
import React from 'react';
import { Icon, IconName } from '../ui/Icon';
import { UserRole } from '../../types';
import { roleToPath, EXTERNAL_INTAKE_URL } from '../../constants';

interface SitemapJourneysViewProps {
  navigate: (path: string) => void;
}

const NetworkCluster: React.FC<{ 
    title: string; 
    icon: IconName; 
    links: { label: string; role?: UserRole; desc: string; href?: string }[];
    navigate: (path: string) => void;
}> = ({ title, icon, links, navigate }) => (
    <div className="bg-brand-primary/20 backdrop-blur-3xl rounded-[2.5rem] border border-white/5 overflow-hidden flex flex-col h-full shadow-2xl">
        <div className="p-8 border-b border-white/5 bg-white/[0.02] flex items-center gap-4">
            <div className="p-3 bg-brand-accent/10 rounded-2xl text-brand-accent">
                <Icon name={icon} className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-black text-white uppercase tracking-tighter">{title}</h2>
        </div>
        <div className="p-6 flex-grow space-y-4">
            {links.map((link, idx) => (
                link.href ? (
                    <a
                        key={idx}
                        href={link.href}
                        className="block group text-left p-4 rounded-2xl hover:bg-brand-accent/5 border border-transparent hover:border-brand-accent/20 transition-all"
                    >
                        <div className="flex justify-between items-center mb-1">
                            <span className="text-xs font-black text-brand-light uppercase tracking-widest group-hover:text-brand-accent transition-colors">{link.label}</span>
                            <Icon name="send" className="w-3 h-3 text-brand-muted opacity-0 group-hover:opacity-100 transition-all transform group-hover:translate-x-1" />
                        </div>
                        <p className="text-[10px] text-brand-muted font-bold uppercase tracking-wider leading-relaxed">{link.desc}</p>
                    </a>
                ) : (
                    <button
                        key={link.role}
                        onClick={() => link.role && navigate(roleToPath(link.role))}
                        className="w-full group text-left p-4 rounded-2xl hover:bg-brand-accent/5 border border-transparent hover:border-brand-accent/20 transition-all"
                    >
                        <div className="flex justify-between items-center mb-1">
                            <span className="text-xs font-black text-brand-light uppercase tracking-widest group-hover:text-brand-accent transition-colors">{link.label}</span>
                            <Icon name="send" className="w-3 h-3 text-brand-muted opacity-0 group-hover:opacity-100 transition-all transform group-hover:translate-x-1" />
                        </div>
                        <p className="text-[10px] text-brand-muted font-bold uppercase tracking-wider leading-relaxed">{link.desc}</p>
                    </button>
                )
            ))}
        </div>
    </div>
);

const SitemapJourneysView: React.FC<SitemapJourneysViewProps> = ({ navigate }) => {
    const clusters = [
        {
            title: "Access & Origins",
            icon: "user" as const,
            links: [
                { label: "Protocol Home", role: UserRole.HOME, desc: "Primary entry point for workforce infrastructure." },
                { label: "Founder Origins", role: UserRole.FOUNDER_STORY, desc: "The 'Why' behind our Deaf-first mission." },
                { label: "Vault Sync", href: EXTERNAL_INTAKE_URL, desc: "Secure authentication for active nodes." },
                { label: "Initialization", href: EXTERNAL_INTAKE_URL, desc: "Deploy new professional or specialist identity." },
            ]
        },
        {
            title: "Service Layer",
            icon: "cpu-chip" as const,
            links: [
                { label: "Success Protocol", role: UserRole.THE_PROCESS, desc: "Neural trajectory from intake to outcome." },
                { label: "Procurement Hub", role: UserRole.STORE, desc: "Authorized hardware and labor marketplace." },
                { label: "Network Directory", role: UserRole.ECOSYSTEM_DIRECTORY, desc: "Verified specialist and vendor mesh." },
                { label: "Housing Infra", role: UserRole.HOUSING, desc: "Competitive integrated living resources." },
            ]
        },
        {
            title: "Partner Nodes",
            icon: "briefcase" as const,
            links: [
                { label: "Counselor Core", role: UserRole.VR_COUNSELOR_JOURNEY, desc: "Agency-specific referral and tracking workflow." },
                { label: "Specialist Mesh", role: UserRole.VENDOR_JOURNEY, desc: "Onboarding for coaches and technical providers." },
                { label: "Employer Uplink", role: UserRole.EMPLOYER_JOURNEY, desc: "Direct talent pipeline for corporate partners." },
                { label: "Career Pod", role: UserRole.JOB_PLACEMENT, desc: "Live job boards and career documentation nodes." },
            ]
        },
        {
            title: "Engineering Vault",
            icon: "code-bracket" as const,
            links: [
                { label: "Neural DevOps", role: UserRole.AUTO_DEVOPS, desc: "CI/CD and automated integrity auditing." },
                { label: "Platform Architecture", role: UserRole.PLATFORM_ARCHITECTURE, desc: "Full-stack system data-flow blueprints." },
                { label: "API Reference", role: UserRole.API_DOCS, desc: "Headless gateway for agency integration." },
                { label: "System Logs", role: UserRole.CHANGELOG, desc: "Real-time protocol update history." },
            ]
        }
    ];

    return (
        <div className="bg-[#020617] min-h-screen text-brand-light pb-32 overflow-x-hidden">
            {/* High-Integrity Hero */}
            <section className="relative py-32 px-6 text-center border-b border-white/5 overflow-hidden">
                <div className="absolute inset-0 bg-grid-white/[0.01] bg-[size:60px_60px]"></div>
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-brand-accent/5 blur-[120px] rounded-full"></div>
                
                <div className="relative z-10 max-w-4xl mx-auto">
                    <div className="inline-flex items-center gap-3 px-5 py-2 rounded-full bg-brand-accent/5 border border-brand-accent/20 text-brand-accent text-[10px] font-black uppercase tracking-[0.5em] mb-10 shadow-glow-cyan animate-pulse">
                        <Icon name="map" className="w-3.5 h-3.5" />
                        SYSTEM INDEX: MASTER NETWORK TOPOLOGY
                    </div>
                    <h1 className="text-5xl md:text-8xl font-black text-white tracking-tighter uppercase mb-8 drop-shadow-2xl">
                        PLATFORM <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-accent to-white">BLUEPRINT</span>
                    </h1>
                    <p className="text-brand-muted text-lg md:text-xl font-bold uppercase tracking-[0.25em] leading-relaxed max-w-3xl mx-auto opacity-90">
                        Mapping the decentralized specialist mesh and autonomous logic layers for national VR scalability.
                    </p>
                </div>
            </section>

            {/* Network Grid */}
            <section className="py-24 px-6 relative z-10">
                <div className="max-w-[1600px] mx-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                        {clusters.map((cluster, i) => (
                            <NetworkCluster 
                                key={i} 
                                title={cluster.title} 
                                icon={cluster.icon} 
                                links={cluster.links} 
                                navigate={navigate} 
                            />
                        ))}
                    </div>
                </div>
            </section>

            {/* Governance Callout */}
            <section className="px-6 mt-12">
                <div className="max-w-6xl mx-auto bg-brand-accent/5 border border-brand-accent/20 p-12 rounded-[3.5rem] flex flex-col md:flex-row items-center gap-10 text-center md:text-left relative overflow-hidden">
                    <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:40px_40px] pointer-events-none"></div>
                    <div className="p-6 bg-brand-accent text-brand-dark rounded-3xl shadow-glow-cyan relative z-10">
                        <Icon name="shield-check" className="w-12 h-12" />
                    </div>
                    <div className="flex-grow relative z-10">
                        <h3 className="text-2xl font-black text-white uppercase tracking-tighter mb-2">Integrity Verification Node</h3>
                        <p className="text-brand-muted text-sm font-bold uppercase tracking-widest leading-relaxed">
                            Every node listed in this index is synchronized via the <span className="text-brand-accent">RSA-911 Compliance Engine</span>. Continuous automated audits ensure 100% transparency.
                        </p>
                    </div>
                    <button 
                        onClick={() => navigate(roleToPath(UserRole.COMPLIANCE_HUB))}
                        className="bg-white text-brand-dark font-black py-4 px-10 rounded-2xl uppercase text-[10px] tracking-widest hover:scale-105 active:scale-95 transition-all shadow-xl relative z-10"
                    >
                        Audit Network Health
                    </button>
                </div>
            </section>
        </div>
    );
};

export default SitemapJourneysView;
