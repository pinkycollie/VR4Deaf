
import React, { useState, useMemo } from 'react';
import { Icon } from '../ui/Icon';
import { MOCK_VENDORS } from '../../constants';
import { Vendor } from '../../types';

interface VRCounselorDashboardViewProps {
    showToast: (message: string) => void;
}

const RatingStars: React.FC<{ rating: number }> = ({ rating }) => {
    const fullStars = Math.floor(rating);
    return (
        <div className="flex items-center gap-1">
            {[...Array(5)].map((_, i) => (
                <Icon 
                    key={i} 
                    name="star" 
                    className={`w-3.5 h-3.5 ${i < fullStars ? 'text-brand-gold' : 'text-slate-200'}`} 
                    style={{ fill: i < fullStars ? 'currentColor' : 'none' }} 
                />
            ))}
            <span className="ml-1.5 text-[10px] font-black text-slate-400">{rating.toFixed(1)}</span>
        </div>
    );
};

const ComplianceAdvisory: React.FC = () => (
    <div className="bg-slate-50 border border-slate-200 p-8 rounded-3xl mb-12 shadow-sm">
        <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-[#0A2F5E] text-white rounded-xl flex items-center justify-center shadow-federal">
                <Icon name="shield-check" className="w-6 h-6" />
            </div>
            <div>
                <h2 className="text-xl font-display font-black text-[#0A2F5E] uppercase tracking-tight">Documentation Oversight</h2>
                <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">RSA-911 Case Integrity Review</p>
            </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="p-5 bg-white border border-slate-200 rounded-2xl flex items-start gap-4">
                <Icon name="check-badge" className="w-6 h-6 text-status-green mt-1" />
                <div>
                    <h4 className="text-sm font-black text-slate-800 uppercase mb-1">Audit Readiness: Optimal</h4>
                    <p className="text-xs text-slate-500 leading-relaxed font-medium">98% of active case tranches have synchronized progress notes and primary modality verified.</p>
                </div>
            </div>
            <div className="p-5 bg-white border border-slate-200 rounded-2xl flex items-start gap-4">
                <Icon name="flag" className="w-6 h-6 text-status-yellow mt-1" />
                <div>
                    <h4 className="text-sm font-black text-slate-800 uppercase mb-1">Authorization Alerts</h4>
                    <p className="text-xs text-slate-500 leading-relaxed font-medium">3 service tranches are reaching unit limits. Review case records for extension eligibility.</p>
                </div>
            </div>
        </div>
    </div>
);

const VRCounselorDashboardView: React.FC<VRCounselorDashboardViewProps> = ({ showToast }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [sortKey, setSortKey] = useState<'rating' | 'avgClientSuccessRate'>('rating');

    const filteredVendors = useMemo(() => {
        return MOCK_VENDORS.filter(vendor =>
            vendor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            vendor.role.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [searchTerm]);

    return (
        <div className="bg-[#F8FAFC] min-h-screen text-slate-800 p-6 sm:p-10 lg:p-16">
            <div className="max-w-7xl mx-auto">
                <header className="mb-12 flex flex-col md:flex-row justify-between items-end gap-6">
                    <div>
                        <h1 className="text-4xl font-display font-black text-[#0A2F5E] uppercase tracking-tight">Counselor <span className="text-brand-accent">Control Plane.</span></h1>
                        <p className="text-slate-500 font-bold text-sm uppercase tracking-widest mt-2">Managing Institutional Success & Case Integrity</p>
                    </div>
                    <div className="flex gap-4 w-full md:w-auto">
                        <div className="relative flex-grow md:w-80">
                            <input
                                type="text"
                                placeholder="Filter verified vendors..."
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3.5 pl-12 text-sm font-bold shadow-sm focus:ring-2 focus:ring-[#0A2F5E] outline-none transition-all"
                            />
                            <Icon name="magnifying-glass" className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                        </div>
                    </div>
                </header>

                <ComplianceAdvisory />

                <div className="bg-white border border-slate-200 rounded-3xl shadow-federal overflow-hidden">
                    <div className="p-8 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                        <h3 className="text-sm font-black text-[#0A2F5E] uppercase tracking-[0.2em]">Verified Service Network</h3>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{filteredVendors.length} ACTIVE PROVIDERS</span>
                    </div>
                    <table className="w-full text-left">
                        <thead className="bg-slate-50 border-b border-slate-100">
                            <tr>
                                <th className="p-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Provider Node</th>
                                <th className="p-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Credentialing</th>
                                <th className="p-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Success Outcome</th>
                                <th className="p-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Oversight</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {filteredVendors.map(vendor => (
                                <tr key={vendor.id} className="hover:bg-slate-50 transition-colors">
                                    <td className="p-6">
                                        <p className="font-display font-bold text-slate-800 leading-tight">{vendor.name}</p>
                                        <p className="text-[10px] font-bold text-brand-accent uppercase tracking-widest mt-1">{vendor.role}</p>
                                    </td>
                                    <td className="p-6">
                                        <RatingStars rating={vendor.rating} />
                                    </td>
                                    <td className="p-6 text-center">
                                        <span className="text-lg font-display font-black text-[#0A2F5E]">{vendor.avgClientSuccessRate}%</span>
                                        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">CIE Standard</p>
                                    </td>
                                    <td className="p-6 text-right">
                                        <button 
                                            onClick={() => showToast(`Synchronizing Case for ${vendor.name}...`)}
                                            className="bg-[#0A2F5E] text-white font-black py-2.5 px-6 rounded-lg uppercase text-[10px] tracking-widest hover:bg-brand-secondary shadow-federal transition-all active:scale-95"
                                        >
                                            Assign Provision
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default VRCounselorDashboardView;
