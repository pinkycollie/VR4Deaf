
import React from 'react';
import { Icon } from '../ui/Icon';
import { IconName } from '../ui/Icon';

const journeySteps = [
    {
        icon: 'send' as const,
        title: 'Receive Client Referral',
        description: 'A new client, referred by a VR Counselor, appears on your dashboard. You get instant access to their intake form and initial business idea.'
    },
    {
        icon: 'star' as const,
        title: 'Choose Your Partnership Tier',
        description: 'Select a partnership model that fits your needs. Opt for a free tier with standard transaction fees, or subscribe to a Premium tier for reduced fees, priority placement in our directory, and access to VURI™ performance analytics.'
    },
    {
        icon: 'clipboard-list' as const,
        title: 'Dashboard At-a-Glance',
        description: 'Your dashboard provides a high-level overview of all your clients. VURI™, your AI co-pilot, provides a summarized briefing to highlight key updates and clients who need attention.'
    },
    {
        icon: 'check' as const,
        title: 'Monitor Milestones & URLs',
        description: 'Drill down into any client to see their specific milestone progress. Use the URL monitoring tool to get live status updates on their websites and social media pages.'
    },
    {
        icon: 'specialist' as const,
        title: 'Provide Proactive Coaching',
        description: 'Use the data and insights from the platform to provide targeted, effective coaching. Send messages and generate progress reports with a single click.'
    },
    {
        icon: 'briefcase' as const,
        title: 'Facilitate Job Placement',
        description: 'For job-seeking clients, connect them with opportunities from the Job Placement Hub and guide them using our AI-powered career resources.'
    },
    {
        icon: 'report' as const,
        title: 'Generate Compliance Reports',
        description: 'Easily generate and export standardized progress reports for VR counselors, ensuring seamless communication and compliance.'
    }
];

const VendorJourneyView: React.FC = () => {
    return (
        <div className="bg-brand-dark">
             {/* Hero Section */}
            <section className="bg-brand-primary/50 text-white py-16 px-4 text-center rounded-b-2xl">
                <div className="w-16 h-16 mx-auto mb-4 bg-brand-accent/10 rounded-full flex items-center justify-center ring-2 ring-brand-accent/30">
                    <Icon name="specialist" className="w-10 h-10 text-brand-accent" />
                </div>
                <h1 className="text-4xl font-extrabold tracking-tight">The Vendor's Journey</h1>
                <p className="mt-4 text-lg text-brand-muted max-w-3xl mx-auto">A detailed workflow showing how vendors (Coaches, Specialists, Consultants) use our platform to manage clients and facilitate success.</p>
            </section>
            
            {/* Journey Timeline */}
            <section className="py-20 px-4">
                <div className="max-w-3xl mx-auto">
                    <div className="relative">
                        {/* The vertical line */}
                        <div className="absolute left-8 top-8 bottom-8 w-1 bg-brand-secondary/50 rounded-full" aria-hidden="true"></div>

                        <ul className="space-y-12">
                            {journeySteps.map((step, index) => (
                                <li key={index} className="flex items-start gap-6">
                                    <div className="flex-shrink-0 flex flex-col items-center">
                                        <div className="w-16 h-16 bg-brand-primary border-2 border-brand-accent/80 rounded-full flex items-center justify-center z-10 shadow-glow-cyan">
                                            <Icon name={step.icon} className="w-8 h-8 text-brand-accent" />
                                        </div>
                                    </div>
                                    <div className="bg-brand-primary/50 backdrop-blur-md p-6 rounded-xl border border-brand-secondary flex-grow -mt-2">
                                        <h3 className="text-xl font-bold text-white mb-2">{index + 1}. {step.title}</h3>
                                        <p className="text-brand-muted">{step.description}</p>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default VendorJourneyView;