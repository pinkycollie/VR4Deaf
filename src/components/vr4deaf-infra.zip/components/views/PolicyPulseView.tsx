import React, { useState, useEffect } from 'react';
import { Icon } from '../ui/Icon';
import * as api from '../../services/apiService';

export const PolicyPulseView: React.FC = () => {
    const [pulseData, setPulseData] = useState<{ text: string, links: { uri: string, title: string }[] } | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => { handleSync(); }, []);

    const handleSync = async () => {
        setIsLoading(true);
        try {
            const data = await api.getLatestPolicyNews();
            setPulseData(data);
        } catch (e) { console.error(e); } 
        finally { setIsLoading(false); }
    };

    return (
        <div className="bg-slate-50 min-h-screen text-slate-900 pb-24">
            <header className="pt-20 pb-12 px-4 sm:px-6 lg:px-8 border-b border-slate-200 bg-white">
                <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-end gap-6">
                    <div>
                        <div className="inline-flex items-center gap-2 text-blue-600 text-[10px] font-bold uppercase tracking-wider mb-4">
                            <Icon name="signal" className="w-4 h-4" />
                            Grounded Telemetry Sync
                        </div>
                        <h1 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight">Policy Pulse</h1>
                        <p className="text-base text-slate-500 font-medium max-w-2xl mt-1 leading-relaxed">
                            Autonomous search grounding for current VR funding and workforce mandates.
                        </p>
                    </div>
                    <button 
                        onClick={handleSync}
                        disabled={isLoading}
                        className="px-5 py-2.5 bg-white border border-slate-200 text-slate-700 font-bold rounded-lg text-xs flex items-center gap-2 hover:bg-slate-50 transition-all disabled:opacity-50"
                    >
                        <Icon name="cog" className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                        Refresh News
                    </button>
                </div>
            </header>

            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                {isLoading ? (
                    <div className="py-24 flex flex-col items-center justify-center gap-4">
                        <Icon name="cpu-chip" className="w-10 h-10 text-slate-200 animate-spin" />
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-[0.2em]">Querying Grounded Search Nodes...</p>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
                        <div className="lg:col-span-8">
                            <div className="bg-white p-8 sm:p-10 border border-slate-200 rounded-xl shadow-sm">
                                <div className="prose prose-slate max-w-none">
                                    <div className="text-lg leading-relaxed text-slate-700 whitespace-pre-wrap font-medium">
                                        {pulseData?.text}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="lg:col-span-4 space-y-6">
                            <div className="bg-white p-6 border border-slate-200 rounded-xl shadow-sm">
                                <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">Grounded Source Nodes</h3>
                                <div className="space-y-2">
                                    {pulseData?.links.map((link, i) => (
                                        <a 
                                            key={i} 
                                            href={link.uri} 
                                            target="_blank" 
                                            rel="noopener noreferrer" 
                                            className="block p-4 bg-slate-50 border border-slate-100 rounded-lg hover:border-blue-400 hover:bg-blue-50/30 transition-all group"
                                        >
                                            <p className="text-xs font-bold text-slate-900 group-hover:text-blue-700 transition-colors truncate mb-1">{link.title}</p>
                                            <p className="text-[10px] text-slate-400 font-mono truncate">{link.uri}</p>
                                        </a>
                                    ))}
                                    {pulseData?.links.length === 0 && <p className="text-xs text-slate-400 italic">No external nodes linked.</p>}
                                </div>
                            </div>

                            <div className="p-6 bg-blue-600 rounded-xl shadow-md text-white">
                                <Icon name="shield-check" className="w-6 h-6 mb-4 opacity-50" />
                                <h4 className="text-sm font-bold mb-2">Institutional Integrity</h4>
                                <p className="text-xs font-medium leading-relaxed opacity-90">
                                    Data retrieval is governed by the VURI™ Active Telemetry Engine. Logic adheres to federal audit guidelines and SemVer 2.0.0 standards.
                                </p>
                            </div>
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
};