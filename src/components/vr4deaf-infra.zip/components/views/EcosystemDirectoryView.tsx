
import React, { useState, useMemo } from 'react';
import { Icon } from '../ui/Icon';
import { US_STATES, MOCK_REFERRAL_PARTNERS } from '../../constants';
import { ReferralPartner } from '../../types';

/* Fix: Defined missing EcosystemDirectoryViewProps interface */
interface EcosystemDirectoryViewProps {
    showToast: (message: string) => void;
}

const PartnerCard: React.FC<{ partner: ReferralPartner }> = ({ partner }) => {
    const tierConfig = {
        'Premium': {
            badge: 'bg-yellow-400/20 text-yellow-300',
            icon: 'star' as const,
            text: 'Premium Partner',
            glow: 'shadow-[0_0_15px_-3px_rgba(250,204,21,0.4)]',
        },
        'Verified': {
            badge: 'bg-status-green/20 text-status-green',
            icon: 'check-badge' as const,
            text: 'Fibonrose Verified',
            glow: '',
        }
    };
    
    const tierInfo = partner.tier ? tierConfig[partner.tier] : null;

    return (
    <div className={`relative bg-brand-primary/50 backdrop-blur-md p-6 rounded-2xl shadow-lg border border-brand-secondary h-full flex flex-col group transition-all duration-300 hover:border-brand-accent/60 hover:scale-[1.02] hover:shadow-glow-cyan ${tierInfo?.glow}`}>
        <div className="flex justify-between items-start">
            <h3 className="text-xl font-bold text-brand-light group-hover:text-brand-accent pr-4 transition-colors">{partner.name}</h3>
            {tierInfo && (
                <div className={`flex items-center gap-1.5 text-xs font-bold px-2 py-1 rounded-full flex-shrink-0 ${tierInfo.badge}`}>
                    <Icon name={tierInfo.icon} className="w-4 h-4" />
                    <span>{tierInfo.text}</span>
                </div>
            )}
        </div>
        <span className="text-sm font-semibold text-brand-accent my-1">{partner.serviceCategory}</span>
        <p className="text-sm text-brand-muted flex-grow mt-2">{partner.description}</p>
        <div className="mt-4 pt-4 border-t border-brand-secondary/50">
            <p className="text-xs text-brand-muted"><strong>State:</strong> {partner.state}</p>
            <p className="text-xs text-brand-muted"><strong>Contact:</strong> {partner.contact}</p>
        </div>
    </div>
    );
};


const EcosystemDirectoryView: React.FC<EcosystemDirectoryViewProps> = ({ showToast }) => {
    const [filterState, setFilterState] = useState('All');
    const [filterService, setFilterService] = useState('All');
    const [searchTerm, setSearchTerm] = useState('');

    const serviceCategories = useMemo(() => ['All', ...Array.from(new Set(MOCK_REFERRAL_PARTNERS.map(p => p.serviceCategory)))], []);
    
    const filteredPartners = useMemo(() => {
        return MOCK_REFERRAL_PARTNERS.filter(partner => {
            const stateMatch = filterState === 'All' || partner.state === filterState;
            const serviceMatch = filterService === 'All' || partner.serviceCategory === filterService;
            const searchMatch = searchTerm.trim() === '' || 
                                partner.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                partner.description.toLowerCase().includes(searchTerm.toLowerCase());
            return stateMatch && serviceMatch && searchMatch;
        });
    }, [filterState, filterService, searchTerm]);


    return (
        <div className="bg-brand-dark">
            {/* Hero Section */}
            <section className="bg-brand-primary/50 text-white py-16 px-4 text-center rounded-b-2xl">
                <div className="w-16 h-16 mx-auto mb-4 bg-brand-accent/10 rounded-full flex items-center justify-center ring-2 ring-brand-accent/30">
                    <Icon name="share" className="w-10 h-10 text-brand-accent" />
                </div>
                <h1 className="text-4xl font-extrabold tracking-tight">Deaf-First Ecosystem Directory</h1>
                <p className="mt-4 text-lg text-brand-muted max-w-3xl mx-auto">Browse our curated network of Deaf-first and sign language certified providers, services, and products to support your journey.</p>
            </section>

            {/* Partner Network Section */}
            <section className="py-20 px-4">
                <div className="max-w-6xl mx-auto text-center">
                    <h2 className="text-3xl font-black text-white mb-4 uppercase tracking-tighter">The Partner <span className="text-brand-accent">Network</span></h2>
                    <p className="text-brand-muted mb-12 max-w-4xl mx-auto text-lg font-medium leading-relaxed">
                        Our directory is built on the Partner Network, a trust layer that verifies every provider for quality, ethics, and Deaf-first competency. Joining the Network allows vendors to build credibility and connect with clients in a secure, transparent ecosystem.
                    </p>
                    
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 text-left mb-12 items-stretch">
                        {/* Verified Partner Card */}
                        <div className="bg-brand-primary/40 backdrop-blur-xl p-10 rounded-[2.5rem] border border-brand-secondary hover:border-brand-accent/30 transition-all flex flex-col">
                            <div className="flex items-center gap-4 mb-6">
                                <div className="p-4 bg-status-green/10 rounded-2xl ring-1 ring-status-green/30">
                                    <Icon name="check-badge" className="w-8 h-8 text-status-green"/>
                                </div>
                                <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Verified Partner</h3>
                            </div>
                             <ul className="space-y-4 flex-grow">
                                <li className="flex items-start gap-3">
                                    <Icon name="check" className="w-5 h-5 text-status-green mt-1 flex-shrink-0"/>
                                    <span className="text-brand-light font-medium">Fibonrose ethical & quality check</span>
                                </li>
                                <li className="flex items-start gap-3">
                                    <Icon name="check" className="w-5 h-5 text-status-green mt-1 flex-shrink-0"/>
                                    <span className="text-brand-light font-medium">DeafAUTH identity & credential verification</span>
                                </li>
                                <li className="flex items-start gap-3">
                                    <Icon name="check" className="w-5 h-5 text-status-green mt-1 flex-shrink-0"/>
                                    <span className="text-brand-light font-medium">Standard listing in the directory</span>
                                </li>
                             </ul>
                        </div>

                        {/* Premium Partner Card */}
                        <div className="bg-brand-primary/40 backdrop-blur-xl p-10 rounded-[2.5rem] border-2 border-yellow-400 shadow-[0_0_25px_-5px_rgba(250,204,21,0.2)] flex flex-col transition-all">
                             <div className="flex items-center gap-4 mb-6">
                                <div className="p-4 bg-yellow-400/10 rounded-2xl ring-1 ring-yellow-400/30">
                                    <Icon name="star" className="w-8 h-8 text-yellow-300"/>
                                </div>
                                <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Premium Partner</h3>
                            </div>
                             <ul className="space-y-4 flex-grow">
                                <li className="flex items-start gap-3">
                                    <Icon name="check" className="w-5 h-5 text-status-green mt-1 flex-shrink-0"/>
                                    <span className="text-brand-light font-medium">All benefits of the Verified tier</span>
                                </li>
                                <li className="flex items-start gap-3">
                                    <Icon name="check" className="w-5 h-5 text-status-green mt-1 flex-shrink-0"/>
                                    <span className="text-brand-light font-medium">Priority placement in search results</span>
                                </li>
                                <li className="flex items-start gap-3">
                                    <Icon name="check" className="w-5 h-5 text-status-green mt-1 flex-shrink-0"/>
                                    <span className="text-brand-light font-medium">Access to VURI™ performance analytics</span>
                                </li>
                                <li className="flex items-start gap-3">
                                    <Icon name="check" className="w-5 h-5 text-status-green mt-1 flex-shrink-0"/>
                                    <span className="text-brand-light font-medium">Reduced platform transaction fees</span>
                                </li>
                             </ul>
                        </div>
                    </div>

                    <a 
                        href="https://partners.pinksync.io" 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="inline-block bg-brand-accent hover:bg-cyan-300 text-brand-dark font-black py-5 px-14 rounded-2xl uppercase text-sm tracking-[0.2em] transition-all transform hover:scale-[1.03] active:scale-95 shadow-glow-cyan"
                    >
                        Join the Partner Network
                    </a>
                </div>
            </section>

            {/* Directory Content */}
             <section className="py-20 px-4 bg-brand-primary/20 rounded-[4rem] my-10 mx-4 border border-white/5">
                <div className="max-w-7xl mx-auto">
                     {/* Filters & Search */}
                    <div className="bg-brand-primary/50 backdrop-blur-md p-6 rounded-[2rem] shadow-xl border border-brand-secondary mb-12 space-y-4">
                        <div className="relative">
                            <input
                                type="text"
                                placeholder="Search nodes by name or service..."
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                                className="w-full bg-brand-dark/50 px-6 py-4 pl-14 border border-white/5 rounded-2xl shadow-sm focus:ring-brand-accent focus:border-brand-accent text-white font-bold placeholder:text-brand-muted/40 transition-all outline-none"
                            />
                            <Icon name="magnifying-glass" className="absolute left-5 top-1/2 -translate-y-1/2 w-6 h-6 text-brand-muted" />
                        </div>
                        <div className="flex flex-col sm:flex-row gap-6 items-center pt-2">
                            <p className="text-[10px] font-black text-brand-accent uppercase tracking-widest flex-shrink-0">Integrity Filters</p>
                            <div className="flex-grow grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
                                 <select value={filterState} onChange={e => setFilterState(e.target.value)} className="w-full bg-brand-dark/80 px-4 py-3 border border-white/5 rounded-xl shadow-sm focus:ring-brand-accent focus:border-brand-accent text-brand-light font-bold text-sm outline-none transition-all cursor-pointer">
                                    <option value="All">All State Nodes</option>
                                    {US_STATES.map(state => <option key={state} value={state}>{state}</option>)}
                                </select>
                                 <select value={filterService} onChange={e => setFilterService(e.target.value)} className="w-full bg-brand-dark/80 px-4 py-3 border border-white/5 rounded-xl shadow-sm focus:ring-brand-accent focus:border-brand-accent text-brand-light font-bold text-sm outline-none transition-all cursor-pointer">
                                    {serviceCategories.map(cat => <option key={cat} value={cat}>{cat === 'All' ? 'All Modalities' : cat}</option>)}
                                </select>
                            </div>
                        </div>
                    </div>

                    {/* Partner Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {filteredPartners.length > 0 ? filteredPartners.map(partner => (
                            <PartnerCard key={partner.id} partner={partner} />
                        )) : (
                            <div className="md:col-span-2 lg:col-span-3 text-center text-brand-muted py-24 bg-brand-primary/40 rounded-[3rem] border border-white/5">
                                <Icon name="shield-exclamation" className="w-16 h-16 mx-auto mb-4 text-brand-muted/30" />
                                <p className="text-xl font-bold uppercase tracking-widest opacity-50">No verified partners matching your criteria.</p>
                            </div>
                        )}
                    </div>
                </div>
            </section>
        </div>
    );
};

export default EcosystemDirectoryView;
