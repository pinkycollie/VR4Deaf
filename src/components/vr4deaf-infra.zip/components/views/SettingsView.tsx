
import React from 'react';
import { Icon, IconName } from '../ui/Icon';

const ConfigNode: React.FC<{ icon: IconName; title: string; label: string; children: React.ReactNode }> = ({ icon, title, label, children }) => (
    <div className="bg-brand-primary/20 backdrop-blur-3xl p-10 rounded-[3rem] border border-white/5 h-full group hover:border-brand-accent/20 transition-all">
        <div className="flex items-start gap-5 mb-8">
            <div className="bg-brand-accent/5 p-4 rounded-2xl ring-1 ring-brand-accent/10 flex-shrink-0 group-hover:bg-brand-accent/10 transition-colors">
                 <Icon name={icon} className="w-10 h-10 text-brand-accent" />
            </div>
            <div>
                <span className="text-[9px] font-black text-brand-accent uppercase tracking-[0.4em] mb-1 block">{label}</span>
                <h2 className="text-3xl font-black text-white uppercase tracking-tighter leading-none">{title}</h2>
            </div>
        </div>
        <div className="space-y-6 pt-6 border-t border-white/5">
            {children}
        </div>
    </div>
);


const SettingsView: React.FC = () => {
    return (
        <div className="bg-[#020617] min-h-screen text-brand-light pb-20">
            <header className="relative h-[30vh] min-h-[250px] flex items-center justify-center border-b border-white/5 overflow-hidden">
                <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:40px_40px]"></div>
                <div className="relative z-10 text-center">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-brand-muted text-[10px] font-black uppercase tracking-[0.4em] mb-6">
                        <Icon name="cog" className="w-3 h-3" />
                        System Config Node
                    </div>
                    <h1 className="text-5xl md:text-7xl font-black text-white uppercase tracking-tighter">Configuration</h1>
                </div>
            </header>

            <section className="py-20 px-6">
                <div className="max-w-[1400px] mx-auto grid grid-cols-1 lg:grid-cols-2 gap-10">
                    
                    <ConfigNode icon="cog" title="Organization" label="Metadata Node">
                        <div className="space-y-2">
                            <label className="text-[10px] font-black text-brand-muted uppercase tracking-widest ml-1">Entity Name</label>
                            <input type="text" defaultValue="MBTQ Solutions Hub" className="w-full px-6 py-4 bg-brand-dark/50 border border-white/5 rounded-2xl text-white font-bold focus:border-brand-accent outline-none transition-all" />
                        </div>
                         <button className="w-full bg-brand-accent text-brand-dark font-black py-4 rounded-2xl uppercase text-[10px] tracking-widest shadow-glow-cyan hover:scale-[1.02] transition-all">
                            Commit Metadata
                        </button>
                    </ConfigNode>

                    <ConfigNode icon="key" title="API Gateway" label="Security Uplink">
                        <div className="bg-brand-dark/40 p-5 rounded-2xl border border-white/5 flex justify-between items-center group/key">
                            <div>
                                <p className="text-[10px] font-black text-brand-muted uppercase tracking-widest mb-1">Production Node Key</p>
                                <p className="font-mono text-xs text-brand-accent">vuri_sk_827...911x</p>
                            </div>
                            <button className="text-[10px] font-black uppercase text-status-red hover:text-white transition-colors">Revoke</button>
                        </div>
                        <button className="w-full bg-brand-secondary/40 border border-white/10 text-white font-black py-4 rounded-2xl uppercase text-[10px] tracking-widest hover:bg-brand-secondary transition-all">
                            Generate New Sync Link
                        </button>
                    </ConfigNode>
                    
                    <ConfigNode icon="credit-card" title="Economic Path" label="GU Treasury">
                         <div className="p-6 bg-brand-accent/5 rounded-2xl border border-brand-accent/20">
                            <p className="text-xl font-black text-white uppercase tracking-tight">Premium Agency Tier</p>
                            <p className="text-[10px] text-brand-accent font-bold uppercase tracking-widest mt-1">Status: Active & Synchronized</p>
                        </div>
                        <div className="flex justify-between items-center px-2">
                             <p className="text-sm font-bold text-brand-light uppercase tracking-tighter">Next Audit: Dec 2055</p>
                             <button className="text-[10px] font-black text-brand-accent hover:underline uppercase">Manage Tranches</button>
                        </div>
                    </ConfigNode>

                    <ConfigNode icon="users" title="Authorized Nodes" label="Neural Team">
                        <div className="space-y-4">
                            {[
                                { name: 'V. Master AI', role: 'Financial Governor', status: 'Core' },
                                { name: 'Admin Node', role: 'System Auditor', status: 'Active' }
                            ].map((user, i) => (
                                <div key={i} className="flex justify-between items-center p-4 bg-white/5 rounded-2xl border border-white/5">
                                    <div>
                                        <p className="text-sm font-black text-white uppercase">{user.name}</p>
                                        <p className="text-[9px] font-bold text-brand-muted uppercase tracking-widest">{user.role}</p>
                                    </div>
                                    <span className="text-[9px] font-black px-2 py-1 bg-status-green/10 text-status-green rounded uppercase">{user.status}</span>
                                </div>
                            ))}
                        </div>
                         <button className="w-full bg-white text-brand-dark font-black py-4 rounded-2xl uppercase text-[10px] tracking-widest hover:scale-[1.02] transition-all">
                            Invite Specialist Node
                        </button>
                    </ConfigNode>
                </div>
            </section>
        </div>
    );
};

export default SettingsView;
