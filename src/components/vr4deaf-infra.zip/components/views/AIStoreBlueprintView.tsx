
import React, { ReactNode } from 'react';
import { Icon, IconName } from '../ui/Icon';

const CodeBlock: React.FC<{ children: ReactNode, language?: string }> = ({ children, language = 'javascript' }) => (
    <pre className="bg-brand-dark/70 text-sm text-cyan-200 p-4 rounded-lg border border-brand-secondary overflow-x-auto">
        <code className={`language-${language}`}>{children}</code>
    </pre>
);

const StepCard: React.FC<{ number: number; icon: IconName; title: string; description: string; children: ReactNode }> = ({ number, icon, title, description, children }) => (
    <div className="flex items-start gap-6">
        <div className="flex-shrink-0 flex flex-col items-center">
            <div className="w-20 h-20 bg-brand-primary border-2 border-brand-accent/80 rounded-full flex items-center justify-center z-10 shadow-glow-cyan">
                <span className="text-4xl font-bold text-brand-accent">{number}</span>
            </div>
            <div className="w-1 flex-grow bg-brand-secondary/50 my-4"></div>
        </div>
        <div className="bg-brand-primary/50 backdrop-blur-md p-6 rounded-xl border border-brand-secondary flex-grow -mt-2 w-full">
            <div className="flex items-center gap-4 mb-3">
                 <Icon name={icon} className="w-8 h-8 text-brand-accent" />
                <h3 className="text-2xl font-bold text-white">{title}</h3>
            </div>
            <p className="text-brand-muted mb-6">{description}</p>
            {children}
        </div>
    </div>
);

const VuriInsight: React.FC<{ children: ReactNode }> = ({ children }) => (
    <div className="mt-4 bg-brand-dark/50 p-4 rounded-lg border-l-4 border-brand-accent/70">
        <div className="flex items-center gap-3 mb-2">
            <Icon name="sparkles" className="w-5 h-5 text-brand-accent" />
            <h4 className="font-semibold text-brand-accent">VURI™ Co-Pilot Insight</h4>
        </div>
        <div className="text-sm text-brand-light/90 space-y-2">{children}</div>
    </div>
);


const AIStoreBlueprintView: React.FC = () => {
    return (
        <div className="bg-brand-dark">
            {/* Hero Section */}
            <section className="bg-brand-primary/50 text-white py-16 px-4 text-center rounded-b-2xl">
                <div className="w-16 h-16 mx-auto mb-4 bg-brand-accent/10 rounded-full flex items-center justify-center ring-2 ring-brand-accent/30">
                    <Icon name="cog" className="w-10 h-10 text-brand-accent" />
                </div>
                <h1 className="text-4xl font-extrabold tracking-tight">AI Co-Pilot: Building the VR4Deaf Store</h1>
                <p className="mt-4 text-lg text-brand-muted max-w-3xl mx-auto">A developer's guide to creating a modern, accessible, and scalable e-commerce platform, with insights from your AI co-pilot, VURI™.</p>
            </section>

            {/* Main Content */}
            <section className="py-20 px-4">
                <div className="max-w-4xl mx-auto">
                    <div className="space-y-8">
                        
                        <StepCard number={1} icon="server-stack" title="Technology Stack Selection" description="Choosing the right tools is the foundation. We recommend a modern, component-based frontend and a scalable, serverless backend for optimal performance and developer experience.">
                            <VuriInsight>
                                <p>For maximum performance and SEO, a framework like Next.js (built on React) hosted on Vercel is ideal. It supports Server-Side Rendering (SSR) and Static Site Generation (SSG) out of the box. For the backend, a headless e-commerce platform like Shopify or a custom-built solution using Node.js and Stripe for payments provides flexibility.</p>
                            </VuriInsight>
                        </StepCard>

                        <StepCard number={2} icon="cube" title="Data Modeling & Schema" description="Define the structure of your data. This includes products, users, orders, and inventory. A well-designed schema is crucial for a scalable store.">
                            <VuriInsight>
                                <p>Here is a simplified JSON schema for a Product. Notice the `accessibilityFeatures` array, which is critical for a Deaf-first platform.</p>
                                <CodeBlock language="json">{`{
  "product": {
    "id": "prod_12345",
    "name": "Smart Captioning Glasses",
    "description": "Real-time captions displayed directly in your field of view.",
    "price": 699.99,
    "images": ["/img1.jpg", "/img2.jpg"],
    "inventory": 150,
    "categories": ["assistive-tech", "wearables"],
    "accessibilityFeatures": [
      "Real-time captioning",
      "Adjustable font size",
      "Multiple language support"
    ]
  }
}`}</CodeBlock>
                            </VuriInsight>
                        </StepCard>
                        
                        <StepCard number={3} icon="device-tablet" title="Accessible Frontend Development" description="Build the user interface with accessibility (a11y) as the top priority. This is non-negotiable for a Deaf-first platform.">
                             <VuriInsight>
                                <p>Focus on semantic HTML, ARIA attributes, and keyboard navigation. All interactive elements must be focusable and operable without a mouse. For video content, ensure high-quality, user-toggleable captions and ASL interpretation options are available.</p>
                                <CodeBlock language="jsx">{`// Example of an accessible button in React
<button
  aria-label="Add Smart Captioning Glasses to your cart"
  onClick={handleAddToCart}
  className="add-to-cart-btn"
>
  <ShoppingCartIcon />
  <span>Add to Cart</span>
</button>`}</CodeBlock>
                             </VuriInsight>
                        </StepCard>

                         <StepCard number={4} icon="shopping-cart" title="Cart & Checkout Logic" description="Implement the core e-commerce functionality. This includes adding items to a cart, managing quantities, and processing payments securely.">
                             <VuriInsight>
                                <p>Use a state management library like Redux Toolkit or Zustand to manage the cart state globally in your React application. For payments, integrate a trusted provider like Stripe. Their pre-built UI components (`Stripe Elements`) are secure, accessible, and simplify PCI compliance by ensuring sensitive card data never touches your server.</p>
                             </VuriInsight>
                        </StepCard>

                        <StepCard number={5} icon="rocket-launch" title="Deployment & Automation" description="Automate your deployment process to ensure fast, reliable, and consistent updates to your store.">
                            <VuriInsight>
                               <p>Connect your GitHub repository to a hosting provider like Vercel or Netlify. This creates a CI/CD (Continuous Integration/Continuous Deployment) pipeline. Every `git push` to your main branch can automatically trigger a build, run tests, and deploy the new version with zero downtime. This is the same process outlined in our platform's Auto DevOps documentation.</p>
                            </VuriInsight>
                        </StepCard>

                    </div>
                </div>
            </section>
        </div>
    );
};

export default AIStoreBlueprintView;
