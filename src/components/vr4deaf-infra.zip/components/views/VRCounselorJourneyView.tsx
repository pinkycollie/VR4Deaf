import React from 'react';
import { Icon } from '../ui/Icon';
import { IconName } from '../ui/Icon';

const journeySteps = [
    {
        icon: 'link' as const,
        title: 'Secure Referral & Partnership',
        description: 'Partner with VR4Deaf to add a powerful, Deaf-first self-employment and job placement track to your state\'s list of approved service providers.'
    },
    {
        icon: 'document-text' as const,
        title: 'Streamlined Client Intake',
        description: 'Use our simple, secure intake form or have your client use our revolutionary AI-powered ASL video intake. All data is captured and organized instantly.'
    },
    {
        icon: 'clipboard-list' as const,
        title: 'Real-time Progress Monitoring',
        description: 'Gain access to a dedicated dashboard to view client progress in real-time. Our AI co-pilot, VURI™, also provides performance analytics and recommendations for vendors.'
    },
    {
        icon: 'report' as const,
        title: 'Easy Compliance & Reporting',
        description: 'Our platform provides standardized, one-click progress reports, making your documentation and reporting requirements faster and easier than ever.'
    },
     {
        icon: 'check' as const,
        title: 'Achieve Successful Outcomes',
        description: 'Leverage our specialized tools and expert network to help your clients successfully launch their businesses or secure meaningful employment.'
    }
];

const VRCounselorJourneyView: React.FC = () => {
    return (
        <div className="bg-brand-dark">
             {/* Hero Section */}
            <section className="bg-brand-primary/50 text-white py-16 px-4 text-center rounded-b-2xl">
                <div className="w-16 h-16 mx-auto mb-4 bg-brand-accent/10 rounded-full flex items-center justify-center ring-2 ring-brand-accent/30">
                    <Icon name="briefcase" className="w-10 h-10 text-brand-accent" />
                </div>
                <h1 className="text-4xl font-extrabold tracking-tight">The VR Counselor's Journey</h1>
                <p className="mt-4 text-lg text-brand-muted max-w-3xl mx-auto">Discover how our platform simplifies your workflow, enhances client outcomes, and streamlines reporting for state Vocational Rehabilitation agencies.</p>
            </section>
            
            {/* Journey Timeline */}
            <section className="py-20 px-4">
                <div className="max-w-3xl mx-auto">
                    <div className="relative">
                        {/* The vertical line */}
                        <div className="absolute left-8 top-8 bottom-8 w-1 bg-brand-secondary/50 rounded-full" aria-hidden="true"></div>

                        <ul className="space-y-12">
                            {journeySteps.map((step, index) => (
                                <li key={index} className="flex items-start gap-6">
                                    <div className="flex-shrink-0 flex flex-col items-center">
                                        <div className="w-16 h-16 bg-brand-primary border-2 border-brand-accent/80 rounded-full flex items-center justify-center z-10 shadow-glow-cyan">
                                            <Icon name={step.icon} className="w-8 h-8 text-brand-accent" />
                                        </div>
                                    </div>
                                    <div className="bg-brand-primary/50 backdrop-blur-md p-6 rounded-xl border border-brand-secondary flex-grow -mt-2">
                                        <h3 className="text-xl font-bold text-white mb-2">{index + 1}. {step.title}</h3>
                                        <p className="text-brand-muted">{step.description}</p>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    </div>

                    {/* SARA Digital Integration Note */}
                    <div className="mt-20 bg-brand-primary/50 backdrop-blur-lg p-8 rounded-2xl shadow-2xl border border-brand-secondary/50 text-center">
                         <div className="inline-block p-4 bg-brand-accent/10 rounded-full mb-5 ring-4 ring-brand-accent/30">
                             <Icon name="cog" className="w-12 h-12 text-brand-accent"/>
                        </div>
                        <h2 className="text-2xl font-bold text-white mb-4">A Note on Government Platform Integration</h2>
                        <p className="text-brand-muted max-w-2xl mx-auto">
                            We understand that many state agencies use specific case management systems like SARA Digital. While direct API integration with these government platforms can be challenging and slow, our system is designed to complement your existing workflow. You can easily generate and download standardized reports from VR4Deaf, ensuring you have all the necessary documentation for seamless entry into your required system.
                        </p>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default VRCounselorJourneyView;