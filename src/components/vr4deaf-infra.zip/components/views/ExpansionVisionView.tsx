
import React from 'react';
import { Icon } from '../ui/Icon';

const PhaseCard: React.FC<{ number: string, title: string, desc: string, items: string[], current?: boolean }> = ({ number, title, desc, items, current }) => (
    <div className={`relative p-8 rounded-3xl border-2 transition-all ${current ? 'bg-brand-primary border-brand-accent shadow-glow-cyan' : 'bg-brand-dark/40 border-brand-secondary opacity-60 hover:opacity-100'}`}>
        {current && (
            <div className="absolute -top-3 right-6 bg-brand-accent text-brand-dark text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-tighter">Current Focus</div>
        )}
        <div className="text-brand-accent font-black text-5xl mb-4 opacity-30">{number}</div>
        <h3 className="text-2xl font-bold text-white mb-2">{title}</h3>
        <p className="text-brand-muted mb-6 text-sm">{desc}</p>
        <ul className="space-y-3">
            {items.map((item, i) => (
                <li key={i} className="flex items-center gap-2 text-brand-light text-xs font-medium">
                    <Icon name="check" className="w-3 h-3 text-brand-accent" />
                    {item}
                </li>
            ))}
        </ul>
    </div>
);

export const ExpansionVisionView: React.FC = () => {
    return (
        <div className="bg-brand-dark py-16 px-4">
            <div className="max-w-6xl mx-auto">
                <div className="text-center mb-16">
                    <h2 className="text-brand-accent font-bold uppercase tracking-widest text-sm mb-4">Strategic Roadmap</h2>
                    <h1 className="text-5xl font-black text-white mb-6">Becoming the #1 Multi-Agency Partner</h1>
                    <p className="text-brand-muted max-w-3xl mx-auto text-lg leading-relaxed">
                        We are starting with the most underserved and communication-locked demographic: the Deaf community. By solving for the highest level of accessibility, we build a foundation that scales effortlessly to every intersectional agency on earth.
                    </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <PhaseCard 
                        number="01" 
                        title="Deaf-First Core" 
                        current
                        desc="Perfecting the visual-first, AI-transcription driven workflow for Deaf entrepreneurs and VR counselors."
                        items={[
                            "ASL Video Intake Systems",
                            "TWC Vendor Integration",
                            "Visual-Text Sync Intelligence"
                        ]}
                    />
                    <PhaseCard 
                        number="02" 
                        title="LGBTQIA+ Agencies" 
                        desc="Expanding to agencies focusing on queer workforce development, housing, and inclusive legal resources."
                        items={[
                            "Safe-Space ID Protocols",
                            "Gender-Affirming Benefit Hubs",
                            "Intersectional Coaching Logic"
                        ]}
                    />
                    <PhaseCard 
                        number="03" 
                        title="Universal Scale" 
                        desc="The definitive AI co-pilot for any government or non-profit agency managing client outcomes at scale."
                        items={[
                            "Federal Gov-API Gateway",
                            "Multi-Language LLM Agents",
                            "Global Compliance Standard"
                        ]}
                    />
                </div>

                <div className="mt-20 p-10 bg-brand-primary/30 border border-brand-secondary rounded-3xl text-center">
                    <Icon name="sparkles" className="w-16 h-16 text-brand-accent mx-auto mb-6" />
                    <h2 className="text-3xl font-bold text-white mb-4">A Legacy of Inclusion</h2>
                    <p className="text-brand-muted max-w-2xl mx-auto mb-8">
                        Our goal isn't just to build a tool; it's to build a protocol for human potential. Whether it's a Deaf founder in Texas or a queer professional in New York, VURI™ ensures their path to success is data-verified, funded, and compliant.
                    </p>
                    <button className="bg-brand-accent text-brand-dark font-black py-4 px-10 rounded-full hover:scale-105 transition-transform shadow-glow-cyan">Partner with the Future</button>
                </div>
            </div>
        </div>
    );
};
