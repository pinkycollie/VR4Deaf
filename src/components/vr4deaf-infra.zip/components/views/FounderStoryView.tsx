
import React from 'react';
import { Icon } from '../ui/Icon';

interface FounderStoryViewProps {
    onClose: () => void;
    isModal: boolean;
}

export const FounderStoryView: React.FC<FounderStoryViewProps> = ({ onClose, isModal }) => {

    const storyContent = (
        <>
            <section className={`bg-brand-primary/50 text-white py-16 px-4 text-center ${isModal ? 'rounded-t-2xl' : 'rounded-b-2xl'}`}>
                <div className="w-16 h-16 mx-auto mb-4 bg-brand-accent/10 rounded-full flex items-center justify-center ring-2 ring-brand-accent/30">
                    <Icon name="user" className="w-10 h-10 text-brand-accent" />
                </div>
                <h1 className="text-4xl font-extrabold tracking-tight">The Origins</h1>
                <p className="mt-4 text-lg text-brand-muted max-w-3xl mx-auto">It's all about us ensuring every user finds their path to wealth and inclusion.</p>
            </section>

            {/* Main Content */}
            <section className="py-12 px-4">
                <div className="max-w-4xl mx-auto space-y-6 text-lg text-brand-light leading-relaxed">
                    <p>
                        The idea for VR4Deaf wasn't born in a boardroom. It was forged in frustration, in a series of sterile Vocational Rehabilitation office meetings that all ended the same way.
                    </p>
                    <p className="pl-6 border-l-4 border-brand-accent italic text-brand-muted">
                        "Every time I came to the office, I always said I want to start a business," the founder recalls. "I had plans, I had ideas, I had the drive. I just needed the right resources—connections to mentors, help with a business plan, access to startup capital."
                    </p>
                    <p>
                        But the traditional VR system wasn't built for that. It was a system set on job placement, not entrepreneurship. The conversations always circled back to finding a job, any job, to close the case. They were fixated on providing hearing aids, but deaf to the request for entrepreneurial resources.
                    </p>
                    <p>
                        "I ended up in a warehouse job. They considered it a success, closed the case, and moved on. My entrepreneurial dream was delayed, again. I realized the system wasn't designed to support ambition like mine; it was designed for compliance."
                    </p>
                    <p>
                        That's why VR4Deaf was built. It's a platform designed to listen first, to see the entrepreneur before the disability, and to provide the specific, high-quality, accommodated workspaces needed to turn a professional dream into a reality.
                    </p>
                    <p>
                        We collaborate with experts at <a href="https://mbtq.dev" target="_blank" rel="noopener noreferrer" className="text-brand-accent hover:underline">MBTQ Solutions</a> to ensure our digital foundations are as accessible as our physical goals. We aren't just building a tool; we are building an ecosystem where creative, developer, and business spaces are accommodated by default.
                    </p>
                    <blockquote className="mt-10 text-center text-xl italic text-brand-accent border-t border-b border-brand-secondary/50 py-6">
                        "This is not about me. It's about us. Ensuring wealth and inclusion for every node in our network."
                    </blockquote>
                </div>
            </section>
        </>
    );
    
    if (isModal) {
        return (
            <div className="fixed inset-0 bg-brand-dark/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in-up">
                <div className="bg-brand-dark max-w-5xl w-full max-h-[90vh] overflow-y-auto rounded-2xl shadow-2xl border border-brand-secondary relative">
                     <button onClick={onClose} className="absolute top-4 right-4 text-brand-muted hover:text-white transition-colors z-10">
                        <Icon name="x-mark" className="w-8 h-8"/>
                     </button>
                    {storyContent}
                </div>
            </div>
        )
    }

    return (
        <div className="bg-brand-dark">
           {storyContent}
        </div>
    );
};

export default FounderStoryView;