
import React, { useState, useEffect } from 'react';
import { Icon } from '../ui/Icon';
import { MeshTelemetry } from '../../types';
import { SYMBOL_REGISTRY, INTENTIONAL_FORMULA } from '../../manifest.symbols';

export const GovernanceNodeView: React.FC = () => {
    const [telemetry, setTelemetry] = useState<MeshTelemetry>({
        totalGUCirculation: 1245000,
        activeTrajectories: 420,
        globalIntegrityScore: 99.1,
        nodeHealth: {
            'TX-HUB': 'Optimal',
            'NY-NODE': 'Optimal',
            'CA-GATEWAY': 'Optimal',
            'WASM-CORE': 'Optimal'
        }
    });

    return (
        <div className="bg-[#010413] min-h-screen text-white font-mono p-8 lg:p-20 overflow-x-hidden selection:bg-brand-accent/30">
            <header className="mb-20 flex flex-col md:flex-row justify-between items-start gap-10">
                <div>
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-brand-accent/10 border border-brand-accent/20 text-brand-accent text-[9px] font-black uppercase tracking-[0.5em] mb-4">
                        <Icon name="shield-check" className="w-3 h-3" />
                        Master Protocol: Root Level Access
                    </div>
                    <h1 className="text-5xl font-black uppercase tracking-tighter leading-none mb-4">
                        Governance <span className="text-brand-accent">Node.</span>
                    </h1>
                    <p className="text-slate-500 font-bold text-xs uppercase tracking-widest max-w-xl">
                        Global telemetry for the decentralized VR success mesh. Performance tranches monitored via {SYMBOL_REGISTRY.GU_UNIT} tranches.
                    </p>
                </div>
                <div className="bg-white/5 border border-white/10 p-6 rounded-2xl text-right">
                    <p className="text-[9px] font-black text-brand-muted uppercase mb-2">Intentional Proof</p>
                    <p className="text-xl text-brand-accent font-black tracking-widest">{INTENTIONAL_FORMULA}</p>
                </div>
            </header>

            <main className="space-y-10">
                {/* Global Metrics Mesh */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {[
                        { label: 'Mesh Integrity (ι)', val: `${telemetry.globalIntegrityScore}%`, icon: 'shield-check', color: 'text-status-green' },
                        { label: 'Success Tranches (σ)', val: telemetry.activeTrajectories, icon: 'check-badge', color: 'text-brand-accent' },
                        { label: 'Circulating Credits (γ)', val: telemetry.totalGUCirculation.toLocaleString(), icon: 'currency-dollar', color: 'text-brand-gold' },
                        { label: 'Logic Version', val: '3.4.0', icon: 'cog', color: 'text-white' }
                    ].map((m, i) => (
                        <div key={i} className="bg-white/5 border border-white/10 p-8 rounded-[2rem] hover:border-brand-accent/50 transition-all group">
                            <Icon name={m.icon as any} className={`w-8 h-8 ${m.color} mb-6 group-hover:scale-110 transition-transform`} />
                            <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.3em] mb-2">{m.label}</p>
                            <p className="text-4xl font-black uppercase tracking-tighter">{m.val}</p>
                        </div>
                    ))}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
                    {/* Node Health Matrix */}
                    <div className="lg:col-span-8 bg-brand-primary/40 backdrop-blur-3xl border border-white/10 rounded-[3rem] p-10 shadow-2xl">
                        <h3 className="text-xs font-black uppercase tracking-[0.4em] mb-10 text-brand-accent">Regional Node Status Matrix</h3>
                        <div className="space-y-4">
                            {Object.entries(telemetry.nodeHealth).map(([node, status]) => (
                                <div key={node} className="flex items-center justify-between p-6 bg-black/40 border border-white/5 rounded-2xl group hover:border-white/10 transition-all">
                                    <div className="flex items-center gap-6">
                                        <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center font-black text-xs">
                                            {node.substring(0, 2)}
                                        </div>
                                        <div>
                                            <p className="font-black text-lg tracking-tight uppercase">{node}</p>
                                            <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">Authorized Uplink Active</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-3 px-4 py-2 bg-status-green/5 border border-status-green/20 rounded-xl">
                                        <div className="w-2 h-2 rounded-full bg-status-green animate-pulse"></div>
                                        <span className="text-[10px] font-black text-status-green uppercase">{status}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Intentional Logs */}
                    <div className="lg:col-span-4 space-y-6">
                        <div className="bg-brand-accent/5 border border-brand-accent/20 p-8 rounded-[3rem]">
                            <h4 className="text-[10px] font-black text-brand-accent uppercase tracking-[0.3em] mb-6">Intentional Trace</h4>
                            <div className="space-y-4 text-[10px] font-mono leading-relaxed opacity-60">
                                <p>[SYSTEM] ν initialized at edge</p>
                                <p>[BRIDGE] μ detected: ASL_MODAL</p>
                                <p>[TREASURY] τ released for Phase_01</p>
                                <p>[WASM] Calculated γ = 4.2</p>
                                <p>[AUDIT] ι verified: 0.9992</p>
                                <div className="h-px bg-white/10 my-4"></div>
                                <p className="text-brand-accent font-black">σ STATUS: DEPLOYED</p>
                            </div>
                        </div>

                        <button className="w-full bg-white text-brand-dark font-black py-6 rounded-[2rem] uppercase text-[10px] tracking-[0.5em] hover:bg-brand-accent hover:text-white transition-all shadow-xl active:scale-95">
                            Re-Sync Global Ledger
                        </button>
                    </div>
                </div>
            </main>
        </div>
    );
};
