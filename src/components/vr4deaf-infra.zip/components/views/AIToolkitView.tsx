
import React from 'react';
import { Icon } from '../ui/Icon';
import { UserRole } from '../../types';
import { roleToPath, EXTERNAL_INTAKE_URL } from '../../constants';

interface AIToolkitViewProps {
  navigate: (path: string) => void;
}

const ProtocolCard = ({ icon, title, description, nodes, ctaText, ctaAction, accent = false, href }: { icon: 'lightbulb' | 'user' | 'briefcase', title: string, description: string, nodes: string[], ctaText: string, ctaAction?: () => void, accent?: boolean, href?: string }) => (
    <div className={`group relative p-10 rounded-[3rem] border transition-all flex flex-col h-full ${accent ? 'bg-brand-primary/40 border-brand-accent/30 shadow-glow-cyan' : 'bg-brand-primary/20 border-white/5 hover:border-white/20'}`}>
        <div className="flex items-center gap-5 mb-8">
            <div className={`p-4 rounded-3xl ring-1 transition-all group-hover:rotate-12 ${accent ? 'bg-brand-accent text-brand-dark ring-brand-accent/50' : 'bg-white/5 text-brand-accent ring-white/10'}`}>
                <Icon name={icon} className="w-10 h-10" />
            </div>
            <div>
                <h3 className="text-3xl font-black text-white uppercase tracking-tighter leading-none">{title}</h3>
                <span className="text-[10px] font-black text-brand-muted uppercase tracking-[0.3em]">Neural Protocol Node</span>
            </div>
        </div>
        <p className="text-brand-muted text-base font-medium mb-8 leading-relaxed">{description}</p>
        <div className="space-y-3 mb-10 flex-grow">
            {nodes.map((node, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/5">
                    <Icon name="check" className="w-4 h-4 text-brand-accent" />
                    <span className="text-xs font-bold text-brand-light uppercase tracking-widest">{node}</span>
                </div>
            ))}
        </div>
        {href ? (
            <a
                href={href}
                className={`w-full py-5 rounded-2xl font-black uppercase text-center text-xs tracking-widest transition-all hover:scale-[1.02] active:scale-95 ${accent ? 'bg-white text-brand-dark' : 'bg-brand-accent text-brand-dark shadow-glow-cyan'}`}
            >
                {ctaText}
            </a>
        ) : (
            <button
                onClick={ctaAction}
                className={`w-full py-5 rounded-2xl font-black uppercase text-xs tracking-widest transition-all hover:scale-[1.02] active:scale-95 ${accent ? 'bg-white text-brand-dark' : 'bg-brand-accent text-brand-dark shadow-glow-cyan'}`}
            >
                {ctaText}
            </button>
        )}
    </div>
);

export const AIToolkitView: React.FC<AIToolkitViewProps> = ({ navigate }) => {
    return (
        <div className="bg-[#020617] min-h-screen text-brand-light pb-20">
            <header className="relative h-[30vh] min-h-[250px] overflow-hidden flex items-center justify-center border-b border-white/5">
                <div className="absolute inset-0 z-0">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#020617] z-10"></div>
                    <div className="absolute inset-0 opacity-40 bg-grid-white/[0.02] bg-[size:40px_40px]"></div>
                </div>
                <div className="relative z-20 text-center">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-accent/5 border border-brand-accent/20 text-brand-accent text-[10px] font-black uppercase tracking-[0.4em] mb-4">
                        <Icon name="cpu-chip" className="w-3 h-3" />
                        System Extension Layer
                    </div>
                    <h1 className="text-4xl md:text-6xl font-black text-white tracking-tighter uppercase">PROTOCOL <span className="text-brand-accent">TOOLKITS</span></h1>
                </div>
            </header>

            <div className="max-w-[1400px] mx-auto px-6 -mt-12 relative z-30">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
                    <ProtocolCard
                        icon="lightbulb"
                        title="Venture Core"
                        description="Neural frameworks for business validation, competitive analysis, and strategic roadmap generation."
                        nodes={["IPE Initialization", "Market Trajectory Sync", "Venture Logic Engine", "ASL Pitch Analysis"]}
                        ctaText="Initiate Venture"
                        href={EXTERNAL_INTAKE_URL}
                    />
                    <ProtocolCard
                        icon="user"
                        accent
                        title="Node Ops"
                        description="Operational protocols for the independent professional. Invoicing, communication, and contract mapping."
                        nodes={["Visual Record Sync", "Contract Logic Mapping", "Modal Communication", "GU Balance Audit"]}
                        ctaText="Access Core Node"
                        ctaAction={() => navigate(roleToPath(UserRole.LOGIN))}
                    />
                    <ProtocolCard
                        icon="briefcase"
                        title="Career Pod"
                        description="Direct uplink to inclusive corporate nodes. Neural matching based on skill set and communication modality."
                        nodes={["Resume Modality Build", "ASL Mock Simulation", "Employer Filter Logic", "Audit Link"]}
                        ctaText="Access Career Pod"
                        ctaAction={() => navigate(roleToPath(UserRole.JOB_PLACEMENT))}
                    />
                </div>

                <div className="mt-20 p-10 bg-brand-primary/20 backdrop-blur-xl border border-white/5 rounded-[3rem] text-center">
                    <h4 className="text-[10px] font-black text-brand-accent uppercase tracking-[0.5em] mb-4">Neural-Sync Status</h4>
                    <div className="flex justify-center items-center gap-12 flex-wrap">
                        {['RSA-911 Sync: Active', 'Modality Engine: 1.4.0', 'Encryption: AES-256', 'Network Nodes: 420+'].map((stat, i) => (
                            <div key={i} className="flex items-center gap-2">
                                <div className="w-1.5 h-1.5 rounded-full bg-status-green animate-pulse"></div>
                                <span className="text-xs font-bold text-brand-muted uppercase tracking-widest">{stat}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};
