import React, { ReactNode } from 'react';
import { Icon } from '../ui/Icon';

const CodeBlock: React.FC<{ children: ReactNode }> = ({ children }) => (
    <pre className="bg-brand-dark/70 text-sm text-cyan-200 p-4 rounded-lg border border-brand-secondary overflow-x-auto">
        <code>{children}</code>
    </pre>
);

const openApiSchema = `
openapi: 3.0.0
info:
  title: VR4Deaf Service Subscription API
  description: |-
    API for managing Vocational Rehabilitation (VR) service subscriptions,
    ensuring they are directly synchronized with a client's Individualized 
    Plan for Employment (IPE). The IPE is the source of truth for all 
    services, pricing, and duration.
  version: 1.0.0

servers:
  - url: https://api.vr4deaf.org/v1
    description: Production Server

paths:
  /clients/{clientId}/ipe:
    get:
      summary: Get Client's IPE
      description: Retrieves the current active or draft IPE for a specific client.
      parameters:
        - name: clientId
          in: path
          required: true
          schema: { type: string }
      responses:
        '200':
          description: The client's IPE document.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/IPE'
    post:
      summary: Create Client IPE
      description: Creates a new IPE for a client. (Action typically for VR Counselors)
      parameters:
        - name: clientId
          in: path
          required: true
          schema: { type: string }
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/IPEInput'
      responses:
        '201':
          description: IPE created successfully.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/IPE'

  /ipes/{ipeId}/subscription:
    get:
      summary: Get IPE Subscription Status
      description: Retrieves the subscription details tied to a specific IPE.
      parameters:
        - name: ipeId
          in: path
          required: true
          schema: { type: string }
      responses:
        '200':
          description: Subscription details.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Subscription'
    post:
      summary: Activate IPE Subscription
      description: Activates the service subscription for an approved IPE. This typically follows funding authorization from the VR agency.
      parameters:
        - name: ipeId
          in: path
          required: true
          schema: { type: string }
      responses:
        '200':
          description: Subscription activated.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Subscription'

  /service-catalog:
    get:
      summary: List Available Services
      description: Returns a list of all VR-approved services and their pricing.
      responses:
        '200':
          description: A list of services.
          content:
            application/json:
              schema:
                type: array
                items:
                  $ref: '#/components/schemas/Service'

  /subscriptions/{subscriptionId}/usage:
    post:
      summary: Record Service Usage
      description: Records an instance of a service being used by a client under their active subscription. (Action typically for Vendors/Specialists)
      parameters:
        - name: subscriptionId
          in: path
          required: true
          schema: { type: string }
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServiceUsageInput'
      responses:
        '201':
          description: Service usage recorded.

components:
  schemas:
    IPE:
      type: object
      properties:
        id: { type: string, format: uuid }
        clientId: { type: string, format: uuid }
        counselorId: { type: string }
        status:
          type: string
          enum: [Draft, Pending Approval, Active, Completed, Closed]
        startDate: { type: string, format: date }
        endDate: { type: string, format: date }
        goals: { type: string }
        services:
          type: array
          items:
            $ref: '#/components/schemas/Service'
        
    IPEInput:
      type: object
      properties:
        goals: { type: string, description: "The primary goals of the IPE." }
        startDate: { type: string, format: date }
        endDate: { type: string, format: date }
        serviceIds:
          type: array
          items:
            type: string
          description: "An array of service IDs from the service catalog to include in the plan."
            
    Service:
      type: object
      properties:
        id: { type: string, format: uuid }
        name: { type: string }
        description: { type: string }
        category: { type: string }
        costUSD: { type: number, format: float }

    Subscription:
      type: object
      properties:
        id: { type: string, format: uuid }
        ipeId: { type: string, format: uuid }
        clientId: { type: string, format: uuid }
        status:
          type: string
          enum: [Inactive, Active, Completed]
        totalValueUSD: { type: number, format: float }
        remainingValueUSD: { type: number, format: float }
        startDate: { type: string, format: date }
        endDate: { type: string, format: date }
        
    ServiceUsageInput:
      type: object
      properties:
        serviceId: { type: string, format: uuid }
        vendorId: { type: string }
        dateOfService: { type: string, format: date-time }
        notes: { type: string, description: "Notes on the service provided." }
`;

const ApiDocsView: React.FC = () => {
    return (
        <div className="bg-brand-dark">
            {/* Hero Section */}
            <section className="bg-brand-primary/50 text-white py-16 px-4 text-center rounded-b-2xl">
                <div className="w-16 h-16 mx-auto mb-4 bg-brand-accent/10 rounded-full flex items-center justify-center ring-2 ring-brand-accent/30">
                    <Icon name="code-bracket" className="w-10 h-10 text-brand-accent" />
                </div>
                <h1 className="text-4xl font-extrabold tracking-tight">API & Documentation</h1>
                <p className="mt-4 text-lg text-brand-muted max-w-3xl mx-auto">Integrate with our headless platform to build custom solutions and connect services.</p>
            </section>

            {/* Main Content */}
            <section className="py-20 px-4">
                <div className="max-w-5xl mx-auto space-y-12">
                    
                    {/* Authentication Card */}
                    <div className="bg-brand-primary/50 backdrop-blur-lg p-8 rounded-2xl shadow-2xl border border-brand-secondary">
                        <h2 className="text-2xl font-bold text-white mb-4">Core Concept: IPE-Driven Subscriptions</h2>
                        <p className="text-brand-muted mb-4">
                            Our system is built on the principle that a client's services and their funding are directly tied to their <strong>Individualized Plan for Employment (IPE)</strong>. The IPE, created and approved by a VR Counselor, acts as the master agreement. Once the IPE is funded and activated, it becomes a "Subscription" that allows the client to consume the approved services from vendors within our network. This API provides the endpoints to manage this entire lifecycle.
                        </p>
                    </div>

                    {/* Endpoints Card */}
                    <div className="bg-brand-primary/50 backdrop-blur-lg p-8 rounded-2xl shadow-2xl border border-brand-secondary">
                        <h2 className="text-2xl font-bold text-white mb-4">OpenAPI 3.0 Schema</h2>
                         <p className="text-brand-muted mb-4">
                            Below is the technical schema defining the endpoints and data models for the VR Service Subscription API.
                        </p>
                        <CodeBlock>
                            {openApiSchema}
                        </CodeBlock>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default ApiDocsView;
