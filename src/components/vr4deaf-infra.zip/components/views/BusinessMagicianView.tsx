
import React, { useState } from 'react';
import { Icon, IconName } from '../ui/Icon';

const MagicianCard: React.FC<{ 
    title: string; 
    alias: string; 
    lore: string; 
    spec: string; 
    outputs: string[];
    guardedActions: string[];
    icon: IconName;
    mode: 'lore' | 'spec'
}> = ({ title, alias, lore, spec, outputs, guardedActions, icon, mode }) => (
    <div className={`p-12 border-2 transition-all flex flex-col group relative overflow-hidden clip-edge ${mode === 'lore' ? 'bg-brand-primary/40 border-brand-accent/20 hover:border-brand-accent/60 shadow-2xl' : 'bg-brand-dark/60 border-white/5 hover:border-white/20'}`}>
        <div className="absolute top-0 right-0 p-16 opacity-[0.02] group-hover:opacity-[0.06] transition-opacity pointer-events-none">
            <Icon name={icon} className="w-48 h-48 text-white" />
        </div>
        
        <div className="flex justify-between items-start mb-10 relative z-10">
            <div className={`p-5 clip-edge transition-all duration-500 ${mode === 'lore' ? 'bg-brand-accent/10 text-brand-accent ring-2 ring-brand-accent/20' : 'bg-white/5 text-brand-muted'}`}>
                <Icon name={icon} className="w-10 h-10" />
            </div>
            <div className="text-right">
                <span className="text-[10px] font-black text-brand-muted uppercase tracking-[0.4em] block mb-1">ASSET CLASS</span>
                <span className="text-xs font-black text-white uppercase tracking-widest">Neural Service Unit</span>
            </div>
        </div>

        <h3 className="text-4xl font-black text-white uppercase tracking-tighter mb-1 leading-none">{title}</h3>
        <p className="text-[11px] font-black text-brand-accent uppercase tracking-[0.3em] mb-10">{alias}</p>
        
        <div className="flex-grow mb-12 relative z-10">
            {mode === 'lore' ? (
                <div className="space-y-6">
                    <p className="text-brand-light text-xl font-bold leading-relaxed opacity-80">"{lore}"</p>
                    <div className="p-6 bg-brand-accent/5 border-l-4 border-brand-accent">
                         <p className="text-xs text-brand-muted font-bold uppercase tracking-widest">Non-Standard Overhead Conversion: This asset converts knowledge-work friction into permanent capital output.</p>
                    </div>
                </div>
            ) : (
                <div className="space-y-8 animate-fade-in-up">
                    <div>
                         <h4 className="text-[10px] font-black text-brand-accent uppercase tracking-[0.4em] mb-3">Operational Spec</h4>
                         <p className="text-brand-muted text-sm font-bold uppercase tracking-widest leading-relaxed">{spec}</p>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-3">
                            <h5 className="text-[9px] font-black text-white/30 uppercase tracking-[0.3em]">Institutional Inputs</h5>
                            {outputs.map((o, i) => (
                                <div key={i} className="flex items-center gap-3">
                                    <div className="w-1.5 h-1.5 bg-brand-accent/40 rotate-45"></div>
                                    <span className="text-[10px] font-bold text-brand-muted uppercase tracking-widest leading-tight">{o}</span>
                                </div>
                            ))}
                        </div>
                        <div className="space-y-3">
                            <h5 className="text-[9px] font-black text-status-red/40 uppercase tracking-[0.3em]">Guardrails (Never)</h5>
                            {guardedActions.map((g, i) => (
                                <div key={i} className="flex items-center gap-3">
                                    <div className="w-1.5 h-1.5 bg-status-red/30 rounded-full"></div>
                                    <span className="text-[10px] font-bold text-brand-muted/60 uppercase tracking-widest leading-tight">{g}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </div>

        <div className="pt-10 border-t border-white/5 mt-auto relative z-10 flex justify-between items-center">
             <span className="text-[10px] font-black text-brand-muted uppercase tracking-[0.5em]">Audit Score: High Integrity</span>
             <Icon name="shield-check" className="w-5 h-5 text-status-green opacity-40" />
        </div>
    </div>
);

const BusinessMagicianView: React.FC = () => {
    const [mode, setMode] = useState<'lore' | 'spec'>('lore');

    const magicians = [
        {
            title: "Creative Magician",
            alias: "The Ghost-Architect",
            lore: "A vanishing brand node. It builds visual resonance that remains after the work is done. It removes the friction of identity and makes accessibility standard.",
            spec: "Neural service unit for visual identity system generation, WCAG 2.2 color mapping, and brand asset production for Deaf founders.",
            outputs: ["Visual Narrative Specs", "Dynamic SVG Modalities", "A11y Brand Guidelines"],
            guardedActions: ["Policy Modification", "Legal Representation", "Disbursement Approval"],
            icon: "sparkles" as const
        },
        {
            title: "Developer Magician",
            alias: "The Ghost-Engineer",
            lore: "The scaffolding engine. It builds the digital workspace while the founder focuses on the vision. Systematizes manual overhead into automated capital.",
            spec: "Autonomous infrastructure node for root-mounting SaaS platforms, managing automated accessibility updates, and API lifecycle monitoring.",
            outputs: ["Root-Mount Deployments", "Immutable Node Logs", "Endpoint Compliance Sync"],
            guardedActions: ["Data Ownership Transfer", "Privacy Protocol Override", "Identity Forging"],
            icon: "code-bracket" as const
        },
        {
            title: "Job Magician",
            alias: "The Ghost-Salesman",
            lore: "Routing human energy into revenue. It identifies high-integrity placements and removes the noise. It works while the founder strategizes.",
            spec: "Revenue and employment trajectory router. Synchronizes local skill-data with federal outcome standards for VR reporting (RSA-911).",
            outputs: ["RSA-911 Data Tranches", "CIE Performance Analytics", "Outcome Projections"],
            guardedActions: ["Counselor Override", "Funding Authorization", "Ethical Gate Bypassing"],
            icon: "briefcase" as const
        }
    ];

    return (
        <div className="bg-[#020617] min-h-screen text-brand-light pb-32">
            <header className="relative py-48 px-6 text-center border-b border-white/5 overflow-hidden">
                <div className="absolute inset-0 bg-grid-white/[0.01] bg-[size:60px_60px]"></div>
                
                <div className="relative z-10">
                    <div className="inline-flex items-center gap-4 px-8 py-3 rounded-none bg-brand-primary/60 border-2 border-brand-accent/20 shadow-glow-cyan mb-16 clip-edge">
                        <div className="flex bg-black/60 p-1.5">
                            <button 
                                onClick={() => setMode('lore')}
                                className={`px-8 py-3 rounded-none text-[11px] font-black uppercase tracking-[0.4em] transition-all ${mode === 'lore' ? 'bg-brand-accent text-brand-dark shadow-glow-cyan' : 'text-brand-muted hover:text-white'}`}
                            >
                                Vision Lore
                            </button>
                            <button 
                                onClick={() => setMode('spec')}
                                className={`px-8 py-3 rounded-none text-[11px] font-black uppercase tracking-[0.4em] transition-all ${mode === 'spec' ? 'bg-brand-accent text-brand-dark shadow-glow-cyan' : 'text-brand-muted hover:text-white'}`}
                            >
                                Technical Spec
                            </button>
                        </div>
                    </div>
                    
                    <h1 className="text-8xl md:text-[11rem] font-black text-white tracking-tighter uppercase mb-12 leading-[0.8] drop-shadow-glow">THE <span className="text-brand-accent">MAGICIANS</span></h1>
                    <p className="text-brand-muted text-2xl md:text-3xl font-black uppercase tracking-[0.4em] max-w-5xl mx-auto opacity-70 leading-relaxed">
                        Knowledge work overhead converted into systematized capital.
                    </p>
                </div>
            </header>

            <section className="py-40 px-6">
                <div className="max-w-[1900px] mx-auto">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-14">
                        {magicians.map((m, i) => (
                            <MagicianCard key={i} {...m} mode={mode} />
                        ))}
                    </div>
                </div>
            </section>

            <section className="px-6 py-20">
                <div className="max-w-7xl mx-auto bg-brand-accent/5 border-2 border-brand-accent/20 p-32 rounded-none text-center relative overflow-hidden shadow-2xl clip-edge">
                    <div className="absolute inset-0 opacity-[0.02] pointer-events-none text-left p-16 font-mono text-[10px] leading-loose">
                        {`// GOVERNANCE PROTOCOL 01
if (decisionNode.isHuman()) {
    magician.execute(decisionNode.strategicTrajectory);
} else {
    magician.halt();
}`}
                    </div>
                    
                    <h2 className="text-6xl font-black text-white uppercase tracking-tighter mb-14 leading-none">Decision <span className="text-brand-accent">Governance</span></h2>
                    <p className="text-brand-muted text-3xl mb-24 leading-relaxed font-black uppercase tracking-[0.1em] opacity-80 max-w-5xl mx-auto">
                        Magicians do not lead; they execute. Humans remain the <span className="text-white underline decoration-brand-accent underline-offset-[12px] decoration-4">Strategic Decision Nodes</span>.
                    </p>
                    
                    <div className="grid md:grid-cols-3 gap-14 text-left relative z-10">
                        <div className="space-y-6 p-8 bg-brand-dark/40 border border-white/5 clip-edge">
                            <span className="text-[12px] font-black text-brand-accent uppercase tracking-[0.5em]">Protocol 01</span>
                            <h4 className="text-2xl font-black text-white uppercase tracking-widest">Set Objectives</h4>
                            <p className="text-sm text-brand-muted font-bold uppercase leading-relaxed opacity-60">The human founder defines the strategic trajectory and ethical guardrails. AI listens and maps.</p>
                        </div>
                        <div className="space-y-6 p-8 bg-brand-dark/40 border border-white/5 clip-edge">
                            <span className="text-[12px] font-black text-brand-accent uppercase tracking-[0.5em]">Protocol 02</span>
                            <h4 className="text-2xl font-black text-white uppercase tracking-widest">Asset Activation</h4>
                            <p className="text-sm text-brand-muted font-bold uppercase leading-relaxed opacity-60">Magician pods initialize as non-standard labor, converting human input into permanent capital output.</p>
                        </div>
                        <div className="space-y-6 p-8 bg-brand-dark/40 border border-white/5 clip-edge">
                            <span className="text-[12px] font-black text-brand-accent uppercase tracking-[0.5em]">Protocol 03</span>
                            <h4 className="text-2xl font-black text-white uppercase tracking-widest">Human Audit</h4>
                            <p className="text-sm text-brand-muted font-bold uppercase leading-relaxed opacity-60">The Supervisor pod verifies form integrity and authorizes GU tranches based on human approval.</p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default BusinessMagicianView;
