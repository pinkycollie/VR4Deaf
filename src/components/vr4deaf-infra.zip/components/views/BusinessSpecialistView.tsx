import React, { useState, useMemo, useEffect } from 'react';
import { Client, Milestone, MilestoneStatus, MonitoredUrl, UrlStatus, VendorRole, AuthenticatedUser, EquipmentOrder, WeeklyBriefing, UserRole } from '../../types';
import { Icon } from '../ui/Icon';
import * as api from '../../services/apiService';
import { useClients } from '../../ClientContext';
import { WeeklyBriefingCard } from '../ui/WeeklyBriefingCard';

const statusConfig = {
    [MilestoneStatus.PENDING]: { icon: 'pending' as const, color: 'text-brand-muted', borderColor: 'border-brand-muted/50' },
    [MilestoneStatus.IN_PROGRESS]: { icon: 'progress' as const, color: 'text-status-blue', borderColor: 'border-status-blue/80' },
    [MilestoneStatus.IN_REVIEW]: { icon: 'shield-exclamation' as const, color: 'text-status-yellow', borderColor: 'border-status-yellow/80' },
    [MilestoneStatus.COMPLETED]: { icon: 'check' as const, color: 'text-status-green', borderColor: 'border-status-green/80' },
    [MilestoneStatus.STUCK]: { icon: 'stuck' as const, color: 'text-status-red', borderColor: 'border-status-red/80' },
};

const urlStatusConfig = {
    [UrlStatus.PENDING]: { color: 'bg-gray-500', text: 'Pending' },
    [UrlStatus.ONLINE]: { color: 'bg-status-green', text: 'Online' },
    [UrlStatus.OFFLINE]: { color: 'bg-status-red', text: 'Offline' },
};

const orderStatusConfig = {
    'Pending Approval': { color: 'bg-status-yellow text-brand-dark', icon: 'pending' as const},
    'Approved': { color: 'bg-status-blue text-white', icon: 'check' as const},
    'Shipped': { color: 'bg-blue-400 text-brand-dark', icon: 'briefcase' as const},
    'Delivered': { color: 'bg-status-green text-white', icon: 'home' as const},
};

const ProgressBar: React.FC<{ milestones: Milestone[] }> = ({ milestones }) => {
    const completedCount = milestones.filter(m => m.status === MilestoneStatus.COMPLETED).length;
    const totalCount = milestones.length;
    const progress = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;
    
    return (
        <div>
            <div className="w-full bg-brand-dark/50 rounded-full h-2">
                <div className="bg-brand-accent h-2 rounded-full transition-all duration-500" style={{ width: `${progress}%` }}></div>
            </div>
            <p className="text-xs text-brand-muted text-right mt-1.5">{completedCount} of {totalCount} milestones complete</p>
        </div>
    );
};

interface ClientCardProps {
    client: Client;
    vendorRole: VendorRole;
    showToast: (message: string) => void;
}


const ClientCard: React.FC<ClientCardProps> = ({ client, vendorRole, showToast }) => {
    const { updateClient, addMonitoredUrl, updateMonitoredUrlStatus } = useClients();
    const [isExpanded, setIsExpanded] = useState(false);
    const [newUrlLabel, setNewUrlLabel] = useState('');
    const [newUrlLink, setNewUrlLink] = useState('');
    const [checkingStatus, setCheckingStatus] = useState<Record<string, boolean>>({});
    
    const overallStatus = useMemo(() => {
        if (client.milestones.some(m => m.status === MilestoneStatus.STUCK)) {
            return { text: 'Needs Attention', color: 'bg-status-red', icon: 'stuck' as const };
        }
        if (client.milestones.some(m => m.status === MilestoneStatus.IN_REVIEW)) {
            return { text: 'Review Required', color: 'bg-status-yellow', icon: 'shield-exclamation' as const };
        }
        const completedCount = client.milestones.filter(m => m.status === MilestoneStatus.COMPLETED).length;
        if (completedCount === client.milestones.length) {
            return { text: 'Completed', color: 'bg-status-green', icon: 'check' as const };
        }
        return { text: 'On Track', color: 'bg-status-blue', icon: 'progress' as const };
    }, [client.milestones]);

    const handleUpdateMilestoneStatus = async (milestoneId: string, status: MilestoneStatus) => {
        const updatedMilestones = client.milestones.map(m =>
            m.id === milestoneId ? { ...m, status } : m
        );
        await updateClient({ ...client, milestones: updatedMilestones });
        if (status === MilestoneStatus.COMPLETED) {
            showToast(`Milestone approved for ${client.name}.`);
        } else if (status === MilestoneStatus.IN_PROGRESS) {
            showToast(`Changes requested for ${client.name}. Client has been notified.`);
        }
    };

    const handleAddUrl = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!newUrlLabel.trim() || !newUrlLink.trim()) {
            showToast("Please provide both a label and a valid URL.");
            return;
        }
        await addMonitoredUrl(client.id, newUrlLabel, newUrlLink);
        setNewUrlLabel('');
        setNewUrlLink('');
    };

    const handleCheckStatus = async (url: MonitoredUrl) => {
        setCheckingStatus(prev => ({...prev, [url.id]: true}));
        try {
            const status = await api.checkUrlStatus(url.url);
            await updateMonitoredUrlStatus(client.id, url.id, status);
            if(status === UrlStatus.OFFLINE) {
                showToast(`Alert: "${url.label}" for ${client.name} appears to be offline!`);
            } else {
                 showToast(`"${url.label}" is online.`);
            }
        } catch (error) {
            console.error(`Failed to check URL status for ${url.url}:`, error);
            showToast(`Error checking status for "${url.label}".`);
        } finally {
            setCheckingStatus(prev => ({...prev, [url.id]: false}));
        }
    };

    return (
        <div className="bg-brand-primary/50 backdrop-blur-lg rounded-2xl shadow-2xl border border-brand-secondary overflow-hidden transition-all duration-300">
            <div className="p-6 cursor-pointer hover:bg-brand-secondary/30" onClick={() => setIsExpanded(!isExpanded)}>
                <div className="flex justify-between items-start">
                    <div>
                        <h3 className="text-xl font-bold text-brand-light">{client.name}</h3>
                        <p className="text-sm text-brand-muted">{client.businessIdea}</p>
                    </div>
                    <div className={`flex items-center gap-2 text-xs font-bold text-white px-3 py-1 rounded-full ${overallStatus.color}`}>
                        <Icon name={overallStatus.icon} className="w-4 h-4" />
                        <span>{overallStatus.text}</span>
                    </div>
                </div>
                {vendorRole !== VendorRole.ASSISTIVE_TECH && (
                    <div className="mt-4">
                        <ProgressBar milestones={client.milestones} />
                    </div>
                )}
                 {vendorRole === VendorRole.COACH && (
                    <button className="text-sm mt-4 w-full bg-brand-accent/20 text-brand-accent font-semibold py-2 rounded-lg hover:bg-brand-accent/40 transition-colors">
                        Schedule Coaching Session
                    </button>
                 )}
            </div>
            {isExpanded && (
                <div className="bg-brand-dark/30 px-6 pb-6 pt-4 border-t border-brand-secondary/50">
                    { vendorRole === VendorRole.ASSISTIVE_TECH ? (
                        <div className="pt-4 mt-4">
                             <h4 className="font-bold text-brand-accent mb-3">Equipment Orders</h4>
                            <div className="space-y-3">
                                {(client.equipmentOrders && client.equipmentOrders.length > 0) ? (
                                    client.equipmentOrders.map(order => (
                                         <div key={order.id} className="flex items-center justify-between bg-brand-dark/40 p-3 rounded-lg border border-brand-secondary/70">
                                             <div>
                                                 <p className="font-semibold text-brand-light">{order.itemName}</p>
                                                 <p className="text-xs text-brand-muted">Ordered: {order.date}</p>
                                             </div>
                                             <span className={`text-xs font-bold px-2 py-0.5 rounded-full flex items-center gap-1.5 ${orderStatusConfig[order.status].color}`}>
                                                <Icon name={orderStatusConfig[order.status].icon} className="w-3.5 h-3.5" />
                                                {order.status}
                                            </span>
                                         </div>
                                    ))
                                ) : <p className="text-sm text-center text-brand-muted py-2">No equipment orders for this client.</p>}
                            </div>
                        </div>
                    ) : (
                        <>
                             {/* Milestones */}
                            <h4 className="font-bold text-brand-accent mb-3">Milestone Verification</h4>
                            <div className="space-y-2 mb-4">
                                {client.milestones.map(m => (
                                    <div key={m.id} className={`text-sm p-3 rounded-md bg-brand-dark/40 border-l-4 ${statusConfig[m.status].borderColor}`}>
                                        <div className="flex items-center justify-between">
                                            <span className="text-brand-light">{m.title}</span>
                                            <div className={`flex items-center gap-2 font-semibold ${statusConfig[m.status].color}`}>
                                                <Icon name={statusConfig[m.status].icon} className="w-5 h-5" />
                                                <span>{m.status}</span>
                                            </div>
                                        </div>
                                        {m.status === MilestoneStatus.IN_REVIEW && (
                                            <div className="mt-2 pt-2 border-t border-brand-secondary/50 flex gap-2 justify-end">
                                                <button onClick={() => handleUpdateMilestoneStatus(m.id, MilestoneStatus.COMPLETED)} className="text-xs bg-status-green/80 hover:bg-status-green text-white font-semibold py-1 px-3 rounded-md transition-colors">Approve</button>
                                                <button onClick={() => handleUpdateMilestoneStatus(m.id, MilestoneStatus.IN_PROGRESS)} className="text-xs bg-status-yellow/80 hover:bg-status-yellow text-brand-dark font-semibold py-1 px-3 rounded-md transition-colors">Request Changes</button>
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>

                            {/* URL Monitoring */}
                            <div className="pt-4 mt-4 border-t border-brand-secondary/50">
                                 <h4 className="font-bold text-brand-accent mb-3">URL Monitoring</h4>
                                 <div className="space-y-3">
                                    {client.monitoredUrls && client.monitoredUrls.length > 0 ? (
                                        client.monitoredUrls.map(url => (
                                            <div key={url.id} className="flex items-center justify-between bg-brand-dark/40 p-3 rounded-lg border border-brand-secondary/70">
                                                <div className="flex items-center gap-3">
                                                    <Icon name="link" className="w-5 h-5 text-brand-muted" />
                                                    <div>
                                                        <a href={url.url} target="_blank" rel="noopener noreferrer" className="font-semibold text-brand-light hover:underline">{url.label}</a>
                                                        <p className="text-xs text-brand-muted truncate">{url.url}</p>
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-3">
                                                    <span className={`text-xs font-bold text-white px-2 py-0.5 rounded-full flex items-center gap-1.5 ${urlStatusConfig[url.status].color}`}>
                                                        <span className="w-2 h-2 rounded-full bg-white/50"></span>
                                                        {urlStatusConfig[url.status].text}
                                                    </span>
                                                    <button onClick={() => handleCheckStatus(url)} disabled={checkingStatus[url.id]} className="text-xs bg-brand-secondary hover:bg-brand-accent/80 hover:text-brand-dark text-brand-light font-semibold px-3 py-1 rounded-md transition disabled:opacity-50 disabled:cursor-wait">
                                                        {checkingStatus[url.id] ? 'Checking...' : 'Check'}
                                                    </button>
                                                </div>
                                            </div>
                                        ))
                                    ) : <p className="text-sm text-center text-brand-muted py-2">No URLs being monitored.</p>}
                                 </div>
                                 <form onSubmit={handleAddUrl} className="mt-4 space-y-2">
                                     <p className="text-sm font-semibold text-brand-light">Add URL to monitor:</p>
                                     <div className="flex gap-2">
                                         <input type="text" placeholder="Label (e.g. Website)" value={newUrlLabel} onChange={e => setNewUrlLabel(e.target.value)} className="flex-grow w-full px-3 py-1.5 bg-brand-dark border border-brand-secondary rounded-md text-sm focus:ring-brand-accent focus:border-brand-accent"/>
                                         <input type="url" placeholder="https://example.com" value={newUrlLink} onChange={e => setNewUrlLink(e.target.value)} className="flex-grow w-full px-3 py-1.5 bg-brand-dark border border-brand-secondary rounded-md text-sm focus:ring-brand-accent focus:border-brand-accent"/>
                                         <button type="submit" className="text-sm bg-brand-accent hover:bg-cyan-300 text-brand-dark font-semibold py-1.5 px-4 rounded-md transition-colors">Add</button>
                                     </div>
                                 </form>
                            </div>
                        </>
                    )}
                </div>
            )}
        </div>
    )
}

interface BusinessSpecialistViewProps {
    showToast: (message: string) => void;
    currentUser: AuthenticatedUser;
}


export const BusinessSpecialistView: React.FC<BusinessSpecialistViewProps> = ({ showToast, currentUser }) => {
    const { clients } = useClients();
    const vendorRole = currentUser.vendorRole || VendorRole.SPECIALIST;
    const [briefing, setBriefing] = useState<WeeklyBriefing | null>(null);
    const [isBriefingLoading, setIsBriefingLoading] = useState(true);

    useEffect(() => {
        const fetchBriefing = async () => {
            if (clients.length > 0) {
                setIsBriefingLoading(true);
                try {
                    const generatedBriefing = await api.generateWeeklyBriefing(UserRole.BUSINESS_SPECIALIST, clients);
                    setBriefing(generatedBriefing);
                } catch (error) {
                    console.error("Failed to generate weekly briefing:", error);
                    showToast("Error: Could not load AI briefing.");
                } finally {
                    setIsBriefingLoading(false);
                }
            } else {
                setBriefing(null);
                setIsBriefingLoading(false);
            }
        };
        fetchBriefing();
    }, [clients, showToast]);

    const dashboardTitle = {
        [VendorRole.COACH]: "Coaching Dashboard",
        [VendorRole.SPECIALIST]: "Client Progress Dashboard",
        [VendorRole.CONSULTANT]: "Consultant Dashboard",
        [VendorRole.PROVIDER]: "Service Provider Dashboard",
        [VendorRole.ASSISTIVE_TECH]: "Assistive Tech Orders",
        [VendorRole.EMPLOYMENT_NETWORK]: "Placement Network Dashboard",
    }[vendorRole];
    
    return (
        <div className="p-4 sm:p-8 space-y-8">
             <WeeklyBriefingCard
                title="VURI™ Caseload Briefing"
                briefing={briefing}
                isLoading={isBriefingLoading}
            />
            <div>
                <h2 className="text-3xl font-bold text-white mb-6">{dashboardTitle}</h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                    {clients.map(client => (
                        <ClientCard 
                            key={client.id}
                            client={client}
                            vendorRole={vendorRole}
                            showToast={showToast}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
};
