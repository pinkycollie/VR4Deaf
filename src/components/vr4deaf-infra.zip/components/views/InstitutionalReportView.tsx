
import React, { useState, useEffect } from 'react';
import { Icon } from '../ui/Icon';
import { Client } from '../../types';
import * as api from '../../services/apiService';
import { useClients } from '../../ClientContext';

export const InstitutionalReportView: React.FC = () => {
    const { clients } = useClients();
    const [selectedClient, setSelectedClient] = useState<Client | null>(clients[0] || null);
    const [report, setReport] = useState<{ body: string; meta: any } | null>(null);
    const [isGenerating, setIsGenerating] = useState(false);

    const handleGenerate = async () => {
        if (!selectedClient) return;
        setIsGenerating(true);
        try {
            const result = await api.generateInstitutionalReport(selectedClient);
            setReport({ body: result.reportBody, meta: result.metadata });
        } catch (e) {
            console.error(e);
        } finally {
            setIsGenerating(false);
        }
    };

    return (
        <div className="bg-[#F8FAFC] min-h-screen text-slate-900 pb-32 font-sans selection:bg-brand-accent/10">
            {/* Control Panel Header */}
            <header className="bg-white border-b border-slate-200 pt-32 pb-20 px-6 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1.5 bg-brand-primary"></div>
                <div className="max-w-4xl mx-auto relative z-10">
                    <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded bg-[#0A2F5E] text-white text-[10px] font-black uppercase tracking-[0.4em] mb-10 shadow-sm">
                        <Icon name="document-text" className="w-4 h-4" />
                        Outcome Synthesis Engine v3.4 [WASM-VERIFIED]
                    </div>
                    <h1 className="text-5xl md:text-7xl font-display font-black text-[#0A2F5E] tracking-tight mb-8 uppercase leading-none">
                        Success <span className="text-brand-accent">Artifact.</span>
                    </h1>
                    
                    <div className="flex flex-col sm:flex-row gap-6 mt-12">
                        <div className="flex-grow">
                             <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-3">Target Node (Client Identity)</label>
                             <select 
                                value={selectedClient?.id} 
                                onChange={(e) => setSelectedClient(clients.find(c => c.id === e.target.value) || null)}
                                className="w-full bg-slate-50 border-2 border-slate-200 rounded-xl px-5 py-4 font-bold text-[#0A2F5E] outline-none focus:border-brand-accent transition-all cursor-pointer"
                             >
                                {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                             </select>
                        </div>
                        <div className="flex items-end">
                            <button 
                                onClick={handleGenerate}
                                disabled={isGenerating || !selectedClient}
                                className="w-full sm:w-auto bg-[#0A2F5E] text-white font-black py-4 px-12 rounded-xl uppercase text-[10px] tracking-widest hover:bg-brand-secondary active:scale-95 transition-all shadow-federal flex items-center justify-center gap-3"
                            >
                                {isGenerating ? <Icon name="cog" className="w-5 h-5 animate-spin" /> : <Icon name="sparkles" className="w-5 h-5" />}
                                {isGenerating ? 'Synthesizing...' : 'Generate 360-Proof Report'}
                            </button>
                        </div>
                    </div>
                </div>
            </header>

            {/* Generated Report Display */}
            <main className="max-w-6xl mx-auto px-6 py-20">
                {!report && !isGenerating && (
                    <div className="text-center py-32 opacity-20">
                        <Icon name="document-text" className="w-24 h-24 mx-auto mb-8" />
                        <p className="text-2xl font-display font-black uppercase tracking-tighter">Awaiting Signal for Institutional Synthesis</p>
                    </div>
                )}

                {isGenerating && (
                    <div className="max-w-4xl mx-auto space-y-12">
                        <div className="h-8 bg-slate-200 rounded w-1/3 animate-pulse"></div>
                        <div className="space-y-4">
                            <div className="h-4 bg-slate-200 rounded w-full animate-pulse"></div>
                            <div className="h-4 bg-slate-200 rounded w-5/6 animate-pulse"></div>
                            <div className="h-4 bg-slate-200 rounded w-full animate-pulse"></div>
                        </div>
                        <div className="h-64 bg-slate-200 rounded w-full animate-pulse"></div>
                    </div>
                )}

                {report && (
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
                        {/* Authentic Metadata Sidebar */}
                        <div className="lg:col-span-3 space-y-6 lg:sticky lg:top-32">
                             <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                                <h3 className="text-[10px] font-black text-brand-accent uppercase tracking-[0.3em] mb-6">Artifact Metadata</h3>
                                <div className="space-y-6">
                                    <div>
                                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Logic Engine</span>
                                        <p className="text-xs font-mono font-bold text-[#0A2F5E]">VURI™ WASM CORE v1.0</p>
                                    </div>
                                    <div>
                                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Integrity Hash</span>
                                        <p className="text-xs font-mono font-bold text-brand-accent break-all">{report.meta.integrityHash}</p>
                                    </div>
                                    <div>
                                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Compliance</span>
                                        <p className="text-xs font-bold text-status-green uppercase">RSA-911 AUTHORIZED</p>
                                    </div>
                                </div>
                             </div>

                             <div className="p-6 bg-brand-primary text-white rounded-3xl shadow-federal">
                                 <Icon name="shield-check" className="w-8 h-8 text-brand-gold mb-4" />
                                 <p className="text-[9px] font-black text-white/50 uppercase tracking-[0.2em] mb-2">Provenance</p>
                                 <p className="text-xs font-bold leading-relaxed uppercase tracking-tight">
                                     Every calculation in this artifact was executed in a secure WebAssembly environment.
                                 </p>
                             </div>
                        </div>

                        {/* Report Content Container */}
                        <div className="lg:col-span-9 bg-white border border-slate-200 shadow-2xl rounded-[3rem] p-12 md:p-20 relative overflow-hidden">
                            <div className="prose prose-slate max-w-none">
                                <div className="mb-20 border-b border-slate-200 pb-12">
                                    <div className="flex justify-between items-start mb-6">
                                        <div>
                                            <h2 className="text-[10px] font-black text-brand-accent uppercase tracking-[0.5em] mb-4">Official Technical Publication</h2>
                                            <h3 className="text-4xl font-display font-black text-[#0A2F5E] uppercase tracking-tight leading-none mb-4">
                                                360-Proof Outcome Summary
                                            </h3>
                                        </div>
                                        <div className="text-right">
                                            <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Artifact ID</span>
                                            <p className="text-xs font-mono font-bold text-[#0A2F5E]">{report.meta.reportId}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-4 text-xs font-bold text-slate-400 uppercase tracking-widest">
                                        <span>Node: {selectedClient?.name}</span>
                                        <span className="w-1 h-1 rounded-full bg-slate-200"></span>
                                        <span>Verified: {new Date(report.meta.timestamp).toLocaleDateString()}</span>
                                    </div>
                                </div>

                                <div className="text-xl leading-relaxed text-slate-700 font-medium whitespace-pre-wrap font-serif first-letter:text-5xl first-letter:font-black first-letter:text-[#0A2F5E] first-letter:mr-3 first-letter:float-left">
                                    {report.body}
                                </div>

                                <div className="mt-20 pt-12 border-t border-slate-100 flex flex-col md:flex-row justify-between items-end gap-8">
                                    <div className="flex items-center gap-4 p-6 bg-slate-50 rounded-3xl border border-slate-200 w-full md:w-auto">
                                        <div className="w-12 h-12 bg-brand-primary text-white flex items-center justify-center rounded-2xl font-black">
                                            WP
                                        </div>
                                        <div>
                                            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Authorizing Mesh</p>
                                            <p className="text-sm font-black text-brand-primary uppercase tracking-tight">VR4DEAF NATIONAL NODE</p>
                                        </div>
                                    </div>
                                    <div className="text-right w-full md:w-auto">
                                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Cryptographic Signature</p>
                                         <div className="p-5 bg-slate-900 rounded-2xl font-mono text-[11px] text-cyan-400 border border-slate-800 shadow-inner">
                                             -----BEGIN VURI PGP SIGNATURE-----<br/>
                                             Version: VURI_OS_3.4.0<br/>
                                             Hash: SHA256<br/>
                                             iQIcBAEBCAAGBQJmR7S5AAoJECvB3xM...<br/>
                                             -----END VURI PGP SIGNATURE-----
                                         </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
};
