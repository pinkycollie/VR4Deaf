
import React, { useState } from 'react';
import { UserRole, VendorRole } from '../../types';
import { Icon } from '../ui/Icon';
import { Logo } from '../ui/Logo';

interface AuthViewProps {
    defaultTab: 'signIn' | 'signUp';
    onLogin: (email: string, password: string) => Promise<void>;
    onSignUp: (name: string, email: string, password: string, role: UserRole.VR_PARTNER | UserRole.ENTREPRENEUR | UserRole.BUSINESS_SPECIALIST, vendorRole?: VendorRole) => Promise<void>;
    showToast: (message: string) => void;
    navigate: (path: string) => void;
}

const AuthView: React.FC<AuthViewProps> = ({ defaultTab, onLogin, onSignUp, showToast, navigate }) => {
    const [activeTab, setActiveTab] = useState(defaultTab);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [name, setName] = useState('');
    const [primaryRole, setPrimaryRole] = useState<UserRole.VR_PARTNER | UserRole.ENTREPRENEUR | UserRole.BUSINESS_SPECIALIST>(UserRole.ENTREPRENEUR);
    const [quickLoginLoading, setQuickLoginLoading] = useState<string | null>(null);

    const handleQuickLogin = async (loginEmail: string, roleId: string) => {
        setQuickLoginLoading(roleId);
        try {
            await onLogin(loginEmail, 'password123');
        } catch (e) {
            showToast("VAULT CONNECTION ERROR.");
        } finally {
            setQuickLoginLoading(null);
        }
    };

    const QuickLoginButton = ({ email, roleId, label }: { email: string, roleId: string, label: string }) => (
         <button 
            onClick={() => handleQuickLogin(email, roleId)} 
            disabled={!!quickLoginLoading} 
            className="flex-1 min-w-[130px] bg-brand-primary/60 backdrop-blur-md p-6 rounded-[2.5rem] border border-white/5 hover:border-brand-accent/50 transition-all flex flex-col items-center justify-center h-32 gap-2 group relative overflow-hidden"
        >
            <div className="absolute inset-0 bg-brand-accent/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <span className="text-[8px] font-black text-brand-muted uppercase tracking-[0.5em] group-hover:text-brand-accent transition-colors relative z-10">BYPASS NODE</span>
            <span className="text-xs font-black text-white uppercase text-center leading-tight tracking-[0.2em] relative z-10">
                {quickLoginLoading === roleId ? <Icon name="cog" className="w-5 h-5 animate-spin text-brand-accent" /> : label}
            </span>
        </button>
    );

    return (
        <div className="min-h-screen flex flex-col items-center justify-center py-24 px-6 bg-brand-dark">
            <div className="text-center mb-16 animate-fade-in-up">
                <div className="inline-block p-6 bg-white/5 border border-white/10 rounded-[2.8rem] shadow-glow-cyan mb-10 transform hover:scale-105 transition-transform">
                    <Logo className="h-20 w-auto" />
                </div>
                <h1 className="text-5xl md:text-6xl font-black text-white uppercase tracking-tighter mb-3">VAULT <span className="text-brand-accent">LOGIN</span></h1>
                <p className="text-brand-gold font-bold tracking-[0.6em] uppercase text-[10px] animate-pulse">VERIFYING NODE INTEGRITY...</p>
            </div>
            
            <div className="w-full max-w-xl">
                <div className="bg-brand-primary/40 backdrop-blur-3xl rounded-[4rem] border border-white/10 p-4 shadow-2xl relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-brand-accent/5 to-transparent pointer-events-none"></div>
                    
                    <div className="flex bg-black/50 rounded-[3.5rem] p-2.5 mb-6 relative z-10">
                        <button onClick={() => setActiveTab('signIn')} className={`flex-1 py-6 rounded-[3rem] text-[11px] font-black uppercase tracking-[0.4em] transition-all ${activeTab === 'signIn' ? 'bg-brand-accent text-brand-dark shadow-glow-cyan' : 'text-brand-muted hover:text-white'}`}>
                            SYNC NODE
                        </button>
                        <button onClick={() => setActiveTab('signUp')} className={`flex-1 py-6 rounded-[3rem] text-[11px] font-black uppercase tracking-[0.4em] transition-all ${activeTab === 'signUp' ? 'bg-brand-gold text-brand-dark shadow-glow-gold' : 'text-brand-muted hover:text-white'}`}>
                            INITIALIZE
                        </button>
                    </div>

                    <div className="p-10 relative z-10">
                        <form onSubmit={(e) => { e.preventDefault(); activeTab === 'signIn' ? onLogin(email, password) : onSignUp(name, email, password, primaryRole); }} className="space-y-8">
                            {activeTab === 'signUp' && (
                                <input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full px-8 py-6 bg-brand-dark/60 border border-white/10 rounded-2xl text-white font-black tracking-widest focus:border-brand-gold outline-none text-sm placeholder:text-brand-muted/30" placeholder="SUBJECT NAME" required />
                            )}
                            <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full px-8 py-6 bg-brand-dark/60 border border-white/10 rounded-2xl text-white font-black tracking-widest focus:border-brand-accent outline-none text-sm placeholder:text-brand-muted/30" placeholder="SECURE EMAIL PATH" required />
                            <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full px-8 py-6 bg-brand-dark/60 border border-white/10 rounded-2xl text-white font-black tracking-widest focus:border-brand-accent outline-none text-sm placeholder:text-brand-muted/30" placeholder="VAULT PASSWORD" required />
                            
                            <button type="submit" disabled={isLoading} className={`w-full font-black py-7 rounded-[3rem] uppercase text-xs tracking-[0.5em] transition-all hover:scale-[1.03] active:scale-95 shadow-xl ${activeTab === 'signIn' ? 'bg-white text-brand-dark' : 'bg-brand-gold text-brand-dark shadow-glow-gold'}`}>
                                {activeTab === 'signIn' ? 'AUTHENTICATE UPLINK' : 'EXECUTE INITIALIZATION'}
                            </button>
                        </form>
                    </div>
                </div>
                 
                 {activeTab === 'signIn' && (
                    <div className="mt-24 w-full animate-fade-in-up">
                        <div className="text-center text-[11px] font-black text-brand-muted uppercase tracking-[0.7em] mb-12 opacity-60">DEMO ACCESS NODES</div>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-8">
                            <QuickLoginButton email="partner@vr4deaf.org" roleId="p" label="AGENCY" />
                            <QuickLoginButton email="counselor@vr4deaf.org" roleId="c" label="COUNSELOR" />
                            <QuickLoginButton email="entrepreneur@vr4deaf.org" roleId="f" label="FOUNDER" />
                            <QuickLoginButton email="specialist@vr4deaf.org" roleId="s" label="SPECIALIST" />
                        </div>
                    </div>
                 )}
            </div>
        </div>
    );
};

export default AuthView;
