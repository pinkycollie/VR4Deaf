
import React, { useState, useEffect } from 'react';
import { Icon } from '../ui/Icon';
import * as api from '../../services/apiService';
import { EXTERNAL_INTAKE_URL } from '../../constants';
import { StateDetails, StateAnalytics } from '../../types';

interface StateDetailViewProps {
    stateName: string;
    onBack: () => void;
}

const AnalyticsCard: React.FC<{ label: string; value: string | number; icon: any; color: string }> = ({ label, value, icon, color }) => (
    <div className="bg-white border border-slate-200 p-6 rounded-2xl shadow-sm flex items-center gap-5 group hover:border-brand-accent transition-all">
        <div className={`p-3 rounded-xl bg-slate-50 ${color}`}>
            <Icon name={icon} className="w-5 h-5" />
        </div>
        <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-2">{label}</p>
            <p className="text-xl font-display font-black text-slate-900">{value}</p>
        </div>
    </div>
);

export const StateDetailView: React.FC<StateDetailViewProps> = ({ stateName, onBack }) => {
    const [details, setDetails] = useState<StateDetails | null>(null);
    const [analytics, setAnalytics] = useState<StateAnalytics | null>(null);
    const [nearbyOffices, setNearbyOffices] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isSearchingOffices, setIsSearchingOffices] = useState(false);

    useEffect(() => {
        const fetchDetails = async () => {
            setIsLoading(true);
            const [data, stats] = await Promise.all([
                api.getStateDetails(stateName),
                api.getStateAnalytics(stateName)
            ]);
            setDetails(data);
            setAnalytics(stats);
            setIsLoading(false);
            
            // Grounded real-world office search
            setIsSearchingOffices(true);
            navigator.geolocation.getCurrentPosition(async (pos) => {
                const offices = await api.findNearbyOffices(stateName, pos.coords.latitude, pos.coords.longitude);
                setNearbyOffices(offices);
                setIsSearchingOffices(false);
            }, async () => {
                const offices = await api.findNearbyOffices(stateName);
                setNearbyOffices(offices);
                setIsSearchingOffices(false);
            });
        };
        fetchDetails();
    }, [stateName]);

    if (isLoading) {
        return (
            <div className="min-h-screen bg-[#F8FAFC] flex flex-col items-center justify-center">
                <Icon name="cog" className="w-16 h-16 text-brand-primary animate-spin mb-6" />
                <p className="text-slate-400 font-black uppercase tracking-[0.4em] text-xs">Accessing {stateName} Node...</p>
            </div>
        );
    }

    if (!details) return null;

    return (
        <div className="bg-[#F8FAFC] min-h-screen text-slate-800 pb-32 font-sans selection:bg-brand-accent/10">
            <header className="bg-white border-b border-slate-200 pt-32 pb-24 px-6 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1.5 bg-brand-primary"></div>
                <div className="max-w-6xl mx-auto">
                    <button 
                        onClick={onBack}
                        className="inline-flex items-center gap-2 text-[10px] font-black text-brand-accent uppercase tracking-widest mb-10 hover:underline"
                    >
                        <Icon name="back-arrow" className="w-4 h-4" />
                        Return to Directory
                    </button>
                    
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-8">
                        <div>
                            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-100 border border-slate-200 text-slate-500 text-[10px] font-black uppercase tracking-widest mb-6">
                                <Icon name="map" className="w-3.5 h-3.5" />
                                Regional Node Identifier: {stateName}
                            </div>
                            <h1 className="text-5xl md:text-7xl font-display font-black text-[#0A2F5E] tracking-tight uppercase leading-none">
                                {details.programName}
                            </h1>
                        </div>
                        <div className="flex flex-col items-end">
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-2">Node Status</span>
                            <div className="flex items-center gap-2 px-4 py-2 bg-status-green/10 text-status-green rounded-xl border border-status-green/20">
                                <div className="w-2 h-2 rounded-full bg-status-green animate-pulse"></div>
                                <span className="text-xs font-black uppercase tracking-widest">Active & Sync'd</span>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <main className="max-w-6xl mx-auto px-6 py-12">
                {/* Analytics Mesh */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
                    <AnalyticsCard label="CIE Success Rate" value={`${analytics?.placementRate}%`} icon="check-badge" color="text-status-green" />
                    <AnalyticsCard label="Active Tranches" value={analytics?.activeTranches || 0} icon="currency-dollar" color="text-brand-accent" />
                    <AnalyticsCard label="Placement Velocity" value={`${analytics?.avgVelocityDays} Days`} icon="rocket-launch" color="text-brand-primary" />
                    <AnalyticsCard label="Audit Standard" value={analytics?.complianceRating || 'Optimal'} icon="shield-check" color="text-blue-600" />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
                    <div className="lg:col-span-8 space-y-16">
                        <section>
                            <h2 className="text-xs font-black text-brand-accent uppercase tracking-[0.4em] mb-8">System Overview</h2>
                            <p className="text-xl text-slate-600 font-bold leading-relaxed uppercase tracking-tight opacity-90">
                                {details.description}
                            </p>
                        </section>

                        {/* Grounded Nearby Offices */}
                        <section className="bg-slate-900 text-white rounded-[3rem] p-12 shadow-2xl relative overflow-hidden">
                             <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
                                <Icon name="map" className="w-64 h-64 text-brand-accent" />
                            </div>
                            <h2 className="text-xs font-black text-brand-accent uppercase tracking-[0.4em] mb-8 relative z-10">Real-World Authorized Nodes (Nearby)</h2>
                            {isSearchingOffices ? (
                                <div className="flex items-center gap-4 animate-pulse">
                                    <Icon name="magnifying-glass" className="w-6 h-6 text-brand-gold animate-bounce" />
                                    <span className="text-xs font-bold uppercase tracking-widest text-slate-400">Querying Google Maps Grounding...</span>
                                </div>
                            ) : (
                                <div className="space-y-6 relative z-10">
                                    {nearbyOffices.length > 0 ? nearbyOffices.map((office, i) => (
                                        <div key={i} className="p-6 bg-white/5 border border-white/10 rounded-2xl group hover:border-brand-accent/50 transition-all">
                                            <div className="flex justify-between items-center">
                                                <h4 className="text-lg font-black uppercase tracking-tight text-white">{office.web?.title || 'VR Office Node'}</h4>
                                                <Icon name="check-badge" className="w-5 h-5 text-status-green" />
                                            </div>
                                            <p className="text-xs text-slate-400 font-bold mt-2 uppercase tracking-widest">{office.web?.uri || 'Authorized State Address'}</p>
                                        </div>
                                    )) : (
                                        <p className="text-xs font-bold text-slate-500 uppercase italic">Using state root office provided in metadata.</p>
                                    )}
                                </div>
                            )}
                        </section>

                        <section className="bg-white rounded-[3rem] border border-slate-200 p-12 shadow-sm">
                            <h2 className="text-xs font-black text-[#0A2F5E] uppercase tracking-[0.4em] mb-12 text-center">National Success Tranches</h2>
                            <div className="space-y-12">
                                {details.successStories.map((story, idx) => (
                                    <div key={idx} className="group relative">
                                        <div className="flex gap-8">
                                            <div className="flex-shrink-0 w-12 h-12 bg-[#0A2F5E] text-white flex items-center justify-center rounded-2xl font-black text-sm shadow-federal">
                                                0{idx + 1}
                                            </div>
                                            <div>
                                                <h3 className="text-2xl font-black text-[#0A2F5E] uppercase tracking-tighter mb-4 group-hover:text-brand-accent transition-colors">{story.title}</h3>
                                                <p className="text-slate-500 font-medium leading-relaxed mb-6 italic opacity-80">"{story.story}"</p>
                                                <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between">
                                                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Protocol Outcome</span>
                                                    <span className="text-xs font-black text-status-green uppercase">{story.outcome}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </section>
                    </div>

                    <div className="lg:col-span-4 space-y-8">
                        <div className="bg-[#0A2F5E] text-white p-10 rounded-[3.5rem] shadow-federal relative overflow-hidden">
                            <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
                                <Icon name="shield-check" className="w-64 h-64 text-brand-gold" />
                            </div>
                            <h3 className="text-[10px] font-black text-brand-gold uppercase tracking-[0.3em] mb-10 relative z-10">Uplink Gateway</h3>
                            <div className="space-y-8 relative z-10">
                                <div>
                                    <p className="text-[9px] font-black text-white/40 uppercase tracking-widest mb-1">Official Website</p>
                                    <a href={details.contactInfo.website} target="_blank" rel="noopener noreferrer" className="text-sm font-bold hover:text-brand-accent transition-colors break-all underline underline-offset-4">{details.contactInfo.website}</a>
                                </div>
                                <div>
                                    <p className="text-[9px] font-black text-white/40 uppercase tracking-widest mb-1">Regional Comms</p>
                                    <p className="text-sm font-bold">{details.contactInfo.phone}</p>
                                    <p className="text-sm font-bold mt-1">{details.contactInfo.email}</p>
                                </div>
                                <div>
                                    <p className="text-[9px] font-black text-white/40 uppercase tracking-widest mb-1">Office Root</p>
                                    <p className="text-sm font-bold leading-relaxed">{details.contactInfo.officeAddress}</p>
                                </div>
                            </div>
                            <div className="mt-12 pt-10 border-t border-white/10 relative z-10">
                                <a 
                                    href={EXTERNAL_INTAKE_URL}
                                    className="w-full bg-white text-[#0A2F5E] font-black py-5 rounded-2xl uppercase text-[10px] tracking-widest text-center block hover:bg-brand-gold hover:text-white transition-all shadow-xl"
                                >
                                    Initialize State Intake
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};
