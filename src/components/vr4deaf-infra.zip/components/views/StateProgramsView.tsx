
import React from 'react';
import { Icon } from '../ui/Icon';
import { US_STATES, slugifyState, roleToPath, STATS_TRUTH } from '../../constants';
import { UserRole } from '../../types';

interface StateProgramsViewProps {
    showToast: (message: string) => void;
    navigate: (path: string) => void;
}

export const StateProgramsView: React.FC<StateProgramsViewProps> = ({ showToast, navigate }) => {

    const handleStateClick = (state: string) => {
        const slug = slugifyState(state);
        const basePath = roleToPath(UserRole.STATE_PROGRAMS);
        navigate(`${basePath}/${slug}`);
    };

    return (
        <div className="text-slate-800 font-sans bg-[#F8FAFC] min-h-screen pb-32 overflow-x-hidden selection:bg-brand-accent/10">
            {/* Institutional Hero */}
            <section className="relative pt-32 pb-24 px-6 overflow-hidden text-center border-b border-slate-200 bg-white">
                <div className="max-w-6xl mx-auto relative z-10">
                    <div className="inline-flex items-center gap-3 px-5 py-2 rounded bg-brand-primary text-white text-[10px] font-black uppercase tracking-[0.4em] mb-10 shadow-sm">
                        <Icon name="map" className="w-4 h-4" />
                        National Support Mesh Index
                    </div>
                    
                    <h1 className="text-5xl md:text-8xl font-display font-black text-[#0A2F5E] tracking-tighter uppercase mb-8">
                        NATIONAL <span className="text-brand-accent">DIRECTORY.</span>
                    </h1>
                    
                    <p className="text-xl md:text-2xl text-slate-500 font-bold max-w-3xl mx-auto leading-relaxed uppercase tracking-tight opacity-80 mb-16">
                        Vocational Rehabilitation agencies in all 50 states synchronized for Deaf-first workforce infrastructure.
                    </p>

                    {/* National Ledger Mesh */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
                        <div className="bg-slate-50 border border-slate-200 p-8 rounded-3xl text-left">
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Aggregate CIE Placements</span>
                            <div className="text-4xl font-black text-[#0A2F5E]">12,482</div>
                            <div className="mt-4 flex items-center gap-2 text-status-green font-bold text-xs uppercase tracking-tighter">
                                <Icon name="arrow-trending-up" className="w-4 h-4" />
                                +14% vs Previous Tranche
                            </div>
                        </div>
                        <div className="bg-[#0A2F5E] p-8 rounded-3xl text-left text-white shadow-federal">
                            <span className="text-[10px] font-black text-white/40 uppercase tracking-widest block mb-2">Institutional ROI Sync</span>
                            <div className="text-4xl font-black text-brand-gold">{STATS_TRUTH.FEDERAL_ROI_MULTIPLIER}</div>
                            <p className="mt-4 text-[10px] font-bold text-white/60 uppercase leading-tight tracking-widest">Calculated across 50 nodes</p>
                        </div>
                        <div className="bg-slate-50 border border-slate-200 p-8 rounded-3xl text-left">
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Compliance Avg.</span>
                            <div className="text-4xl font-black text-[#0A2F5E]">{STATS_TRUTH.RSA_COMPLIANCE_RATE}</div>
                            <div className="mt-4 flex items-center gap-2 text-brand-accent font-bold text-xs uppercase tracking-tighter">
                                <Icon name="shield-check" className="w-4 h-4" />
                                NIST AAL2 Certified
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Main Interactive Grid Section */}
            <section className="py-24 px-6">
                <div className="max-w-7xl mx-auto">
                    <div className="bg-white border border-slate-200 p-12 md:p-20 rounded-[4rem] shadow-sm">
                        <div className="flex flex-col md:flex-row items-center justify-between gap-8 mb-20 border-b border-slate-100 pb-12">
                            <div>
                                <h2 className="text-3xl font-display font-black text-[#0A2F5E] uppercase tracking-tight">Regional Access Nodes</h2>
                                <p className="text-slate-400 font-black text-[10px] uppercase tracking-[0.4em] mt-2">Select a state to access specific program details</p>
                            </div>
                            <div className="flex items-center gap-4 px-6 py-3 bg-slate-50 border border-slate-200 rounded-2xl">
                                <Icon name="shield-check" className="w-5 h-5 text-status-green" />
                                <span className="text-xs font-black text-slate-600 uppercase tracking-widest">50 Nodes Active</span>
                            </div>
                        </div>
                        
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
                            {US_STATES.map(state => {
                                const isTexas = state === 'Texas';
                                return (
                                    <button
                                        key={state}
                                        onClick={() => handleStateClick(state)}
                                        className={`group relative p-8 rounded-[2.5rem] border transition-all duration-300 text-left overflow-hidden ${
                                            isTexas 
                                                ? 'bg-[#0A2F5E] text-white border-[#0A2F5E] shadow-federal' 
                                                : 'bg-slate-50 text-slate-600 border-slate-200 hover:border-brand-accent hover:bg-white hover:shadow-card'
                                        }`}
                                    >
                                        <div className="flex flex-col gap-2 relative z-10">
                                            <span className="text-xs font-black uppercase tracking-widest leading-tight">{state}</span>
                                            {isTexas && (
                                                <span className="text-[7px] font-black uppercase tracking-tighter opacity-60">National Hub Node</span>
                                            )}
                                        </div>
                                        
                                        <div className={`absolute bottom-4 right-4 p-2 transition-all transform translate-x-4 opacity-0 group-hover:translate-x-0 group-hover:opacity-100 ${isTexas ? 'text-white' : 'text-brand-accent'}`}>
                                            <Icon name="send" className="w-4 h-4" />
                                        </div>

                                        <div className="absolute -top-4 -right-4 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity">
                                            <Icon name="map" className="w-24 h-24" />
                                        </div>
                                    </button>
                                );
                            })}
                        </div>
                    </div>
                </div>
            </section>

            {/* Support Callout */}
            <section className="px-6">
                <div className="max-w-6xl mx-auto bg-[#0A2F5E] p-16 rounded-[4rem] text-center relative overflow-hidden shadow-federal">
                    <div className="absolute inset-0 bg-grid-white/[0.03] pointer-events-none"></div>
                    <Icon name="sparkles" className="w-32 h-32 text-brand-gold opacity-5 absolute -top-8 -right-8" />
                    <h3 className="text-3xl font-display font-black text-white uppercase tracking-tight mb-6 relative z-10">Integration Request</h3>
                    <p className="text-white/70 text-lg font-bold uppercase tracking-widest max-w-2xl mx-auto mb-12 relative z-10 leading-relaxed text-sm">
                        Are you a VR counselor looking to establish a specialized entrepreneurship track for your caseload?
                    </p>
                    <button className="bg-white text-[#0A2F5E] font-black py-6 px-16 rounded-2xl uppercase text-[10px] tracking-[0.2em] hover:bg-brand-gold hover:text-white transition-all shadow-xl relative z-10">
                        Request Agency Liaison
                    </button>
                </div>
            </section>
        </div>
    );
};

export default StateProgramsView;
