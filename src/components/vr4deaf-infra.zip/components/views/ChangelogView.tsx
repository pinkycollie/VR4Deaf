
import React from 'react';
import { MOCK_CHANGELOG } from '../../constants';
import { Icon } from '../ui/Icon';
import { ChangelogEntry } from '../../types';

const ChangeTypeTag: React.FC<{ type: ChangelogEntry['changes'][0]['type'] }> = ({ type }) => {
    const config = {
        'Protocol Update': { color: 'bg-brand-accent/20 text-brand-accent border-brand-accent/30', icon: 'rocket-launch' as const },
        'System Enhancement': { color: 'bg-status-blue/20 text-status-blue border-status-blue/30', icon: 'cpu-chip' as const },
        'Logic Correction': { color: 'bg-status-yellow/20 text-status-yellow border-status-yellow/30', icon: 'shield-exclamation' as const },
    };
    // Type casting to handle the legacy mock types vs current enum
    const info = config[type as keyof typeof config] || config['Protocol Update'];
    
    return (
        <div className={`flex-shrink-0 text-[10px] font-black px-3 py-1 rounded-full border uppercase tracking-widest flex items-center gap-2 ${info.color}`}>
            <Icon name={info.icon} className="w-3.5 h-3.5" />
            <span>{type}</span>
        </div>
    );
}

export const ChangelogView: React.FC = () => {
    return (
        <div className="bg-[#020617] min-h-screen text-brand-light pb-20">
            <header className="relative h-[35vh] min-h-[300px] overflow-hidden flex items-center justify-center border-b border-white/5">
                <div className="absolute inset-0 z-0">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#020617] z-10"></div>
                    <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=2070&auto=format&fit=crop')] bg-cover"></div>
                </div>
                <div className="relative z-20 text-center px-6">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-accent/5 border border-brand-accent/20 text-brand-accent text-[10px] font-black uppercase tracking-[0.4em] mb-6">
                        <Icon name="list-bullet" className="w-3 h-3" />
                        System Trace Logs
                    </div>
                    <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter uppercase leading-none">Protocol <span className="text-brand-accent">Sync Logs</span></h1>
                </div>
            </header>

            <section className="py-20 px-6">
                <div className="max-w-4xl mx-auto space-y-16">
                    {MOCK_CHANGELOG.map((entry, idx) => (
                        <div key={entry.version} className="relative">
                            {idx !== MOCK_CHANGELOG.length - 1 && (
                                <div className="absolute left-[-2rem] top-10 bottom-[-4rem] w-px bg-white/5 hidden md:block"></div>
                            )}
                            
                            <div className="flex items-center gap-6 mb-8">
                                <div className="hidden md:flex w-12 h-12 rounded-2xl bg-brand-accent text-brand-dark items-center justify-center font-black text-sm shadow-glow-cyan z-10">
                                    V{idx === 0 ? 'L' : idx}
                                </div>
                                <div>
                                    <h2 className="text-4xl font-black text-white uppercase tracking-tighter leading-none">Version {entry.version}</h2>
                                    <span className="text-[10px] font-black text-brand-muted uppercase tracking-[0.4em] mt-2 block">Timestamp: {entry.date}</span>
                                </div>
                            </div>

                            <div className="bg-brand-primary/20 backdrop-blur-3xl p-10 rounded-[3rem] border border-white/5 space-y-4">
                                {entry.changes.map((change, index) => (
                                    <div key={index} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 p-6 bg-white/5 rounded-[2rem] border border-white/5 hover:border-brand-accent/20 transition-all group">
                                        <p className="text-brand-light font-medium tracking-tight text-lg">{change.description}</p>
                                        <ChangeTypeTag type={change.type} />
                                    </div>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
};
