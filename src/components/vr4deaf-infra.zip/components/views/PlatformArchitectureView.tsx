
import React, { ReactNode, useEffect } from 'react';
import { Icon } from '../ui/Icon';
import type { IconName } from '../ui/Icon';
import mermaid from 'mermaid';

const ArchitectureCard: React.FC<{ title: string; icon: IconName; children: ReactNode; badge?: string }> = ({ title, icon, children, badge }) => (
    <div className="bg-white border border-slate-200 p-8 rounded-[3rem] shadow-sm w-full relative overflow-hidden group">
        <div className="flex items-center gap-5 mb-6">
            <div className="bg-brand-primary text-white p-4 rounded-2xl shadow-federal">
                 <Icon name={icon} className="w-8 h-8" />
            </div>
            <div>
                <h3 className="text-2xl font-display font-black text-brand-primary uppercase tracking-tighter leading-none">{title}</h3>
                {badge && <span className="text-[9px] font-black text-brand-accent uppercase tracking-widest mt-1 block">{badge}</span>}
            </div>
        </div>
        <div className="text-slate-500 text-sm font-bold uppercase tracking-tight leading-relaxed space-y-3">
            {children}
        </div>
    </div>
);

const PlatformArchitectureView: React.FC = () => {
    const gcpFlow = `
graph LR
    subgraph Client_Layer [Client Node]
        UI[React Frontend]
        WASM("⚙️ Wasm Engine<br/>(Local Logic Anchor)")
        UI --> WASM
    end

    subgraph GCP_Cloud [GCP Production Mesh]
        CR[Cloud Run Gateway]
        PS[Cloud Pub/Sub Orchestrator]
        VA[Vertex AI / Gemini 3]
        FS[Firestore Persistence]
        
        CR -- "Signal" --> PS
        PS -- "Worker: Specialist" --> VA
        PS -- "Worker: Coach" --> FS
    end

    subgraph Fed_Compliance [Institutional Vault]
        RSA[RSA-911 Data Tranche]
        GCS[Cloud Storage Artifacts]
    end

    WASM -- "Signed Payload" --> CR
    VA -- "Synthesis" --> RSA
    FS -- "State" --> GCS

    classDef default font-family:Inter,font-weight:bold,stroke-width:2px;
    classDef wasm fill:#0A2F5E,stroke:#C5A059,color:#FFFFFF;
    classDef gcp fill:#F8FAFC,stroke:#2563EB,color:#1E293B;
    classDef fed fill:#15803D,stroke:#15803D,color:#FFFFFF;

    class WASM wasm;
    class CR,PS,VA,FS gcp;
    class RSA,GCS fed;
    `;

    useEffect(() => {
        mermaid.initialize({
            startOnLoad: false,
            theme: 'neutral',
            fontFamily: 'Inter, sans-serif'
        });
        mermaid.run();
    }, []);

    return (
        <div className="bg-[#F8FAFC] min-h-screen pb-32">
            <header className="bg-white border-b border-slate-200 pt-32 pb-24 px-6 text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1.5 bg-brand-primary"></div>
                <div className="max-w-4xl mx-auto relative z-10">
                    <div className="inline-flex items-center gap-3 px-5 py-2 rounded bg-brand-primary text-white text-[10px] font-black uppercase tracking-[0.4em] mb-10 shadow-federal">
                        <Icon name="server-stack" className="w-4 h-4 text-brand-gold" />
                        Infrastructure Blueprint: PRODUCTION STACK [GCP]
                    </div>
                    <h1 className="text-6xl md:text-8xl font-display font-black text-brand-primary tracking-tighter uppercase mb-8 leading-none">
                        GCP <span className="text-brand-accent">Mesh.</span>
                    </h1>
                    <p className="text-xl text-slate-400 font-bold max-w-3xl mx-auto leading-tight uppercase tracking-tight">
                        Scalable Cloud Run architecture anchored by WebAssembly logic for zero-trust federal reporting.
                    </p>
                </div>
            </header>

            <section className="py-20 px-6">
                <div className="max-w-[1400px] mx-auto">
                    
                    <div className="bg-white border border-slate-200 rounded-[4rem] p-12 md:p-20 shadow-sm mb-20 overflow-x-auto">
                        <div className="text-center mb-16">
                            <h2 className="text-[10px] font-black text-brand-accent uppercase tracking-[0.6em] mb-4">GCP Resource Topology</h2>
                            <p className="text-3xl font-display font-black text-brand-primary uppercase">The Production Data Path</p>
                        </div>
                        <div className="mermaid flex justify-center min-w-[1000px]">
                            {gcpFlow}
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                        <ArchitectureCard title="Master Gateway" icon="rocket-launch" badge="Cloud Run">
                            <p>Authorized entry node for all API calls. Zero-trust authentication enforced via GCP Identity Platform.</p>
                        </ArchitectureCard>
                        <ArchitectureCard title="Logic Anchor" icon="cpu-chip" badge="WebAssembly">
                            <p>Immutable Wasm binary executing GU calculations and milestone validation on the edge.</p>
                        </ArchitectureCard>
                        <ArchitectureCard title="Orchestrator" icon="signal" badge="Cloud Pub/Sub">
                            <p>Global event bus routing signals between Job Specialists, Coaches, and Directors.</p>
                        </ArchitectureCard>
                        <ArchitectureCard title="Truth Vault" icon="shield-check" badge="Firestore">
                            <p>Encrypted persistence layer for RSA-911 case tranches and compliance audit logs.</p>
                        </ArchitectureCard>
                    </div>
                </div>
            </section>

            <section className="mt-20 text-center px-6">
                <div className="p-8 bg-brand-primary text-white rounded-[3rem] max-w-4xl mx-auto shadow-federal">
                    <h4 className="text-xs font-black text-brand-gold uppercase tracking-[0.4em] mb-4">Resource Verification Node</h4>
                    <p className="text-lg font-bold uppercase tracking-widest leading-relaxed opacity-80">
                        "Every GCP resource in this stack is configured to meet federal NIST AAL2 security standards, ensuring client PII is never exposed to the public internet."
                    </p>
                </div>
            </section>
        </div>
    );
};

export default PlatformArchitectureView;
