
import React, { useEffect } from 'react';
import { Icon } from '../ui/Icon';
import mermaid from 'mermaid';
import { EXTERNAL_INTAKE_URL } from '../../constants';

export const CompleteProtocolSchemeView: React.FC = () => {
    const lifecycleDiagram = `
graph TD
    subgraph Client_Side [01. CLIENT EDGE]
        INTAKE[Institutional Intake Node]
        WASM("⚙️ VURI™ Wasm Core<br/>(Immutable Logic Anchor)")
        INTAKE --> WASM
    end

    subgraph GCP_Production [02. PRODUCTION MESH]
        direction TB
        GATEWAY[API Gateway / Cloud Run]
        WASM -- "Signed Payload" --> GATEWAY
        
        subgraph Workers [Pub/Sub Worker Nodes]
            JS["🔍 Job Specialist Worker"]
            BC["📈 Business Coach Worker"]
        end
        
        GATEWAY -- "Signal: Case_Init" --> JS
        GATEWAY -- "Signal: Venture_Init" --> BC
    end

    subgraph Governance [03. TRUTH & AUDIT]
        RSA["🏛️ RSA-911 Data Vault"]
        OUTCOME["🏁 Verified Success Artifact"]
        
        JS --> RSA
        BC --> RSA
        RSA --> OUTCOME
    end

    %% Institutional Styling
    classDef client fill:#FFFFFF,stroke:#0A2F5E,stroke-width:2px,color:#0A2F5E
    classDef wasm fill:#0A2F5E,stroke:#C5A059,stroke-width:2px,color:#FFFFFF
    classDef cloud fill:#F8FAFC,stroke:#2563EB,stroke-width:1px,color:#1E293B
    classDef gov fill:#15803D,stroke:#15803D,stroke-width:2px,color:#FFFFFF

    class INTAKE client
    class WASM wasm
    class GATEWAY,Workers,JS,BC cloud
    class RSA,OUTCOME gov
    `;

    useEffect(() => {
        mermaid.initialize({
            startOnLoad: false,
            theme: 'neutral',
            fontFamily: 'Inter, sans-serif',
            themeVariables: {
                primaryColor: '#FFFFFF',
                primaryTextColor: '#0A2F5E',
                primaryBorderColor: '#0A2F5E',
                lineColor: '#64748B',
                fontSize: '12px',
                clusterBkg: '#F1F5F9',
                clusterBorder: '#CBD5E1'
            }
        });
        mermaid.run();
    }, []);

    return (
        <div className="bg-[#F8FAFC] min-h-screen text-slate-800 pb-32">
            {/* Header */}
            <header className="bg-white border-b border-slate-200 pt-32 pb-24 px-6 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1.5 bg-brand-primary"></div>
                <div className="max-w-6xl mx-auto relative z-10">
                    <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded bg-brand-primary text-white text-[10px] font-black uppercase tracking-[0.4em] mb-10 shadow-sm">
                        <Icon name="cog" className="w-4 h-4 text-brand-gold" />
                        Master Protocol Manifest: Production Node v3.4.0
                    </div>
                    <h1 className="text-6xl md:text-8xl font-display font-black text-brand-primary tracking-tighter uppercase mb-8 leading-none">
                        System <span className="text-brand-accent">Truth.</span>
                    </h1>
                    <p className="text-xl md:text-2xl text-slate-400 font-bold max-w-4xl leading-tight uppercase tracking-tight">
                        A foundational WebAssembly logic anchor ensures every data point in the Success Protocol is verified and immutable.
                    </p>
                </div>
            </header>

            <main className="max-w-[1900px] mx-auto px-6 py-20">
                <div className="bg-white border border-slate-200 rounded-[3rem] p-12 md:p-20 shadow-sm mb-24 overflow-x-auto relative">
                    <div className="text-center mb-16">
                        <h2 className="text-[10px] font-black text-brand-accent uppercase tracking-[0.6em] mb-4">Compute Orchestration</h2>
                        <p className="text-3xl font-display font-black text-brand-primary uppercase">Edge-to-Cloud Integrity Path</p>
                    </div>
                    <div className="mermaid flex justify-center min-w-[1000px]">
                        {lifecycleDiagram}
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                    <div className="bg-brand-primary text-white p-12 rounded-[3rem] shadow-federal">
                        <h3 className="text-xs font-black text-brand-gold uppercase tracking-[0.5em] mb-8">Wasm Identity Node</h3>
                        <p className="text-lg font-bold uppercase tracking-widest leading-relaxed opacity-80 mb-10">
                            "By executing core success logic in WebAssembly, we eliminate the vulnerability of client-side data tampering. The truth of the outcome is hashed before it ever leaves the browser."
                        </p>
                        <div className="font-mono text-[10px] text-white/40 space-y-2">
                            <p>// VURI_CORE_CHECKSUM: 0x82f...911</p>
                            <p>// RUNTIME: WASM_EDGE_STABLE</p>
                        </div>
                    </div>

                    <div className="bg-white border border-slate-200 p-12 rounded-[3rem] shadow-sm flex flex-col justify-center text-center">
                        <Icon name="shield-check" className="w-16 h-16 text-brand-accent mx-auto mb-8" />
                        <h3 className="text-2xl font-display font-black text-brand-primary uppercase tracking-tighter mb-4">RSA-911 Data Integrity</h3>
                        <p className="text-sm text-slate-400 font-bold uppercase tracking-widest leading-relaxed">
                            Ensuring 100% accuracy in federal reporting via automated workers.
                        </p>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default CompleteProtocolSchemeView;
