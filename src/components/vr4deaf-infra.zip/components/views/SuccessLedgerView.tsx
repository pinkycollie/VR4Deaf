import React, { useState, useEffect } from 'react';
import { Icon } from '../ui/Icon';
import * as api from '../../services/apiService';

export const SuccessLedgerView: React.FC = () => {
    const [entries, setEntries] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const load = async () => {
            const data = await api.getLedgerEntries();
            setEntries(data);
            setIsLoading(false);
        };
        load();
    }, []);

    return (
        <div className="bg-slate-50 min-h-screen text-slate-900 pb-24">
            <header className="pt-20 pb-12 px-4 sm:px-6 lg:px-8 border-b border-slate-200 bg-white">
                <div className="max-w-7xl mx-auto">
                    <div className="inline-flex items-center gap-2 text-blue-600 text-[10px] font-bold uppercase tracking-wider mb-4">
                        <Icon name="server-stack" className="w-4 h-4" />
                        Auditor Transparency Protocol
                    </div>
                    <h1 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight mb-2">Audit Ledger</h1>
                    <p className="text-base text-slate-500 font-medium max-w-2xl leading-relaxed">
                        Immutable verification of GU tranches and milestone validations.
                    </p>
                </div>
            </header>

            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                    <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                        <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Protocol Events</h2>
                        <div className="flex gap-3">
                            <span className="text-[10px] font-bold text-green-600 bg-green-50 border border-green-100 px-2 py-1 rounded">Syncing</span>
                            <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-1 rounded">v3.4.0</span>
                        </div>
                    </div>

                    <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead className="bg-slate-50 border-b border-slate-200">
                                <tr>
                                    <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Entry ID</th>
                                    <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Tranche Type</th>
                                    <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-center">GU Units</th>
                                    <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Integrity Hash</th>
                                    <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-right">Timestamp</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {isLoading ? (
                                    <tr><td colSpan={5} className="p-16 text-center text-slate-400 text-sm font-medium animate-pulse uppercase tracking-widest">Accessing Ledger Mesh...</td></tr>
                                ) : entries.map(entry => (
                                    <tr key={entry.id} className="hover:bg-slate-50/80 transition-colors">
                                        <td className="px-6 py-4 text-sm font-bold text-slate-900">{entry.id}</td>
                                        <td className="px-6 py-4">
                                            <span className="text-[10px] font-bold text-slate-500 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded uppercase">{entry.type.replace('_', ' ')}</span>
                                        </td>
                                        <td className="px-6 py-4 text-center font-bold text-blue-600 text-sm">{entry.units.toLocaleString()}</td>
                                        <td className="px-6 py-4">
                                            <code className="text-[10px] text-slate-400 bg-slate-50 px-2 py-1 rounded border border-slate-100 truncate block max-w-[120px]">{entry.hash}</code>
                                        </td>
                                        <td className="px-6 py-4 text-right text-[10px] font-semibold text-slate-400 uppercase whitespace-nowrap">
                                            {new Date(entry.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                <div className="mt-8 p-10 bg-slate-900 rounded-xl text-white flex flex-col md:flex-row items-center justify-between gap-8">
                    <div className="max-w-xl text-center md:text-left">
                        <h2 className="text-xl font-bold mb-2">Technical Accountability</h2>
                        <p className="text-slate-400 text-sm leading-relaxed">
                            This ledger provides state and federal auditors with an immutable trail of system logic. All calculations are executed within a signed WebAssembly binary to ensure zero-trust compliance.
                        </p>
                    </div>
                    <button className="shrink-0 px-8 py-3 bg-white text-slate-900 font-bold rounded-lg text-xs hover:bg-slate-100 transition-colors uppercase tracking-widest">
                        Download Audit Artifact
                    </button>
                </div>
            </main>
        </div>
    );
};