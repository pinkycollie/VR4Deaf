
import React from 'react';
import { Icon } from '../ui/Icon';

const SectionHeader: React.FC<{ number: string; title: string }> = ({ number, title }) => (
    <div className="flex items-center gap-4 mb-8 mt-20 border-b border-slate-200 pb-4">
        <span className="text-xl font-mono font-black text-brand-accent tracking-tighter">{number}</span>
        <h2 className="text-2xl font-display font-black text-[#0A2F5E] uppercase tracking-tight">{title}</h2>
    </div>
);

const CodeBlock: React.FC<{ language: string; content: string }> = ({ language, content }) => (
    <div className="my-8 rounded-xl overflow-hidden border border-slate-200 bg-[#0F172A] shadow-lg">
        <div className="flex items-center justify-between px-4 py-2 bg-slate-800 border-b border-slate-700">
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest">{language} artifact</span>
            <button onClick={() => navigator.clipboard.writeText(content)} className="text-slate-400 hover:text-white transition-colors">
                <Icon name="clipboard-list" className="w-4 h-4" />
            </button>
        </div>
        <pre className="p-6 text-[13px] font-mono leading-relaxed text-cyan-100 overflow-x-auto">
            <code>{content}</code>
        </pre>
    </div>
);

export const WhitePaperView: React.FC = () => {
    return (
        <article className="bg-[#F8FAFC] min-h-screen text-slate-800 font-sans selection:bg-brand-accent/20 pb-32">
            {/* Publication Header */}
            <header className="pt-32 pb-24 px-6 border-b border-slate-200 bg-white relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-brand-accent via-brand-primary to-brand-accent"></div>
                <div className="max-w-4xl mx-auto relative z-10">
                    <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded bg-[#0A2F5E] text-white text-[10px] font-black uppercase tracking-[0.4em] mb-12 shadow-sm">
                        Strategic Policy v3.1.0 [Market Release]
                    </div>
                    <h1 className="text-5xl md:text-8xl font-display font-black text-[#0A2F5E] tracking-tighter leading-[0.85] mb-10 uppercase">
                        VR4Deaf <span className="text-brand-accent">Manifesto.</span>
                    </h1>
                    <p className="text-2xl text-slate-500 font-bold leading-relaxed max-w-4xl italic">
                        "Modernizing VR programs, closing employment gaps, and tapping into a $645 billion workforce opportunity via coordinated performance-based ecosystems."
                    </p>
                    
                    <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-10 border-t border-slate-100 pt-10">
                        <div className="flex flex-col">
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Market Capacity</span>
                            <p className="text-xs font-bold text-[#0A2F5E] mt-1 uppercase">$645B Opportunity</p>
                        </div>
                        <div className="flex flex-col">
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Policy Engine</span>
                            <p className="text-xs font-bold text-[#0A2F5E] uppercase mt-1">Performance-Based</p>
                        </div>
                        <div className="flex flex-col">
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Audit Standard</span>
                            <p className="text-xs font-bold text-[#0A2F5E] uppercase mt-1">RSA-911 Compliant</p>
                        </div>
                        <div className="flex flex-col">
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Status</span>
                            <p className="text-xs font-bold text-status-green uppercase mt-1">Active Artifact</p>
                        </div>
                    </div>
                </div>
            </header>

            <main className="py-24 px-6">
                <div className="max-w-4xl mx-auto">
                    {/* Executive Summary */}
                    <section className="bg-white p-12 md:p-16 rounded-[3rem] border border-slate-200 shadow-federal relative overflow-hidden mb-24">
                        <div className="absolute top-0 right-0 p-12 opacity-[0.03] pointer-events-none text-slate-900 font-black text-9xl italic">
                            WP
                        </div>
                        <h2 className="text-xs font-black text-brand-accent uppercase tracking-[0.5em] mb-10">Executive Summary</h2>
                        <div className="prose prose-slate max-w-none space-y-6 text-lg leading-relaxed text-slate-700 font-medium">
                            <p>
                                <strong className="text-[#0A2F5E]">VR4Deaf</strong> is a coordinated vocational rehabilitation and workforce pathway ecosystem designed to increase employment access and long‑term career outcomes for Deaf and hard‑of‑hearing adults. 
                            </p>
                            <p>
                                By aligning institutional policy with modular learning pathways and the <strong>DARP v1.0.1 Security Protocol</strong>, we close communication gaps that currently cost state agencies millions in failed placements.
                            </p>
                        </div>
                    </section>

                    <SectionHeader number="1.0" title="The Problem" />
                    <div className="space-y-6 text-slate-600 font-medium leading-relaxed">
                         <p>
                            Traditional Vocational Rehabilitation (VR) systems suffer from <strong>disjointed coordination</strong> and high administrative friction. These barriers systematically exclude Deaf professionals from high-output roles, leaving a <strong>$645 billion market opportunity</strong> entirely dormant.
                        </p>
                    </div>

                    <SectionHeader number="2.0" title="Economic Dynamics" />
                    <div className="p-10 bg-slate-50 border border-slate-200 rounded-[3rem] space-y-8 mb-10">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                            <div>
                                <h4 className="text-xs font-black text-brand-accent uppercase tracking-widest mb-4">Workforce Potential</h4>
                                <p className="text-3xl font-display font-black text-[#0A2F5E] uppercase tracking-tighter">$645,000,000,000</p>
                                <p className="text-xs text-slate-400 font-bold uppercase mt-2">Annual Global Product Gap</p>
                            </div>
                            <div>
                                <h4 className="text-xs font-black text-brand-accent uppercase tracking-widest mb-4">Placement Velocity</h4>
                                <p className="text-3xl font-display font-black text-status-green uppercase tracking-tighter">42 DAYS</p>
                                <p className="text-xs text-slate-400 font-bold uppercase mt-2">Target Intake-to-CIE Duration</p>
                            </div>
                        </div>
                        <div className="h-px bg-slate-200"></div>
                        <p className="text-sm text-slate-600 font-bold leading-relaxed italic">
                            "The modernized VR program doesn't just manage cases; it initializes nodes in an economic ecosystem. By automating RSA-911 sync, we redirect administrative capital toward actual career deployment."
                        </p>
                    </div>

                    <SectionHeader number="3.0" title="Performance Based Sales Model" />
                    <div className="overflow-x-auto my-10 bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm">
                        <table className="w-full text-left">
                            <thead className="bg-slate-50 border-b border-slate-100">
                                <tr>
                                    <th className="p-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Attribute</th>
                                    <th className="p-6 text-[10px] font-black text-brand-primary uppercase tracking-widest">Subscription Model</th>
                                    <th className="p-6 text-[10px] font-black text-brand-accent uppercase tracking-widest">Performance Model</th>
                                </tr>
                            </thead>
                            <tbody className="text-sm font-bold divide-y divide-slate-100">
                                {[
                                    { a: "Revenue Predictability", s: "High", p: "Variable (Outcome-Tied)" },
                                    { a: "Customer Risk", s: "Low for Customer", p: "Low Upfront / High Vendor Risk" },
                                    { a: "Alignment", s: "Moderate", p: "High (Success Incentivized)" },
                                    { a: "Sales Pitch Focus", s: "Features, Uptime", p: "ROI, Measurable Outcomes" },
                                ].map((row, i) => (
                                    <tr key={i}>
                                        <td className="p-6 text-slate-500 uppercase text-xs tracking-widest">{row.a}</td>
                                        <td className="p-6">{row.s}</td>
                                        <td className="p-6 text-brand-accent italic">{row.p}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>

                    <SectionHeader number="4.0" title="Matching & Reuse Strategy" />
                    <p className="text-lg text-slate-700 font-medium leading-relaxed mb-10">
                        To scale outcomes while minimizing friction, VR4Deaf utilizes a <strong>"Reuse, Don't Replicate"</strong> principle. We match new participants with proven resource bundles based on meaningful similarity.
                    </p>
                    
                    <div className="bg-brand-primary p-12 rounded-[3rem] text-white relative overflow-hidden group">
                        <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:rotate-12 transition-transform duration-1000">
                            <Icon name="cpu-chip" className="w-48 h-48" />
                        </div>
                        <h4 className="text-xs font-black text-brand-gold uppercase tracking-[0.4em] mb-8">Neural Matching Algorithm</h4>
                        <div className="space-y-6 font-mono text-sm opacity-80">
                            <p>score = (commMode * 0.3) + (pathwayFit * 0.25) + (experience * 0.2) + (accommodations * 0.15) + (geography * 0.1)</p>
                            <div className="h-px bg-white/10 w-full"></div>
                            <p>Threshold (≥ 0.75): Auto-match Proven POD Artifact</p>
                            <p>Threshold (0.6 - 0.75): Hybrid Tailored Plan</p>
                        </div>
                    </div>

                    <SectionHeader number="5.0" title="Appendices — Resource Schema" />
                    <CodeBlock language="json" content={`{
  "id": "res-comm-asl-101",
  "title": "ASL-friendly Workplace Communication Module",
  "tags": ["ASL", "job", "soft-skills", "employer-outreach"],
  "evidenceScore": 0.87,
  "artifactMeta": { 
    "author": "VR4Deaf", 
    "createdAt": "2026-01-25T19:22:00Z" 
  }
}`} />

                    <footer className="mt-32 pt-20 border-t border-slate-200 text-center">
                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.5em]">VR4DEAF // SUCCESS_PROTOCOL_V3.1 // MARKET_READY_ARTIFACT</p>
                    </footer>
                </div>
            </main>
        </article>
    );
};
