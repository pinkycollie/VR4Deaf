
import React, { useState, useEffect } from 'react';
import { Icon } from '../ui/Icon';
import { ComplianceMetric } from '../../types';
import * as api from '../../services/apiService';

export const ComplianceHubView: React.FC = () => {
    const [metrics, setMetrics] = useState<ComplianceMetric[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isScanning, setIsScanning] = useState(false);
    const [scanComplete, setScanComplete] = useState(false);

    useEffect(() => {
        const load = async () => {
            const data = await api.getComplianceMetrics();
            setMetrics(data);
            setIsLoading(false);
        };
        load();
    }, []);

    const runAuditScan = () => {
        setIsScanning(true);
        setScanComplete(false);
        setTimeout(() => {
            setIsScanning(false);
            setScanComplete(true);
        }, 3000);
    };

    return (
        <div className="bg-slate-50 min-h-screen text-slate-900 pb-32">
            <header className="bg-white border-b border-slate-200 pt-32 pb-20 px-6">
                <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
                    <div>
                        <div className="flex items-center gap-3 mb-2">
                            <Icon name="shield-check" className="w-10 h-10 text-brand-accent" />
                            <h1 className="text-4xl font-extrabold text-[#0A2F5E] uppercase tracking-tight">Compliance <span className="text-brand-accent">& Outcomes.</span></h1>
                        </div>
                        <p className="text-slate-500 max-w-2xl font-bold text-sm uppercase tracking-widest mt-2">
                            Institutional Overview: RSA-911 Data Integrity & CIE Benchmarks.
                        </p>
                    </div>
                    <div className="p-4 bg-status-green/5 border-2 border-status-green/20 rounded-2xl flex items-center gap-4">
                        <div className="w-3 h-3 rounded-full bg-status-green animate-pulse"></div>
                        <span className="text-[10px] font-black text-status-green uppercase tracking-widest">Audit Gateway: ACTIVE</span>
                    </div>
                </div>
            </header>

            <main className="max-w-7xl mx-auto px-6 py-20">
                {/* Metrics Grid */}
                {isLoading ? (
                    <div className="flex justify-center py-20"><Icon name="cog" className="w-12 h-12 text-brand-accent animate-spin" /></div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
                        {metrics.map((m, i) => (
                            <div key={i} className="bg-white border border-slate-200 p-8 rounded-[2.5rem] shadow-sm hover:border-brand-accent transition-all group">
                                <div className="flex justify-between items-start mb-6">
                                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 group-hover:text-brand-accent transition-colors">{m.label}</span>
                                    <span className={`h-2.5 w-2.5 rounded-full ${
                                        m.status === 'optimal' ? 'bg-status-green' :
                                        m.status === 'warning' ? 'bg-status-yellow' :
                                        'bg-status-red'
                                    }`}></span>
                                </div>
                                <div className="text-5xl font-display font-black text-[#0A2F5E] mb-3">{m.value}</div>
                                <p className="text-sm text-slate-500 font-bold uppercase leading-relaxed tracking-tight">{m.description}</p>
                            </div>
                        ))}
                    </div>
                )}

                {/* Audit Readiness Scan Tool */}
                <section className="bg-[#0A2F5E] text-white p-12 md:p-20 rounded-[4rem] shadow-federal relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
                        <Icon name="clipboard-list" className="w-96 h-96" />
                    </div>
                    
                    <div className="relative z-10 max-w-3xl">
                        <h2 className="text-3xl font-display font-black uppercase tracking-tight mb-6">RSA-911 Integrity Scanner</h2>
                        <p className="text-white/60 text-lg font-bold uppercase tracking-widest mb-12 leading-relaxed">
                            Simulate a federal audit on your current caseload. VURI™ identifies missing progress notes and unverified communication modalities.
                        </p>
                        
                        <div className="bg-white/5 border border-white/10 rounded-3xl p-10 mb-12">
                            {isScanning ? (
                                <div className="flex flex-col items-center gap-6 py-10">
                                    <Icon name="cog" className="w-12 h-12 animate-spin text-brand-gold" />
                                    <p className="text-xs font-black uppercase tracking-[0.5em] text-white/50 animate-pulse">Scanning Active Tranches...</p>
                                </div>
                            ) : scanComplete ? (
                                <div className="animate-fade-in space-y-8">
                                    <div className="flex items-center gap-5">
                                        <div className="w-12 h-12 bg-status-green text-white rounded-full flex items-center justify-center shadow-lg">
                                            <Icon name="check-badge" className="w-7 h-7" />
                                        </div>
                                        <div>
                                            <h4 className="text-xl font-black uppercase tracking-tighter">Scan Verified: OPTIMAL</h4>
                                            <p className="text-xs font-bold text-white/40 uppercase tracking-widest">No blocking violations detected.</p>
                                        </div>
                                    </div>
                                    <div className="p-5 bg-white/5 border border-white/10 rounded-xl">
                                        <ul className="text-[10px] font-mono text-white/60 space-y-2">
                                            <li>[SCAN] Modality Verification: 100%</li>
                                            <li>[SCAN] Progress Note Sync: 98.4%</li>
                                            <li>[SCAN] Tranche ID Mapping: VALID</li>
                                        </ul>
                                    </div>
                                    <button onClick={() => setScanComplete(false)} className="text-[10px] font-black text-brand-gold uppercase tracking-widest underline underline-offset-4">Reset Node Scanner</button>
                                </div>
                            ) : (
                                <button 
                                    onClick={runAuditScan}
                                    className="w-full bg-white text-[#0A2F5E] font-black py-6 rounded-2xl uppercase text-[11px] tracking-[0.3em] hover:bg-brand-gold hover:text-white transition-all shadow-xl"
                                >
                                    INITIALIZE INTEGRITY SCAN
                                </button>
                            )}
                        </div>
                    </div>
                </section>
            </main>
        </div>
    );
};
