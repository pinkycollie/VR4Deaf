
import React from 'react';
import { Icon } from '../ui/Icon';
import { UserRole } from '../../types';
import { roleToPath, EXTERNAL_INTAKE_URL } from '../../constants';

interface PricingViewProps {
    navigate: (path: string) => void;
}

export const PricingView: React.FC<PricingViewProps> = ({ navigate }) => {
    return (
        <div className="bg-[#F8FAFC] min-h-screen text-slate-800 pb-32 font-sans">
            {/* Institutional Header */}
            <header className="bg-white border-b border-slate-200 pt-32 pb-20 px-6 text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-brand-accent via-brand-primary to-brand-accent"></div>
                <div className="max-w-5xl mx-auto relative z-10">
                    <div className="inline-flex items-center gap-3 px-5 py-2 rounded bg-brand-primary text-white text-[10px] font-black uppercase tracking-[0.4em] mb-10 shadow-sm">
                        <Icon name="shield-check" className="w-4 h-4" />
                        National Fee Schedule v3.0.0
                    </div>
                    <h1 className="text-5xl md:text-7xl font-display font-black text-brand-primary tracking-tight mb-8 uppercase leading-none">
                        Economic <span className="text-brand-accent">Structures.</span>
                    </h1>
                    <p className="text-slate-500 text-xl font-bold max-w-3xl mx-auto leading-relaxed uppercase tracking-tight opacity-80">
                        Performance-driven funding models designed to eliminate risk and maximize Deaf professional retention.
                    </p>
                </div>
            </header>

            {/* Performance vs Subscription Comparison */}
            <section className="py-24 px-6 bg-white border-b border-slate-100">
                <div className="max-w-5xl mx-auto">
                    <div className="text-center mb-16">
                        <h2 className="text-[10px] font-black text-brand-accent uppercase tracking-[0.5em] mb-4">Economic Alignment</h2>
                        <p className="text-3xl font-display font-black text-brand-primary uppercase">Subscription vs. Performance Pay</p>
                    </div>

                    <div className="overflow-hidden border border-slate-200 rounded-[2.5rem] shadow-sm">
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="bg-slate-50 border-b border-slate-200">
                                    <th className="p-8 text-[11px] font-black text-slate-400 uppercase tracking-widest">Attribute</th>
                                    <th className="p-8 text-[11px] font-black text-[#0A2F5E] uppercase tracking-widest">Subscription</th>
                                    <th className="p-8 text-[11px] font-black text-brand-accent uppercase tracking-widest">Performance Based</th>
                                </tr>
                            </thead>
                            <tbody className="text-sm font-bold divide-y divide-slate-100">
                                {[
                                    { a: "Revenue Predictability", s: "High", p: "Variable; Tied to Outcomes" },
                                    { a: "Customer Risk", s: "Low for Customer", p: "Low Upfront; Higher Vendor Risk" },
                                    { a: "Alignment with Outcomes", s: "Moderate", p: "High (Incentives Synced)" },
                                    { a: "Sales Pitch Focus", s: "Features, Uptime, Access", p: "ROI, Risk Reduction" },
                                    { a: "Measurement Needs", s: "Basic Usage", p: "Robust KPIs, Auditable 360-Proof" },
                                ].map((row, i) => (
                                    <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                                        <td className="p-8 text-slate-500 uppercase text-xs tracking-wider">{row.a}</td>
                                        <td className="p-8 text-slate-800">{row.s}</td>
                                        <td className="p-8 text-brand-accent italic font-black">{row.p}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

            {/* Performance Structures */}
            <section className="py-24 px-6">
                <div className="max-w-7xl mx-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                        <div className="p-10 bg-white border border-slate-200 rounded-[3rem] shadow-sm group hover:border-brand-accent transition-all">
                             <div className="w-14 h-14 bg-brand-accent/10 rounded-2xl flex items-center justify-center text-brand-accent mb-8">
                                <Icon name="rocket-launch" className="w-8 h-8" />
                            </div>
                            <h3 className="text-2xl font-black text-brand-primary uppercase mb-4 tracking-tighter">Pay Per Placement</h3>
                            <p className="text-sm text-slate-500 font-bold uppercase tracking-widest leading-relaxed mb-10 opacity-70">
                                Verified job placement at hire date. Fixed fee + Optional success bonus for retention milestones.
                            </p>
                            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                                <span className="text-[10px] font-black text-slate-400 uppercase block mb-1">Fee Tier</span>
                                <span className="text-lg font-black text-[#0A2F5E]">$X per Hire</span>
                            </div>
                        </div>

                        <div className="p-10 bg-[#0A2F5E] text-white rounded-[3rem] shadow-federal relative overflow-hidden group">
                            <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:rotate-12 transition-transform duration-1000">
                                <Icon name="chart-bar" className="w-40 h-40" />
                            </div>
                            <div className="w-14 h-14 bg-brand-accent text-brand-dark rounded-2xl flex items-center justify-center mb-8 relative z-10">
                                <Icon name="shield-check" className="w-8 h-8" />
                            </div>
                            <h3 className="text-2xl font-black uppercase mb-4 tracking-tighter relative z-10">Retention Staging</h3>
                            <p className="text-sm text-white/60 font-bold uppercase tracking-widest leading-relaxed mb-10 relative z-10">
                                Staged payout architecture: 40% on hire, 60% upon 90-day retention verification.
                            </p>
                            <div className="p-4 bg-white/10 rounded-2xl border border-white/10 relative z-10">
                                <span className="text-[10px] font-black text-white/50 uppercase block mb-1">Fee Tier</span>
                                <span className="text-lg font-black text-brand-gold">Staged 40/60</span>
                            </div>
                        </div>

                        <div className="p-10 bg-white border border-slate-200 rounded-[3rem] shadow-sm group hover:border-brand-accent transition-all">
                             <div className="w-14 h-14 bg-brand-gold/10 rounded-2xl flex items-center justify-center text-brand-gold mb-8">
                                <Icon name="currency-dollar" className="w-8 h-8" />
                            </div>
                            <h3 className="text-2xl font-black text-brand-primary uppercase mb-4 tracking-tighter">Blended Model</h3>
                            <p className="text-sm text-slate-500 font-bold uppercase tracking-widest leading-relaxed mb-10 opacity-70">
                                Modest retainer for baseline infrastructure + Performance fees for successful outcomes.
                            </p>
                            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                                <span className="text-[10px] font-black text-slate-400 uppercase block mb-1">Fee Tier</span>
                                <span className="text-lg font-black text-[#0A2F5E]">Hybrid Core</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default PricingView;
