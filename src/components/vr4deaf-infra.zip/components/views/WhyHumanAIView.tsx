
import React from 'react';
import { Icon } from '../ui/Icon';
import { EXTERNAL_INTAKE_URL } from '../../constants';

export const WhyHumanAIView: React.FC = () => {
    const comparisonData = [
        { feature: "Primary Driver", vuri: "Certified Human Coaches", other: "Generative Chatbots" },
        { feature: "IPE Justification", vuri: "Automated & State-Aligned", other: "Generic AI Output" },
        { feature: "Goal Achievement", vuri: "Milestone-Driven Tracking", other: "Single Sessions" },
        { feature: "Accessibility", vuri: "ASL-First Native Support", other: "Translated Text Only" },
        { feature: "Compliance", vuri: "RSA-911 Vault Ready", other: "Zero Reporting" },
    ];

    return (
        <div className="bg-[#020617] min-h-screen text-brand-light pb-32 overflow-x-hidden">
            <header className="relative py-48 px-6 text-center border-b border-white/5 overflow-hidden">
                <div className="absolute inset-0 opacity-10 bg-grid-white/[0.02] bg-[size:80px_80px]"></div>
                
                <div className="relative z-10 max-w-4xl mx-auto">
                    <div className="inline-flex items-center gap-4 px-6 py-2.5 rounded-full border-2 border-brand-accent/20 bg-brand-accent/5 text-brand-accent text-[11px] font-black uppercase tracking-[0.5em] mb-14 shadow-soft animate-pulse clip-edge">
                        STRATEGIC ADVANTAGE: THE HYBRID PROTOCOL
                    </div>
                    <h1 className="text-6xl md:text-[9rem] font-black text-white tracking-tighter uppercase mb-10 italic leading-[0.8] drop-shadow-glow">
                        HUMAN <span className="text-brand-accent">EDGE.</span>
                    </h1>
                    <p className="text-brand-muted text-xl md:text-3xl font-black uppercase tracking-[0.4em] max-w-5xl mx-auto opacity-70 leading-relaxed italic">
                        Why chatbots fail where success circles thrive.
                    </p>
                </div>
            </header>

            <section className="py-32 px-6">
                <div className="max-w-5xl mx-auto">
                    <div className="mb-24 space-y-12">
                        <div className="bg-brand-primary/30 p-12 rounded-[4rem] border border-white/10 shadow-2xl relative overflow-hidden">
                             <div className="absolute top-0 right-0 p-12 opacity-5">
                                <Icon name="shield-check" className="w-64 h-64 text-brand-accent" />
                            </div>
                            <h2 className="text-4xl font-black text-white uppercase italic tracking-tighter mb-6 relative z-10">The Failure of AI-Only Solutions</h2>
                            <p className="text-brand-muted text-lg font-medium leading-relaxed max-w-3xl relative z-10 italic">
                                "Generic chatbots lack context. They don't understand state Vocational Rehabilitation policies, and they can't provide the high-integrity evidence needed to authorize funding. VR4Deaf fills this gap by coupling powerful AI with the one thing chatbots can't replicate: <strong>Human Advocacy.</strong>"
                            </p>
                        </div>
                    </div>

                    <div className="bg-brand-primary/40 backdrop-blur-3xl rounded-[3rem] border border-white/5 overflow-hidden shadow-glow-cyan">
                        <div className="p-8 bg-white/5 border-b border-white/10 text-center">
                            <span className="text-[10px] font-black text-brand-accent uppercase tracking-[0.5em]">TECHNICAL COMPARISON PROTOCOL</span>
                        </div>
                        <table className="w-full text-left">
                            <thead className="bg-black/40">
                                <tr>
                                    <th className="p-8 text-[11px] font-black text-brand-muted uppercase tracking-widest border-r border-white/5">Protocol Layer</th>
                                    <th className="p-8 text-[11px] font-black text-brand-accent uppercase tracking-widest border-r border-white/5">VR4Deaf OS</th>
                                    <th className="p-8 text-[11px] font-black text-white uppercase tracking-widest opacity-40">Standard Chatbot</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-white/5 font-sans">
                                {comparisonData.map((row, idx) => (
                                    <tr key={idx} className="hover:bg-white/[0.02] transition-colors">
                                        <td className="p-8 text-xs font-black text-white uppercase tracking-widest border-r border-white/5">{row.feature}</td>
                                        <td className="p-8 border-r border-white/5">
                                            <div className="flex items-center gap-3">
                                                <div className="p-1 bg-brand-accent/20 rounded-full">
                                                    <Icon name="check" className="w-4 h-4 text-brand-accent" />
                                                </div>
                                                <span className="text-sm font-bold text-brand-light italic uppercase">{row.vuri}</span>
                                            </div>
                                        </td>
                                        <td className="p-8 opacity-40">
                                            <span className="text-sm font-medium text-brand-muted italic uppercase">{row.other}</span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>

                    <div className="mt-32 p-20 bg-brand-accent text-brand-dark rounded-[4rem] text-center shadow-glow-cyan transform hover:scale-[1.01] transition-all">
                        <Icon name="rocket-launch" className="w-20 h-20 mx-auto mb-10" />
                        <h2 className="text-5xl font-black uppercase italic tracking-tighter mb-6">Ready for Real Outcomes?</h2>
                        <p className="text-brand-dark/80 text-xl font-bold uppercase tracking-widest max-w-2xl mx-auto mb-12">
                            Stop talking to windows. Start building your future with the world's first Human-AI success protocol.
                        </p>
                        <a 
                            href={EXTERNAL_INTAKE_URL}
                            className="inline-block bg-brand-dark text-white font-black py-6 px-16 rounded-full uppercase text-sm tracking-[0.3em] shadow-2xl hover:scale-105 active:scale-95 transition-all italic"
                        >
                            INITIATE UPLINK NOW
                        </a>
                    </div>
                </div>
            </section>
        </div>
    );
};
