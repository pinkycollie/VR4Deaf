
import React, { useState, useEffect } from 'react';
import { Icon } from '../ui/Icon';
import { VR4DeafEventType, WebhookSubscription, WebhookEventLog } from '../../types';
import * as webhooks from '../../services/webhookService';

export const WebhookManagementView: React.FC<{ showToast: (m: string) => void }> = ({ showToast }) => {
    const [subs, setSubs] = useState<WebhookSubscription[]>([]);
    const [logs, setLogs] = useState<WebhookEventLog[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [newUrl, setNewUrl] = useState('');
    const [selectedEvents, setSelectedEvents] = useState<VR4DeafEventType[]>([]);
    const [isSimulating, setIsSimulating] = useState(false);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        setIsLoading(true);
        const [s, l] = await Promise.all([webhooks.getSubscriptions(), webhooks.getEventLogs()]);
        setSubs(s);
        setLogs(l);
        setIsLoading(false);
    };

    const handleAdd = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newUrl || selectedEvents.length === 0) {
            showToast("Endpoint URL and Event selection required.");
            return;
        }
        await webhooks.addSubscription(newUrl, selectedEvents);
        setNewUrl('');
        setSelectedEvents([]);
        loadData();
        showToast("Webhook Node Initialized.");
    };

    const handleSimulate = async (type: VR4DeafEventType) => {
        setIsSimulating(true);
        await webhooks.simulateEvent(type);
        await loadData();
        setIsSimulating(false);
        showToast(`Signal Sent: ${type}`);
    };

    const toggleEvent = (ev: VR4DeafEventType) => {
        setSelectedEvents(prev => prev.includes(ev) ? prev.filter(e => e !== ev) : [...prev, ev]);
    };

    return (
        <div className="bg-[#020617] min-h-screen text-brand-light pb-20 overflow-x-hidden font-sans">
            <header className="relative h-[30vh] min-h-[300px] flex items-center justify-center border-b border-white/5 overflow-hidden">
                <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:40px_40px]"></div>
                <div className="relative z-10 text-center px-6">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-accent/5 border border-brand-accent/20 text-brand-accent text-[10px] font-black uppercase tracking-[0.4em] mb-6">
                        <Icon name="signal" className="w-3 h-3" />
                        EVENT ORCHESTRATOR v1.0.1
                    </div>
                    <h1 className="text-5xl md:text-7xl font-black text-white uppercase tracking-tighter italic">SIGNAL <span className="text-brand-accent">GATEWAY</span></h1>
                    <p className="text-brand-muted mt-4 font-bold tracking-[0.3em] uppercase text-xs">Synchronizing VR Outcomes across Specialist Nodes</p>
                </div>
            </header>

            <div className="max-w-[1600px] mx-auto px-6 -mt-12 relative z-30">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                    {/* Left: Configuration Node */}
                    <div className="lg:col-span-4 space-y-6">
                        <div className="bg-brand-primary/40 backdrop-blur-3xl border border-white/10 p-8 rounded-[3rem] shadow-2xl">
                            <h2 className="text-xs font-black uppercase tracking-widest text-brand-accent mb-8">Deploy New Signal Hub</h2>
                            <form onSubmit={handleAdd} className="space-y-8">
                                <div className="space-y-3">
                                    <label className="text-[10px] font-black text-brand-muted uppercase tracking-widest ml-1">Endpoint URL</label>
                                    <input 
                                        type="url" 
                                        value={newUrl}
                                        onChange={e => setNewUrl(e.target.value)}
                                        placeholder="https://your-api.com/webhooks"
                                        className="w-full px-6 py-4 bg-brand-dark/50 border border-white/10 rounded-2xl text-white font-mono text-xs focus:border-brand-accent outline-none"
                                    />
                                </div>
                                <div className="space-y-4">
                                    <label className="text-[10px] font-black text-brand-muted uppercase tracking-widest ml-1">Subscribed Signals</label>
                                    <div className="grid grid-cols-1 gap-2">
                                        {Object.values(VR4DeafEventType).map(ev => (
                                            <button 
                                                key={ev} 
                                                type="button"
                                                onClick={() => toggleEvent(ev)}
                                                className={`text-left p-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border ${selectedEvents.includes(ev) ? 'bg-brand-accent text-brand-dark border-brand-accent' : 'bg-white/5 border-white/5 text-brand-muted hover:bg-white/10'}`}
                                            >
                                                {ev.replace('_', ' ')}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <button type="submit" className="w-full bg-white text-brand-dark font-black py-6 rounded-[2rem] uppercase tracking-widest hover:scale-[1.02] active:scale-95 transition-all italic text-xs">
                                    Authorize Hub Uplink
                                </button>
                            </form>
                        </div>

                        {/* ADA vs VR Policy Guard */}
                        <div className="bg-brand-accent/5 p-8 rounded-[3rem] border border-brand-accent/20 relative overflow-hidden group">
                            <div className="absolute top-0 right-0 p-10 opacity-5 group-hover:rotate-12 transition-transform duration-1000">
                                <Icon name="shield-check" className="w-40 h-40 text-brand-accent" />
                            </div>
                            <h3 className="text-[10px] font-black text-brand-accent uppercase tracking-widest mb-4 italic">Policy Intelligence Node</h3>
                            <p className="text-xs text-brand-muted font-bold uppercase leading-relaxed mb-4">
                                Does VR HAVE to pay for all accommodations?
                            </p>
                            <p className="text-[11px] text-brand-light/70 leading-relaxed italic border-l-2 border-brand-accent/30 pl-4">
                                No. ADA requires <span className="text-brand-accent font-black">employers</span> to provide reasonable accommodations. State VR agencies are eligibility-based and primarily fund temporary or success-critical entry modalities.
                            </p>
                        </div>
                    </div>

                    {/* Right: Active Partner Network Monitoring */}
                    <div className="lg:col-span-8 space-y-6">
                        <div className="bg-brand-primary/20 backdrop-blur-3xl p-8 rounded-[3rem] border border-white/5">
                            <div className="flex justify-between items-center mb-8">
                                <h2 className="text-xs font-black uppercase tracking-widest text-brand-muted">Active Integration Network</h2>
                                <button onClick={() => loadData()} className="p-2 bg-white/5 rounded-full hover:bg-brand-accent/10 transition-colors">
                                    <Icon name="cog" className={`w-5 h-5 text-brand-accent ${isLoading ? 'animate-spin' : ''}`} />
                                </button>
                            </div>

                            <div className="space-y-4">
                                {subs.map(s => (
                                    <div key={s.id} className="p-6 bg-brand-dark/50 border border-white/5 rounded-[2rem] flex flex-col md:flex-row md:items-center justify-between gap-6 group hover:border-brand-accent/30 transition-all">
                                        <div>
                                            <p className="text-sm font-black text-white font-mono uppercase tracking-tighter truncate max-w-md">{s.url}</p>
                                            <div className="flex flex-wrap gap-2 mt-2">
                                                {s.events.map(e => <span key={e} className="text-[8px] font-black px-2 py-0.5 bg-brand-accent/10 text-brand-accent rounded border border-brand-accent/20 uppercase">{e}</span>)}
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-6 text-right">
                                            <div>
                                                <p className="text-[9px] font-black text-brand-muted uppercase tracking-widest mb-1">Status</p>
                                                <span className="text-[10px] font-black text-status-green flex items-center gap-2 justify-end">
                                                    <div className="w-1.5 h-1.5 rounded-full bg-status-green animate-pulse"></div>
                                                    {s.status}
                                                </span>
                                            </div>
                                            <div>
                                                <p className="text-[9px] font-black text-brand-muted uppercase tracking-widest mb-1">Last Signal</p>
                                                <span className="text-[10px] font-black text-white/50 italic">{s.lastPulse === 'Never' ? 'Waiting...' : new Date(s.lastPulse).toLocaleTimeString()}</span>
                                            </div>
                                            <button 
                                                onClick={() => handleSimulate(s.events[0])}
                                                disabled={isSimulating}
                                                className="p-3 bg-brand-accent text-brand-dark rounded-xl shadow-glow-cyan hover:scale-110 active:scale-95 transition-all"
                                                title="Send Test Signal"
                                            >
                                                <Icon name="send" className="w-5 h-5" />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Signal Logs */}
                        <div className="bg-brand-primary/20 border border-white/5 rounded-[3rem] overflow-hidden">
                            <div className="p-8 border-b border-white/5 flex justify-between items-center bg-white/[0.02]">
                                <h3 className="text-xs font-black uppercase tracking-widest text-white italic">Signal Trace Log</h3>
                                <span className="text-[9px] font-black text-brand-muted uppercase">{logs.length} Operations Cached</span>
                            </div>
                            <div className="max-h-[400px] overflow-y-auto">
                                {logs.map(log => (
                                    <div key={log.id} className="p-6 border-b border-white/5 flex items-center justify-between hover:bg-white/[0.01] transition-colors">
                                        <div className="flex items-center gap-6">
                                            <div className="p-3 bg-status-green/10 rounded-xl">
                                                <Icon name="check" className="w-4 h-4 text-status-green" />
                                            </div>
                                            <div>
                                                <p className="text-[10px] font-black text-white uppercase tracking-widest">{log.type}</p>
                                                <p className="text-[9px] font-mono text-brand-muted mt-1">{log.timestamp}</p>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <span className="text-[10px] font-mono text-brand-accent px-3 py-1 bg-brand-accent/5 rounded-full border border-brand-accent/20">HTTP {log.responseCode}</span>
                                        </div>
                                    </div>
                                ))}
                                {logs.length === 0 && (
                                    <div className="py-20 text-center opacity-30">
                                        <Icon name="list-bullet" className="w-12 h-12 mx-auto mb-4" />
                                        <p className="text-xs font-black uppercase tracking-[0.5em]">Waiting for system pulse...</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
