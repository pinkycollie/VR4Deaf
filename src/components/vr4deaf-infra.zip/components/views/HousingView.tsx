
import React from 'react';
import { Icon } from '../ui/Icon';

const PartnerCard = ({ name, logoUrl, description, websiteUrl, category }: { name: string, logoUrl: string, description: string, websiteUrl: string, category: string }) => (
    <a href={websiteUrl} target="_blank" rel="noopener noreferrer" className="block bg-brand-primary/50 backdrop-blur-md p-8 rounded-2xl shadow-lg border border-brand-secondary hover:border-brand-accent/50 transition-all duration-300 group transform hover:-translate-y-1 h-full flex flex-col">
        <div className="h-14 mb-4 flex items-center">
            <div className="bg-white/95 p-2 rounded-md inline-block shadow-sm">
                <img src={logoUrl} alt={`${name} logo`} className="h-8" />
            </div>
        </div>
        <p className="text-sm font-semibold text-brand-accent bg-brand-accent/10 px-3 py-1 rounded-full inline-block mb-3">{category}</p>
        <h3 className="text-2xl font-bold text-white transition-colors group-hover:text-brand-accent">{name}</h3>
        <p className="text-sm text-brand-muted mt-2 mb-4 flex-grow">{description}</p>
        <div className="mt-auto text-sm font-semibold text-brand-accent flex items-center gap-2">
            Visit Website <span aria-hidden="true" className="transition-transform group-hover:translate-x-1">&rarr;</span>
        </div>
    </a>
);

export const HousingView: React.FC = () => {
    return (
        <div className="bg-brand-dark">
            {/* Hero Section */}
            <section className="bg-brand-primary/50 text-white py-16 px-4 text-center rounded-b-2xl">
                <div className="w-16 h-16 mx-auto mb-4 bg-brand-accent/10 rounded-full flex items-center justify-center ring-2 ring-brand-accent/30">
                    <Icon name="home" className="w-10 h-10 text-brand-accent" />
                </div>
                <h1 className="text-4xl font-extrabold tracking-tight">Affordable Housing Partnerships</h1>
                <p className="mt-4 text-lg text-brand-muted max-w-3xl mx-auto">
                    We understand that finding stable, affordable housing is a critical step towards securing a new job or launching a business. We've partnered with national leaders to provide accessible housing solutions.
                </p>
            </section>

            {/* Main Content */}
            <section className="py-20 px-4">
                <div className="max-w-7xl mx-auto">
                    <h2 className="text-3xl font-bold text-center text-white mb-12">Our National Housing Partners</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto items-stretch">
                        <PartnerCard
                            name="PadSplit"
                            category="Affordable Renting"
                            logoUrl="https://assets-global.website-files.com/6425f54623c57a229a4357cb/6425f54623c57a151a43586b_PadSplit%20Logo-p-500.png"
                            description="A public benefit corporation that helps the workforce save money by providing affordable, furnished rooms for rent with utilities and internet included."
                            websiteUrl="https://www.padsplit.com"
                        />
                        <PartnerCard
                            name="NACA"
                            category="Home Ownership"
                            logoUrl="https://www.naca.com/naca-web/img/logo.svg"
                            description="NACA's 'Best in America' mortgage program offers an incredible opportunity with no down payment, no closing costs, no fees, and a below-market fixed rate."
                            websiteUrl="https://www.naca.com/"
                        />
                        <PartnerCard
                            name="Esusu"
                            category="Credit Building"
                            logoUrl="https://assets-global.website-files.com/62014125b2520377543a2283/62014125b2520311f33a22c5_logo.svg"
                            description="Esusu helps you build your credit score by reporting your on-time rent payments to the major credit bureaus, unlocking new financial opportunities."
                            websiteUrl="https://esusurent.com/"
                        />
                    </div>
                    <div className="text-center mt-16 text-sm text-brand-muted max-w-2xl mx-auto">
                        <p>Please note: VR4Deaf.org provides these links as a resource. These are third-party services, and we encourage you to review their terms and offerings to see if they are the right fit for you.</p>
                    </div>
                </div>
            </section>
        </div>
    );
};
