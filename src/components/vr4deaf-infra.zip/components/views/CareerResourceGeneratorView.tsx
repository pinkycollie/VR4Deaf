import React, { useState, useEffect } from 'react';
import { generateCareerResource, submitFeedback } from '../../services/apiService';
import { Icon } from '../ui/Icon';

interface CareerResourceGeneratorViewProps {
  topic: string;
  title: string;
  onBack: () => void;
  showToast: (message: string) => void;
}

const LoadingState: React.FC = () => (
    <div className="text-center p-8">
        <div className="flex justify-center items-center mb-4">
            <Icon name="specialist" className="w-12 h-12 text-brand-accent animate-pulse" />
        </div>
        <h2 className="text-2xl font-bold text-white">Generating Your Custom Guide...</h2>
        <p className="text-brand-muted mt-2">Our AI is crafting a personalized guide for you. This may take a moment.</p>
    </div>
);

const ContentDisplay: React.FC<{ title: string; content: string }> = ({ title, content }) => {
    // Basic markdown parsing for headings and list items
    const formattedContent = content.split('\n').map((line, index) => {
        if (line.startsWith('# ')) {
            return <h2 key={index} className="text-2xl font-bold text-white mt-6 mb-3">{line.substring(2)}</h2>;
        }
        if (line.startsWith('## ')) {
            return <h3 key={index} className="text-xl font-bold text-brand-light mt-4 mb-2">{line.substring(3)}</h3>;
        }
        if (line.startsWith('* ')) {
            return <li key={index} className="flex items-start gap-3"><Icon name="check" className="w-5 h-5 text-brand-accent mt-1 shrink-0" /><span>{line.substring(2)}</span></li>;
        }
        if (line.trim() === '') {
            return <br key={index} />;
        }
        return <p key={index} className="text-brand-light mb-4">{line}</p>;
    });

    return (
         <div className="bg-brand-primary/50 backdrop-blur-lg p-6 sm:p-8 rounded-2xl shadow-2xl border border-brand-secondary">
             <h1 className="text-4xl font-extrabold tracking-tight text-brand-accent mb-6">{title}</h1>
             <div className="prose prose-invert max-w-none space-y-4">
                 {formattedContent}
             </div>
        </div>
    )
};

const FeedbackForm: React.FC<{
    onSubmit: (rating: 'good' | 'bad', comment: string) => void
}> = ({ onSubmit }) => {
    const [rating, setRating] = useState<'good' | 'bad' | null>(null);
    const [comment, setComment] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleRating = (newRating: 'good' | 'bad') => {
        setRating(newRating);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!rating) return;
        setIsSubmitting(true);
        await onSubmit(rating, comment);
        // The parent component will handle hiding this form
        setIsSubmitting(false); 
    };

    return (
        <div className="mt-8 pt-8 border-t-2 border-brand-secondary/50">
            <h3 className="text-xl font-bold text-center text-white mb-4">Was this guide helpful?</h3>
            <form onSubmit={handleSubmit}>
                <div className="flex justify-center gap-4">
                    <button
                        type="button"
                        aria-label="This was helpful"
                        onClick={() => handleRating('good')}
                        className={`p-4 rounded-full transition-all transform hover:scale-110 ${rating === 'good' ? 'bg-status-green/30 ring-2 ring-status-green' : 'bg-brand-secondary/50 hover:bg-brand-secondary'}`}
                    >
                        <Icon name="thumb-up" className="w-8 h-8 text-status-green" />
                    </button>
                    <button
                        type="button"
                        aria-label="This was not helpful"
                        onClick={() => handleRating('bad')}
                        className={`p-4 rounded-full transition-all transform hover:scale-110 ${rating === 'bad' ? 'bg-status-red/30 ring-2 ring-status-red' : 'bg-brand-secondary/50 hover:bg-brand-secondary'}`}
                    >
                        <Icon name="thumb-down" className="w-8 h-8 text-status-red" />
                    </button>
                </div>

                {rating && (
                    <div className="mt-6 animate-fade-in-up">
                        <label htmlFor="feedback-comment" className="block text-sm font-medium text-brand-muted mb-2">
                            Add a comment (optional)
                        </label>
                        <textarea
                            id="feedback-comment"
                            rows={3}
                            value={comment}
                            onChange={(e) => setComment(e.target.value)}
                            className="w-full px-4 py-3 bg-brand-dark border border-brand-secondary rounded-lg focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition"
                            placeholder="What did you like or what could be improved?"
                        />
                        <button
                            type="submit"
                            disabled={isSubmitting}
                            className="mt-4 w-full flex items-center justify-center gap-2 bg-brand-accent hover:bg-cyan-300 text-brand-dark font-bold py-3 px-6 rounded-lg transition-colors disabled:bg-gray-500 disabled:cursor-wait"
                        >
                            {isSubmitting ? 'Submitting...' : 'Submit Feedback'}
                        </button>
                    </div>
                )}
            </form>
        </div>
    );
};


export const CareerResourceGeneratorView: React.FC<CareerResourceGeneratorViewProps> = ({ topic, title, onBack, showToast }) => {
    const [content, setContent] = useState<string>('');
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);

    useEffect(() => {
        const fetchContent = async () => {
            setIsLoading(true);
            setError(null);
            try {
                const result = await generateCareerResource(topic, title);
                if (result.includes("Could not generate") || result.includes("AI functionality disabled")) {
                    setError(result);
                } else {
                    setContent(result);
                }
            } catch (err) {
                setError("An unexpected error occurred while generating the guide.");
                console.error(err);
            } finally {
                setIsLoading(false);
            }
        };

        fetchContent();
    }, [topic, title]);

    const handleFeedbackSubmit = async (rating: 'good' | 'bad', comment: string) => {
        const result = await submitFeedback(topic, title, rating, comment);
        if (result.success) {
            setFeedbackSubmitted(true);
            const message = result.analysis 
                ? `Feedback sent! AI Analysis: "${result.analysis}"`
                : "Thank you for your feedback!";
            showToast(message);
        } else {
            showToast("Sorry, we couldn't submit your feedback at this time.");
        }
    };

    return (
        <div className="p-4 sm:p-8">
            <div className="max-w-4xl mx-auto">
                 {isLoading && <LoadingState />}
                 {error && <div className="text-center text-status-red p-8 bg-brand-primary/50 rounded-lg">{error}</div>}
                 {!isLoading && !error && (
                    <>
                        <ContentDisplay title={title} content={content} />
                        
                        {feedbackSubmitted ? (
                            <div className="mt-8 pt-8 border-t-2 border-brand-secondary/50 text-center text-status-green">
                                <Icon name="check-badge" className="w-12 h-12 mx-auto mb-3" />
                                <p className="font-semibold">Thank you for your feedback!</p>
                            </div>
                        ) : (
                            <FeedbackForm onSubmit={handleFeedbackSubmit} />
                        )}
                    </>
                 )}
            </div>
        </div>
    );
};