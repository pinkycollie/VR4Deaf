
import React, { useState, useEffect } from 'react';
import { Icon } from '../ui/Icon';
import { AgencyTrack, AgencyOutcome } from '../../types';
import * as api from '../../services/apiService';

export const AgencyCommandCenterView: React.FC = () => {
    const [selectedTrack, setSelectedTrack] = useState<AgencyTrack>(AgencyTrack.DEAF_FIRST);
    const [resources, setResources] = useState(75);
    const [outcome, setOutcome] = useState<AgencyOutcome | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        handlePredict();
    }, []);

    const handlePredict = async () => {
        setIsLoading(true);
        try {
            const result = await api.predictAgencyOutcome(selectedTrack, resources);
            setOutcome(result);
        } catch (error) {
            console.error(error);
        } finally {
            setIsLoading(false);
        }
    };

    const getTrackTheme = () => {
        if (selectedTrack.includes('Deaf')) return 'from-brand-accent to-blue-600';
        if (selectedTrack.includes('LGBTQIA')) return 'from-purple-500 via-pink-500 to-orange-500';
        return 'from-yellow-400 to-brand-accent';
    };

    return (
        <div className="bg-[#050B14] min-h-screen text-brand-light pb-20">
            <header className="relative h-[40vh] min-h-[300px] overflow-hidden flex items-center justify-center">
                <div className="absolute inset-0 z-0">
                    <div className={`absolute inset-0 bg-gradient-to-b from-transparent to-[#050B14] z-10`}></div>
                    <div className={`absolute inset-0 opacity-30 bg-gradient-to-br ${getTrackTheme()} animate-aurora blur-3xl`}></div>
                    <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop')] bg-cover bg-center mix-blend-overlay"></div>
                    <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:50px_50px]"></div>
                </div>

                <div className="relative z-20 text-center px-4">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-accent/10 border border-brand-accent/30 text-brand-accent text-[10px] font-black uppercase tracking-[0.2em] mb-4 animate-pulse">
                        <Icon name="signal" className="w-3 h-3" />
                        Network Benchmark Link
                    </div>
                    <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter mb-2 drop-shadow-2xl">
                        AGENCY <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-accent to-white">COMMAND</span>
                    </h1>
                    <p className="text-brand-muted font-bold tracking-[0.3em] uppercase text-xs">Simulating Compliance Trajectories</p>
                </div>
            </header>

            <div className="max-w-[1600px] mx-auto px-6 -mt-20 relative z-30">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    <div className="lg:col-span-3 space-y-6">
                        <div className="bg-brand-primary/40 backdrop-blur-2xl border border-white/10 p-6 rounded-[2rem] shadow-2xl">
                            <div className="flex items-center justify-between mb-8">
                                <h2 className="text-xs font-black uppercase tracking-widest text-brand-accent">Track Benchmarks</h2>
                                <Icon name="cog" className={`w-4 h-4 text-brand-muted ${isLoading ? 'animate-spin' : ''}`} />
                            </div>
                            
                            <div className="space-y-8">
                                <div className="space-y-3">
                                    <label className="text-[10px] font-bold text-brand-muted uppercase flex items-center gap-2">
                                        <div className={`w-1.5 h-1.5 rounded-full bg-gradient-to-r ${getTrackTheme()}`}></div>
                                        Active Agency Track
                                    </label>
                                    <div className="grid grid-cols-1 gap-2">
                                        {Object.values(AgencyTrack).map(track => (
                                            <button 
                                                key={track}
                                                onClick={() => setSelectedTrack(track)}
                                                className={`text-left p-3 rounded-xl text-xs font-bold transition-all border ${
                                                    selectedTrack === track 
                                                    ? 'bg-brand-accent text-brand-dark border-brand-accent shadow-glow-cyan' 
                                                    : 'bg-white/5 border-white/5 text-brand-muted hover:bg-white/10'
                                                }`}
                                            >
                                                {track.split('(')[0]}
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                <div className="space-y-4">
                                    <div className="flex justify-between items-end">
                                        <label className="text-[10px] font-bold text-brand-muted uppercase">Resource Intensity</label>
                                        <span className="text-xl font-black text-brand-accent">{resources}%</span>
                                    </div>
                                    <input 
                                        type="range" 
                                        min="10" 
                                        max="100" 
                                        value={resources} 
                                        onChange={(e) => setResources(parseInt(e.target.value))}
                                        className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-brand-accent"
                                    />
                                </div>

                                <button 
                                    onClick={handlePredict}
                                    disabled={isLoading}
                                    className="w-full bg-white text-brand-dark font-black py-4 rounded-2xl hover:bg-brand-accent transition-all flex items-center justify-center gap-3 active:scale-95 group"
                                >
                                    <Icon name="shield-check" className="w-5 h-5 group-hover:rotate-12 transition-transform" />
                                    SYNC SIMULATION
                                </button>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                            <div className="bg-brand-primary/20 border border-white/5 p-4 rounded-2xl flex flex-col items-center">
                                <div className="w-2 h-2 rounded-full bg-status-green mb-2 animate-pulse"></div>
                                <span className="text-[10px] font-bold uppercase text-brand-muted">Auditor</span>
                            </div>
                            <div className="bg-brand-primary/20 border border-white/5 p-4 rounded-2xl flex flex-col items-center">
                                <div className="w-2 h-2 rounded-full bg-brand-accent mb-2"></div>
                                <span className="text-[10px] font-bold uppercase text-brand-muted">RSA Sync</span>
                            </div>
                        </div>
                    </div>

                    <div className="lg:col-span-9 space-y-6">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            {[
                                { label: 'Integrity', val: '98.4%', icon: 'shield-check', color: 'text-status-green' },
                                { label: 'Velocity', val: '42d', icon: 'rocket-launch', color: 'text-brand-accent' },
                                { label: 'Retention', val: '88%', icon: 'heart', color: 'text-status-blue' },
                                { label: 'Audit Risk', val: 'LOW', icon: 'shield-exclamation', color: 'text-white' }
                            ].map((stat, i) => (
                                <div key={i} className="bg-brand-primary/40 backdrop-blur-xl border border-white/10 p-5 rounded-[1.5rem] flex items-center gap-4">
                                    <div className="p-3 bg-white/5 rounded-xl">
                                        <Icon name={stat.icon as any} className={`w-5 h-5 ${stat.color}`} />
                                    </div>
                                    <div>
                                        <div className="text-[9px] font-black uppercase text-brand-muted tracking-widest">{stat.label}</div>
                                        <div className="text-xl font-black text-white">{stat.val}</div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <div className="bg-brand-primary/40 backdrop-blur-xl border border-white/10 rounded-[2.5rem] overflow-hidden min-h-[400px] flex flex-col">
                            <div className="p-8 border-b border-white/5 flex justify-between items-center">
                                <div>
                                    <h3 className="text-xs font-black uppercase tracking-[0.2em] text-brand-accent mb-1">Projected Outcome Path</h3>
                                    <p className="text-2xl font-bold text-white max-w-md">{outcome?.projectedSuccess || 'Mapping Trajectory...'}</p>
                                </div>
                                <div className="text-right">
                                    <div className="text-[10px] font-black text-brand-muted uppercase mb-1">Risk Profile</div>
                                    <div className={`text-2xl font-black ${outcome?.riskLevel === 'Low' ? 'text-status-green' : 'text-status-red'}`}>
                                        {outcome?.riskLevel || '---'}
                                    </div>
                                </div>
                            </div>

                            <div className="flex-grow p-8 grid grid-cols-1 md:grid-cols-2 gap-12">
                                <div className="space-y-6">
                                    <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                                        <Icon name="stuck" className="w-4 h-4 text-status-red" />
                                        Compliance Gaps
                                    </h4>
                                    <div className="space-y-4">
                                        {outcome?.bottlenecks.map((b, i) => (
                                            <div key={i} className="group flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/5 hover:border-status-red/30 transition-colors">
                                                <div className="w-8 h-8 rounded-full bg-status-red/10 flex items-center justify-center text-status-red text-xs font-black">{i+1}</div>
                                                <span className="text-xs font-bold text-brand-light">{b}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                <div className="space-y-6">
                                    <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                                        <Icon name="check-badge" className="w-4 h-4 text-brand-accent" />
                                        System Standards
                                    </h4>
                                    <div className="space-y-4">
                                        {outcome?.recommendations.map((r, i) => (
                                            <div key={i} className="group flex items-center gap-4 p-4 bg-brand-accent/5 rounded-2xl border border-brand-accent/10 hover:border-brand-accent/30 transition-colors">
                                                <div className="w-8 h-8 rounded-full bg-brand-accent/20 flex items-center justify-center text-brand-accent">
                                                    <Icon name="check" className="w-4 h-4" />
                                                </div>
                                                <span className="text-xs font-bold text-brand-light">{r}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            <div className="h-24 bg-white/[0.02] border-t border-white/5 p-6 flex items-center justify-between">
                                <div className="flex items-end gap-1 h-full">
                                    {[40, 70, 55, 90, 80, 100, 85, 95, 110, 90].map((h, i) => (
                                        <div key={i} className="w-2 bg-brand-accent/40 rounded-t-sm" style={{ height: `${h}%` }}></div>
                                    ))}
                                    <div className="text-[9px] font-black text-brand-muted ml-2 uppercase">Trajectory per Quarter</div>
                                </div>
                                <button className="px-6 py-2 rounded-full border border-white/20 text-[10px] font-black uppercase hover:bg-white hover:text-brand-dark transition-all">
                                    Export Benchmark Analytics
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
