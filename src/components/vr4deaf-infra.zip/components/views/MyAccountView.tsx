
import React, { ReactNode, useState } from 'react';
import { AuthenticatedUser } from '../../types';
import { Icon, IconName } from '../ui/Icon';

interface MyAccountViewProps {
    user: AuthenticatedUser;
    onLogout: () => void;
    showToast: (message: string) => void;
}

const SettingsCard: React.FC<{ icon: IconName, title: string, children: ReactNode }> = ({ icon, title, children }) => (
    <div className="bg-brand-primary/50 backdrop-blur-lg p-6 sm:p-8 rounded-2xl shadow-2xl border border-brand-secondary">
        <div className="flex items-center gap-4 mb-6">
            <div className="p-3 bg-brand-accent/10 rounded-xl">
                <Icon name={icon} className="w-8 h-8 text-brand-accent"/>
            </div>
            <h2 className="text-2xl font-black text-white uppercase tracking-tighter leading-none">{title}</h2>
        </div>
        <div className="space-y-4">
            {children}
        </div>
    </div>
);

const InfoRow: React.FC<{ label: string, value: string, canEdit?: boolean }> = ({ label, value, canEdit }) => (
    <div className="flex flex-col sm:flex-row justify-between sm:items-center py-3 border-b border-brand-secondary/50">
        <div>
            <p className="text-[10px] font-black text-brand-muted uppercase tracking-widest leading-none mb-1">{label}</p>
            <p className="text-brand-light font-bold">{value}</p>
        </div>
        {canEdit && <button className="text-[10px] mt-2 sm:mt-0 font-black uppercase text-brand-accent hover:text-brand-light transition-colors">Modify Data</button>}
    </div>
);

const Toggle: React.FC<{ label: string, description: string, enabled: boolean, onToggle: () => void }> = ({ label, description, enabled, onToggle }) => (
     <div className="flex items-center justify-between py-3 border-b border-brand-secondary/50">
        <div>
            <p className="font-bold text-brand-light leading-none mb-1">{label}</p>
            <p className="text-xs text-brand-muted font-medium">{description}</p>
        </div>
        <button
            onClick={onToggle}
            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors ${enabled ? 'bg-brand-accent shadow-glow-cyan' : 'bg-brand-secondary'}`}
        >
            <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${enabled ? 'translate-x-6' : 'translate-x-1'}`} />
        </button>
    </div>
);

const MyAccountView: React.FC<MyAccountViewProps> = ({ user, onLogout, showToast }) => {
    const [notifications, setNotifications] = useState({
        milestones: true,
        monthlySummary: true,
        jobAlerts: false,
    });
    const [isPasskeyEnrolled, setIsPasskeyEnrolled] = useState(true);

    const handleToggle = (key: keyof typeof notifications) => {
        setNotifications(prev => ({ ...prev, [key]: !prev[key] }));
        showToast("Notification parameters synchronized.");
    };

    const handleEnrollPasskey = () => {
        showToast("Accessing hardware biometric node...");
        setTimeout(() => {
            setIsPasskeyEnrolled(true);
            showToast("WebAuthn / Passkey synchronized. Vault integrity 100%.");
        }, 1500);
    }

    return (
        <div className="p-4 sm:p-8 space-y-12">
            <div className="text-center">
                 <h1 className="text-4xl md:text-5xl font-black text-white uppercase tracking-tighter">NODE <span className="text-brand-accent">IDENTITY</span></h1>
                 <p className="text-brand-muted text-sm font-bold tracking-[0.3em] uppercase mt-2">Personal Security Hub & Data Center</p>
            </div>
            
            <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left Column */}
                <div className="space-y-8">
                    <SettingsCard icon="user" title="Node Credentials">
                        <InfoRow label="Subject Name" value={user.displayName} canEdit />
                        <InfoRow label="Secure Email Path" value={user.email} />
                        <InfoRow label="Primary Protocol Role" value={user.primaryRole} />
                    </SettingsCard>

                    <SettingsCard icon="bell" title="Telemetry Links">
                         <Toggle 
                            label="Milestone Telemetry" 
                            description="Receive real-time data on milestone shifts."
                            enabled={notifications.milestones}
                            onToggle={() => handleToggle('milestones')}
                         />
                         <Toggle 
                            label="Outcome Summaries" 
                            description="Monthly systemic trajectory reports."
                            enabled={notifications.monthlySummary}
                            onToggle={() => handleToggle('monthlySummary')}
                         />
                         <Toggle 
                            label="Marketplace Inbound" 
                            description="Notifications for verified job placements."
                            enabled={notifications.jobAlerts}
                            onToggle={() => handleToggle('jobAlerts')}
                         />
                    </SettingsCard>
                </div>

                {/* Right Column */}
                 <div className="space-y-8">
                     <SettingsCard icon="shield-check" title="Vault Security">
                         <div className="p-4 bg-brand-accent/5 rounded-2xl border border-brand-accent/20 mb-4">
                            <div className="flex items-center gap-3 mb-3">
                                <Icon name="key" className="w-5 h-5 text-brand-accent" />
                                <span className="text-xs font-black text-white uppercase tracking-widest">WebAuthn Protection</span>
                            </div>
                            <p className="text-xs text-brand-muted font-medium mb-4 leading-relaxed">
                                Secure your account using hardware keys or biometric data. This bypasses legacy password vulnerabilities.
                            </p>
                            <button 
                                onClick={handleEnrollPasskey}
                                className={`w-full py-3 rounded-xl font-black uppercase text-[10px] tracking-widest transition-all ${isPasskeyEnrolled ? 'bg-status-green/20 text-status-green border border-status-green/30' : 'bg-brand-accent text-brand-dark shadow-glow-cyan'}`}
                            >
                                {isPasskeyEnrolled ? 'PASSKEY ACTIVE' : 'INITIALIZE PASSKEY'}
                            </button>
                         </div>

                         <InfoRow label="Vault Password" value="••••••••••••" canEdit />
                         
                         <div className="flex items-center gap-3 py-3 border-b border-brand-secondary/50">
                             <div className="w-8 h-8 rounded-full bg-status-green/20 flex items-center justify-center">
                                <Icon name="shield-check" className="w-5 h-5 text-status-green flex-shrink-0" />
                             </div>
                             <p className="text-[10px] font-bold text-brand-light uppercase tracking-wider">Account verified by DeafAUTH Protocol</p>
                         </div>
                    </SettingsCard>

                     <SettingsCard icon="device-tablet" title="Authorized Nodes">
                         <div className="flex items-center gap-4 py-2 opacity-100">
                             <div className="p-2 bg-brand-accent/10 rounded-lg">
                                <Icon name="device-tablet" className="w-6 h-6 text-brand-accent" />
                             </div>
                             <div>
                                 <p className="text-sm font-bold text-brand-light">Current Local Node (Browser)</p>
                                 <p className="text-[9px] font-black text-status-green uppercase tracking-widest">Active Link</p>
                             </div>
                         </div>
                          <div className="flex items-center gap-4 py-2 opacity-50">
                             <div className="p-2 bg-white/5 rounded-lg">
                                <Icon name="user" className="w-6 h-6 text-brand-muted" />
                             </div>
                             <div>
                                 <p className="text-sm font-bold text-brand-muted italic">iPhone 16 Pro Uplink</p>
                                 <p className="text-[9px] font-black text-brand-muted uppercase tracking-widest">Last Sync: 02h 41m</p>
                             </div>
                         </div>
                         <button className="text-[10px] w-full text-center mt-4 font-black uppercase text-brand-accent hover:text-brand-light transition-colors">DE-AUTHORIZE EXTERNAL NODES</button>
                    </SettingsCard>

                     <button onClick={onLogout} className="w-full flex items-center justify-center gap-3 bg-status-red/10 border border-status-red/20 hover:bg-status-red/20 text-status-red font-black py-5 rounded-2xl uppercase text-xs tracking-widest transition-all">
                        <Icon name="logout" className="w-5 h-5" />
                        TERMINATE SESSION
                    </button>
                 </div>
            </div>
        </div>
    );
};

export default MyAccountView;
