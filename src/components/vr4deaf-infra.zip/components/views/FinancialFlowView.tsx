
import React, { useEffect, useState } from 'react';
import { Icon, IconName } from '../ui/Icon';
import mermaid from 'mermaid';

export const FinancialFlowView: React.FC = () => {
    const [milestonesCount, setMilestonesCount] = useState(4);
    
    const projectedGU = milestonesCount * 2.5;

    const treasuryDiagram = `
graph TD
    subgraph Funding_Sources [Funding Sources]
        direction LR
        VR[🏢 State VR Agencies]
        Employers[💼 Employers]
        Grants[💙 Non-Profits/Grants]
    end

    subgraph Treasury [VR4Deaf Treasury & DAO]
        direction TB
        DAO("🏦 AI-Governed Treasury<br/>(Converts USD to GU)")
        VURI_Gov("🧠 VURI™ as Financial Governor<br/>(Sets Allocation Rules)")
        DAO -- "Managed by" --> VURI_Gov
    end

    subgraph Client_Lifecycle [Client Lifecycle & Wallet]
        Wallet("📱 Client's Secure Wallet<br/>(Holds GU)")
    end

    subgraph Marketplace [VR4Deaf Marketplace]
        Store("🛒 Store & Services<br/>(Equipment, Coaching, etc.)")
        Vendors("💼 Verified Vendors")
    end

    Funding_Sources -- "$ USD" --> DAO
    DAO -- "Allocates GU based on Milestones" --> Wallet
    Wallet -- "Spends GU" --> Store
    Store -- "Pays GU" --> Vendors
    VURI_Gov -- "Monitors Performance" --> Wallet

    classDef default font-family:Inter,font-weight:bold;
    classDef wasm fill:#0A2F5E,stroke:#C5A059,color:#FFFFFF;
    classDef market fill:#F8FAFC,stroke:#2563EB,color:#1E293B;

    class DAO,VURI_Gov wasm;
    class Store,Vendors market;
    `;

    useEffect(() => {
        mermaid.initialize({
            startOnLoad: false,
            theme: 'neutral',
            fontFamily: 'Inter, sans-serif',
        });
        mermaid.run();
    }, []);

    return (
        <div className="bg-[#F8FAFC] min-h-screen text-slate-800 pb-32">
            <header className="bg-white border-b border-slate-200 pt-32 pb-24 px-6 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1.5 bg-brand-primary"></div>
                <div className="max-w-6xl mx-auto relative z-10">
                    <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded bg-brand-primary text-white text-[10px] font-black uppercase tracking-[0.4em] mb-10 shadow-sm">
                        <Icon name="currency-dollar" className="w-4 h-4 text-brand-gold" />
                        Master Financial Operating System v1.4
                    </div>
                    <h1 className="text-6xl md:text-8xl font-display font-black text-[#0A2F5E] tracking-tighter uppercase mb-8 leading-none">
                        Economic <span className="text-brand-accent">Flow.</span>
                    </h1>
                    <p className="text-xl md:text-2xl text-slate-400 font-bold max-w-4xl leading-tight uppercase tracking-tight">
                        A transparent, milestone-driven financial ecosystem designed to turn traditional funding into measurable success.
                    </p>
                </div>
            </header>

            <main className="max-w-[1900px] mx-auto px-6 py-20">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
                    {/* Projection Calculator */}
                    <div className="lg:col-span-4">
                        <div className="bg-white border border-slate-200 p-12 rounded-[3.5rem] shadow-sm sticky top-32">
                            <h2 className="text-xs font-black text-brand-accent uppercase tracking-[0.4em] mb-10 italic">Tranche Projection Tool</h2>
                            
                            <div className="space-y-12">
                                <div className="space-y-6">
                                    <div className="flex justify-between items-end">
                                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Milestones in IPE</label>
                                        <span className="text-3xl font-black text-[#0A2F5E]">{milestonesCount}</span>
                                    </div>
                                    <input 
                                        type="range" 
                                        min="1" 
                                        max="12" 
                                        value={milestonesCount}
                                        onChange={(e) => setMilestonesCount(parseInt(e.target.value))}
                                        className="w-full h-2 bg-slate-100 rounded-full appearance-none cursor-pointer accent-brand-accent"
                                    />
                                    <div className="flex justify-between text-[8px] font-black text-slate-300 uppercase tracking-widest px-1">
                                        <span>Initial Step</span>
                                        <span>Full Support Pod</span>
                                    </div>
                                </div>

                                <div className="p-8 bg-slate-900 rounded-[2.5rem] shadow-federal text-white relative overflow-hidden">
                                    <div className="absolute top-0 right-0 p-8 opacity-5">
                                        <Icon name="currency-dollar" className="w-32 h-32" />
                                    </div>
                                    <p className="text-[9px] font-black text-brand-gold uppercase tracking-[0.3em] mb-4">Projected Tranche Allocation</p>
                                    <div className="text-5xl font-display font-black mb-2">{projectedGU.toFixed(1)} <span className="text-xl text-white/40">GU</span></div>
                                    <p className="text-xs font-bold text-white/50 uppercase tracking-widest">≈ ${(projectedGU * 2.5).toLocaleString()} USD Value</p>
                                </div>

                                <button className="w-full py-5 rounded-2xl bg-brand-primary text-white font-black uppercase text-[10px] tracking-[0.3em] hover:bg-brand-secondary transition-all">
                                    Request Tranche Unlock
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Diagram Section */}
                    <div className="lg:col-span-8">
                        <div className="bg-white border border-slate-200 rounded-[4rem] p-12 md:p-20 shadow-sm mb-12 overflow-x-auto relative">
                             <div className="text-center mb-16">
                                <h2 className="text-[10px] font-black text-brand-accent uppercase tracking-[0.6em] mb-4">The Neural Flow Architecture</h2>
                                <p className="text-3xl font-display font-black text-[#0A2F5E] uppercase tracking-tight italic">Funding Loop Logic</p>
                            </div>
                            <div className="mermaid flex justify-center min-w-[800px]">
                                {treasuryDiagram}
                            </div>
                        </div>

                        <div className="p-10 bg-brand-accent text-white rounded-[3rem] shadow-federal">
                            <h3 className="text-xs font-black text-[#0A2F5E] uppercase tracking-[0.4em] mb-6">Accounting Standard</h3>
                            <p className="text-lg font-bold uppercase tracking-widest leading-relaxed opacity-90">
                                "The Global Unit (GU) is a transparent internal accounting metric pegged to specialized service value. It ensures 1:1 parity between state agency funding and client outcomes."
                            </p>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default FinancialFlowView;
