
import React from 'react';
import { Icon, IconName } from '../ui/Icon';
import { ECOSYSTEM_DATA } from '../../constants';

interface FundingNodeProps {
    header: string;
    icon: IconName;
    items: string[];
}

const FundingNode: React.FC<FundingNodeProps> = ({ header, icon, items }) => (
    <div className="group bg-brand-primary/20 backdrop-blur-3xl p-8 rounded-[2.5rem] border border-white/5 hover:border-brand-accent/30 transition-all flex flex-col h-full">
        <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-brand-accent/10 rounded-2xl flex items-center justify-center ring-1 ring-brand-accent/20 group-hover:bg-brand-accent group-hover:text-brand-dark transition-colors">
                <Icon name={icon} className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-black text-white uppercase tracking-tighter">{header}</h3>
        </div>
        <ul className="space-y-3 flex-grow">
            {items.map(item => (
                <li key={item} className="flex items-start gap-3 text-[11px] font-bold text-brand-muted uppercase tracking-wider">
                    <Icon name="check" className="w-4 h-4 text-brand-accent mt-0.5 flex-shrink-0" />
                    <span className="leading-tight">{item}</span>
                </li>
            ))}
        </ul>
    </div>
);

const EcosystemView: React.FC = () => {
    return (
        <div className="bg-[#020617] min-h-screen text-brand-light pb-20">
            <header className="relative h-[30vh] min-h-[250px] overflow-hidden flex items-center justify-center border-b border-white/5">
                <div className="absolute inset-0 z-0">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#020617] z-10"></div>
                    <div className="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070&auto=format&fit=crop')] bg-cover opacity-10"></div>
                </div>
                <div className="relative z-20 text-center px-6">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-accent/5 border border-brand-accent/20 text-brand-accent text-[10px] font-black uppercase tracking-[0.4em] mb-4">
                        <Icon name="currency-dollar" className="w-3 h-3" />
                        Economic Framework
                    </div>
                    <h1 className="text-4xl md:text-6xl font-black text-white tracking-tighter uppercase">ECONOMIC <span className="text-brand-accent">ECOSYSTEM</span></h1>
                </div>
            </header>

            <div className="max-w-[1400px] mx-auto px-6 -mt-12 relative z-30">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {ECOSYSTEM_DATA.sections.map(section => (
                        <FundingNode 
                            key={section.header}
                            header={section.header}
                            icon={section.icon}
                            items={section.items}
                        />
                    ))}
                    {/* Explicit Digital Infrastructure Node */}
                    <div className="group bg-brand-accent/5 backdrop-blur-3xl p-8 rounded-[2.5rem] border border-brand-accent/30 hover:border-brand-accent/50 transition-all flex flex-col h-full">
                        <div className="flex items-center gap-4 mb-6">
                            <div className="w-12 h-12 bg-brand-accent/10 rounded-2xl flex items-center justify-center ring-1 ring-brand-accent/20 group-hover:bg-brand-accent group-hover:text-brand-dark transition-colors">
                                <Icon name="code-bracket" className="w-6 h-6" />
                            </div>
                            <h3 className="text-xl font-black text-white uppercase tracking-tighter">Digital Infrastructure</h3>
                        </div>
                        <p className="text-xs text-brand-muted font-bold uppercase mb-4">Powered by MBTQ.dev</p>
                        <ul className="space-y-3 flex-grow">
                            <li className="flex items-start gap-3 text-[11px] font-bold text-brand-muted uppercase tracking-wider">
                                <Icon name="check" className="w-4 h-4 text-brand-accent mt-0.5 flex-shrink-0" />
                                <span className="leading-tight">Accommodated SaaS Hubs</span>
                            </li>
                            <li className="flex items-start gap-3 text-[11px] font-bold text-brand-muted uppercase tracking-wider">
                                <Icon name="check" className="w-4 h-4 text-brand-accent mt-0.5 flex-shrink-0" />
                                <span className="leading-tight">Inclusive App Dev</span>
                            </li>
                            <li className="flex items-start gap-3 text-[11px] font-bold text-brand-muted uppercase tracking-wider">
                                <Icon name="check" className="w-4 h-4 text-brand-accent mt-0.5 flex-shrink-0" />
                                <span className="leading-tight">Developer Uplink Nodes</span>
                            </li>
                        </ul>
                    </div>
                </div>

                <div className="mt-20 p-12 bg-brand-primary/40 backdrop-blur-xl border border-white/10 rounded-[3rem] text-center shadow-2xl relative">
                    <div className="inline-block p-4 bg-brand-accent/5 rounded-full mb-8 ring-1 ring-brand-accent/20">
                         <Icon name="rocket-launch" className="w-12 h-12 text-brand-accent"/>
                    </div>
                    <h2 className="text-3xl font-black text-white uppercase tracking-tighter mb-4">The Neural Flow Architecture</h2>
                    <p className="text-brand-muted text-base font-medium max-w-4xl mx-auto leading-relaxed mb-8">
                        The VURI™ protocol manages capital flow across accommodated nodes. Every unit of funding (GU) is tracked from authorization to final delivery, ensuring every user gets the creative or developer workspace they need.
                    </p>
                    <div className="bg-brand-dark/60 p-8 rounded-[2rem] border border-white/5 flex flex-col md:flex-row items-center justify-around gap-8">
                        {['Node Identification', 'Neural Verification', 'IPE Approval', 'Resource Uplink'].map((step, i) => (
                            <div key={i} className="flex flex-col items-center gap-3">
                                <div className="w-10 h-10 rounded-full bg-brand-accent/10 border border-brand-accent/30 flex items-center justify-center text-brand-accent text-xs font-black">{i+1}</div>
                                <span className="text-[10px] font-black text-white uppercase tracking-[0.2em]">{step}</span>
                                {i < 3 && <Icon name="send" className="hidden md:block w-4 h-4 text-brand-muted rotate-90 md:rotate-0" />}
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default EcosystemView;
