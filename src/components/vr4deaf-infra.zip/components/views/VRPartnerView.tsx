
import React, { useState, useRef, useEffect } from 'react';
import { Client, MilestoneStatus, UserRole, WeeklyBriefing, DigitalTwin } from '../../types';
import * as api from '../../services/apiService';
import { Icon } from '../ui/Icon';
import { useClients } from '../../ClientContext';
import { EXTERNAL_INTAKE_URL } from '../../constants';

interface VRPartnerViewProps {
  showToast: (message: string) => void;
}

const SuccessModelModal: React.FC<{ client: Client; onClose: () => void }> = ({ client, onClose }) => {
    const { updateClient } = useClients();
    const [twin, setTwin] = useState<DigitalTwin | null>(client.digitalTwin || null);
    const [isLoading, setIsLoading] = useState(!client.digitalTwin);

    useEffect(() => {
        if (!twin) {
            handleSync();
        }
    }, []);

    const handleSync = async () => {
        setIsLoading(true);
        try {
            const result = await api.generateDigitalTwin(client);
            setTwin(result);
            await updateClient({ ...client, digitalTwin: result });
        } catch (e) {
            console.error(e);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-md animate-fade-in">
            <div className="bg-white rounded-3xl w-full max-w-3xl max-h-[90vh] overflow-y-auto relative shadow-2xl border border-slate-200">
                <button onClick={onClose} className="absolute top-6 right-6 text-slate-400 hover:text-slate-900 transition-colors z-20">
                    <Icon name="x-mark" className="w-6 h-6" />
                </button>

                <div className="p-10">
                    <div className="flex items-center gap-6 mb-10 pb-8 border-b border-slate-100">
                        <div className="w-14 h-14 rounded-2xl bg-slate-900 flex items-center justify-center text-white">
                            <Icon name="sparkles" className="w-7 h-7" />
                        </div>
                        <div>
                            <h2 className="text-2xl font-black text-slate-900 tracking-tight uppercase">Strategic Support Model</h2>
                            <p className="text-slate-500 font-bold text-[10px] uppercase tracking-widest mt-1">Institutional Node: {client.name}</p>
                        </div>
                    </div>

                    {isLoading ? (
                        <div className="py-20 flex flex-col items-center justify-center gap-4">
                            <Icon name="cog" className="w-12 h-12 text-slate-300 animate-spin" />
                            <p className="text-slate-400 font-black text-xs tracking-widest uppercase">Synthesizing Profile...</p>
                        </div>
                    ) : twin ? (
                        <div className="space-y-8">
                            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200">
                                <h3 className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-2">Persona Archetype</h3>
                                <p className="text-xl font-bold text-slate-900 leading-tight">"{twin.persona}"</p>
                                <p className="mt-4 text-slate-600 font-medium text-sm leading-relaxed">{twin.trajectorySummary}</p>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200">
                                    <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Support Triggers</h3>
                                    <div className="space-y-3">
                                        {twin.predictedObstacles.map((obs, i) => (
                                            <div key={i} className="flex items-start gap-3">
                                                <div className="w-1.5 h-1.5 rounded-full bg-slate-400 mt-1.5"></div>
                                                <span className="text-xs font-bold text-slate-700 uppercase tracking-tight leading-tight">{obs}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="p-6 bg-slate-900 rounded-2xl flex flex-col justify-center text-white">
                                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Interaction Modality</span>
                                    <p className="text-xl font-black uppercase italic text-blue-400">{twin.recommendedModality}</p>
                                </div>
                            </div>
                        </div>
                    ) : null}
                    
                    <div className="mt-10 pt-8 border-t border-slate-100 flex justify-end gap-4">
                        <button onClick={onClose} className="px-6 py-3 text-xs font-black text-slate-500 uppercase tracking-widest hover:text-slate-900 transition-colors">Close</button>
                        <button onClick={handleSync} className="bg-slate-900 text-white font-black py-3.5 px-8 rounded-xl uppercase text-[10px] tracking-widest hover:bg-slate-800 transition-all">Re-Sync Node</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export const VRPartnerView: React.FC<VRPartnerViewProps> = ({ showToast }) => {
  const { clients, addClient } = useClients();
  const [view, setView] = useState<'intake' | 'caseload'>('caseload'); 
  const [step, setStep] = useState(0); 
  const [intakeMethod, setIntakeMethod] = useState<'manual' | 'asl-scan'>('asl-scan');
  
  const [formData, setFormData] = useState({ name: '', email: '', businessIdea: '' });
  const [activeDigitalTwin, setActiveDigitalTwin] = useState<Client | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (view === 'intake' && intakeMethod === 'asl-scan' && step > 0 && step < 4) {
        startCamera();
    } else {
        stopCamera();
    }
  }, [intakeMethod, step, view]);

  const startCamera = async () => {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: true });
        streamRef.current = stream;
        if (videoRef.current) { videoRef.current.srcObject = stream; videoRef.current.play(); }
    } catch (err: any) { 
        showToast("Camera authorization required for visual intake.");
    }
  };

  const stopCamera = () => {
    if (streamRef.current) { streamRef.current.getTracks().forEach(track => track.stop()); streamRef.current = null; }
  };

  const handleStartRecording = () => { setIsRecording(true); };

  const handleStopAndAnalyze = async () => {
      setIsRecording(false);
      setIsProcessing(true);
      try {
          const result = await api.analyzeAslVideoIntake();
          setFormData(result);
          setStep(4); 
          showToast("Visual analysis successful.");
      } catch (error) { showToast("Logic Sync Error."); } 
      finally { setIsProcessing(false); }
  };

  const handleSubmitFinal = async () => {
      setIsSubmitting(true);
      try {
          await addClient(formData);
          showToast("Institutional record committed.");
          setStep(0); setFormData({ name: '', email: '', businessIdea: '' }); setView('caseload');
      } catch (error) { showToast("Database error."); } 
      finally { setIsSubmitting(false); }
  };

  return (
    <div className="bg-slate-50 min-h-screen text-slate-900 pb-20">
      <header className="bg-white border-b border-slate-200 pt-20 pb-12 px-6">
           <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
                <div>
                    <h1 className="text-3xl font-black uppercase tracking-tight text-slate-900">Case <span className="text-blue-600">Administration.</span></h1>
                    <p className="text-slate-500 font-bold text-xs uppercase tracking-widest mt-1">Authorized Agency Control Plane</p>
                </div>
                <div className="bg-slate-100 p-1.5 rounded-xl border border-slate-200 inline-flex shadow-inner">
                    <button onClick={() => { setView('intake'); setStep(0); }} className={`px-8 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-all ${view === 'intake' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}>Intake</button>
                    <button onClick={() => setView('caseload')} className={`px-8 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-all ${view === 'caseload' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}>Caseload</button>
                </div>
           </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 mt-12">
        
        {view === 'intake' ? (
            step === 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <button onClick={() => { setIntakeMethod('asl-scan'); setStep(1); }} className="bg-white p-10 rounded-2xl border border-slate-200 shadow-sm hover:border-blue-400 transition-all text-left group">
                        <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center mb-8 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                            <Icon name="video-camera" className="w-6 h-6" />
                        </div>
                        <h2 className="text-xl font-bold text-slate-900 mb-2">AI Visual Intake</h2>
                        <p className="text-slate-600 text-sm font-medium leading-relaxed">Execute intake via visual modality mapping and ASL-to-text synthesis.</p>
                    </button>
                    <button onClick={() => { setIntakeMethod('manual'); setStep(1); }} className="bg-white p-10 rounded-2xl border border-slate-200 shadow-sm hover:border-blue-400 transition-all text-left group">
                        <div className="w-12 h-12 bg-slate-100 text-slate-600 rounded-xl flex items-center justify-center mb-8 group-hover:bg-slate-900 group-hover:text-white transition-colors">
                            <Icon name="document-text" className="w-6 h-6" />
                        </div>
                        <h2 className="text-xl font-bold text-slate-900 mb-2">Standard Data Form</h2>
                        <p className="text-slate-600 text-sm font-medium leading-relaxed">Direct entry for standard demographics and competitive employment goals.</p>
                    </button>
                    <a href={EXTERNAL_INTAKE_URL} className="bg-white p-10 rounded-2xl border border-dashed border-slate-300 hover:bg-slate-50 transition-all text-left group">
                        <div className="w-12 h-12 bg-slate-50 text-slate-400 rounded-xl flex items-center justify-center mb-8">
                            <Icon name="link" className="w-6 h-6" />
                        </div>
                        <h2 className="text-xl font-bold text-slate-700 mb-2">Institutional Link</h2>
                        <p className="text-slate-500 text-sm font-medium leading-relaxed">Standalone intake node for cross-agency referrals.</p>
                    </a>
                </div>
            ) : (
                <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden flex flex-col lg:flex-row min-h-[550px]">
                    <div className="lg:w-1/2 bg-slate-50 border-r border-slate-200 p-12 relative flex flex-col">
                        {intakeMethod === 'asl-scan' ? (
                             <div className="flex-grow flex flex-col">
                                <div className="flex-grow rounded-2xl overflow-hidden bg-slate-900 relative shadow-inner">
                                    <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover opacity-90" />
                                    {isProcessing && (
                                        <div className="absolute inset-0 bg-slate-900/95 flex flex-col items-center justify-center p-8 text-center text-white">
                                            <Icon name="cog" className="w-12 h-12 animate-spin mb-6 text-blue-400" />
                                            <h3 className="text-sm font-black uppercase tracking-[0.2em]">Processing Modalities...</h3>
                                        </div>
                                    )}
                                </div>
                                <div className="mt-8 flex justify-center">
                                    {!isRecording ? (
                                        <button onClick={handleStartRecording} className="bg-blue-600 text-white font-black py-4 px-12 rounded-xl uppercase text-xs tracking-widest shadow-lg hover:bg-blue-700 active:scale-95 transition-all">Initialize Record</button>
                                    ) : (
                                        <button onClick={handleStopAndAnalyze} className="bg-status-red text-white font-black py-4 px-12 rounded-xl uppercase text-xs tracking-widest animate-pulse shadow-lg">Complete & Sync</button>
                                    )}
                                </div>
                             </div>
                        ) : (
                             <div className="h-full flex flex-col items-center justify-center text-center">
                                <div className="w-20 h-20 bg-slate-200 rounded-full flex items-center justify-center mb-6">
                                    <Icon name="user" className="w-10 h-10 text-slate-500" />
                                </div>
                                <h3 className="text-2xl font-black text-slate-900 mb-2 uppercase tracking-tight">Manual Input</h3>
                                <p className="font-bold text-[10px] text-slate-400 uppercase tracking-[0.3em]">Establishing Permanent Agency Record</p>
                             </div>
                        )}
                    </div>

                    <div className="lg:w-1/2 p-12 flex flex-col justify-center bg-white">
                         <div className="max-w-md mx-auto w-full space-y-10">
                             {step === 1 && (
                                <div className="space-y-4">
                                    <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest ml-1">Legal Identifier (Name)</label>
                                    <input autoFocus type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl p-5 text-xl font-bold text-slate-900 focus:border-blue-600 focus:bg-white outline-none transition-all shadow-sm" placeholder="Enter full legal name" />
                                </div>
                             )}
                             {step === 2 && (
                                <div className="space-y-4">
                                    <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest ml-1">Secure Contact (Email)</label>
                                    <input autoFocus type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-xl p-5 text-xl font-bold text-slate-900 focus:border-blue-600 focus:bg-white outline-none transition-all shadow-sm" placeholder="email@agency.org" />
                                </div>
                             )}
                             {step === 4 && (
                                <div className="space-y-8 animate-fade-in">
                                     <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight border-b border-slate-100 pb-4">Verification</h3>
                                     <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-6">
                                         <div>
                                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Subject Node</p>
                                            <p className="text-xl font-bold text-slate-900">{formData.name}</p>
                                         </div>
                                         <button onClick={handleSubmitFinal} disabled={isSubmitting} className="w-full bg-slate-900 text-white font-black py-5 rounded-xl uppercase text-xs tracking-widest shadow-md hover:bg-slate-800 transition-all active:scale-95">Commit Record to Mesh</button>
                                     </div>
                                </div>
                             )}
                             <div className="flex justify-between pt-12 border-t border-slate-100">
                                <button onClick={() => setStep(s => Math.max(s-1, 0))} className="text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-slate-900 transition-colors">Back</button>
                                {step < 4 && <button onClick={() => setStep(s => s+1)} className="text-blue-600 font-black uppercase text-[10px] tracking-[0.2em] hover:text-blue-800 transition-colors">Continue &rarr;</button>}
                             </div>
                         </div>
                    </div>
                </div>
            )
        ) : (
            <div className="space-y-12">
                <div className="flex justify-between items-end border-b border-slate-200 pb-8">
                    <div>
                        <h2 className="text-4xl font-black text-slate-900 uppercase tracking-tight">Active <span className="text-blue-600">Network.</span></h2>
                        <p className="text-slate-500 font-bold text-xs uppercase tracking-widest mt-2">{clients.length} Records Fully Verified</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {clients.map(client => (
                        <div key={client.id} className="bg-white border border-slate-200 rounded-3xl p-8 hover:border-blue-400 hover:shadow-xl transition-all flex flex-col group">
                            <div className="flex items-center gap-5 mb-8">
                                <div className="w-14 h-14 rounded-2xl bg-slate-100 text-slate-900 flex items-center justify-center font-black text-2xl group-hover:bg-blue-50 group-hover:text-blue-600 transition-colors">
                                    {client.name[0]}
                                </div>
                                <div className="overflow-hidden">
                                    <h3 className="text-xl font-bold text-slate-900 truncate">{client.name}</h3>
                                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block truncate">{client.email}</span>
                                </div>
                            </div>
                            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 mb-8 flex-grow">
                                <p className="text-sm font-bold text-slate-700 italic leading-relaxed">"{client.businessIdea}"</p>
                            </div>
                            <button 
                                onClick={() => setActiveDigitalTwin(client)}
                                className="w-full bg-slate-900 text-white font-black py-4 rounded-xl uppercase text-[10px] tracking-[0.2em] hover:bg-slate-800 transition-all flex items-center justify-center gap-3"
                            >
                                <Icon name="sparkles" className="w-4 h-4" />
                                {client.digitalTwin ? 'View Success Profile' : 'Synthesize Support Model'}
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        )}
      </div>

      {activeDigitalTwin && <SuccessModelModal client={activeDigitalTwin} onClose={() => setActiveDigitalTwin(null)} />}
    </div>
  );
};
