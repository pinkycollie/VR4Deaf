
import React, { useState } from 'react';
import { Icon } from '../ui/Icon';

export const MeshGatewayView: React.FC<{ showToast: (m: string) => void }> = ({ showToast }) => {
    const [businessName, setBusinessName] = useState('');
    const [isSynchronizing, setIsSynchronizing] = useState(false);

    const handleInitialize = (e: React.FormEvent) => {
        e.preventDefault();
        setIsSynchronizing(true);
        setTimeout(() => {
            setIsSynchronizing(false);
            showToast(`Node ${businessName} initialized. Status: Synchronized Idle.`);
            setBusinessName('');
        }, 2000);
    };

    return (
        <div className="bg-[#010413] min-h-screen text-white font-sans selection:bg-brand-accent/30 overflow-x-hidden">
            {/* Edge Gateway Hero */}
            <section className="relative pt-48 pb-32 px-6 border-b border-white/5">
                <div className="absolute inset-0 bg-grid-white/[0.01] bg-[size:40px_40px]"></div>
                <div className="absolute top-0 right-0 w-1/2 h-full bg-brand-accent/5 blur-[120px] rounded-full pointer-events-none opacity-50"></div>
                
                <div className="max-w-6xl mx-auto relative z-10 text-center">
                    <div className="inline-flex items-center gap-3 px-6 py-2 rounded bg-brand-accent/10 border border-brand-accent/30 text-brand-accent text-[11px] font-black uppercase tracking-[0.4em] mb-12 shadow-glow-cyan animate-pulse">
                        <Icon name="signal" className="w-4 h-4" />
                        Edge Gateway: Master Node
                    </div>
                    <h1 className="text-6xl md:text-8xl font-display font-black text-white tracking-tighter mb-8 uppercase leading-[0.9]">
                        Partner <span className="text-brand-accent">Gateway.</span>
                    </h1>
                    <p className="text-xl md:text-2xl text-slate-400 font-bold max-w-4xl mx-auto leading-relaxed uppercase tracking-tight opacity-80">
                        The institutional portal for businesses to register as active nodes. Synchronize now—Wait until a Deaf professional triggers the uplink.
                    </p>
                </div>
            </section>

            {/* Registration Console */}
            <section className="py-32 px-6">
                <div className="max-w-5xl mx-auto">
                    <div className="bg-brand-primary/40 backdrop-blur-3xl p-12 md:p-20 rounded-[4rem] border border-white/10 shadow-2xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-12 opacity-[0.03] pointer-events-none">
                            <Icon name="cog" className="w-64 h-64 text-white animate-spin" style={{ animationDuration: '60s' }} />
                        </div>
                        
                        <div className="relative z-10">
                            <h2 className="text-xs font-black text-brand-accent uppercase tracking-[0.5em] mb-12 text-center">Node Initialization Protocol</h2>
                            <form onSubmit={handleInitialize} className="space-y-10">
                                <div className="space-y-4">
                                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Entity / Business Identifier</label>
                                    <input 
                                        type="text" 
                                        required
                                        value={businessName}
                                        onChange={e => setBusinessName(e.target.value)}
                                        placeholder="Enter Business Name..."
                                        className="w-full bg-black/60 border-2 border-white/5 rounded-3xl p-8 text-2xl font-black text-white focus:border-brand-accent outline-none transition-all placeholder:text-white/10 uppercase tracking-tighter"
                                    />
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="p-6 bg-white/5 rounded-3xl border border-white/10">
                                        <span className="text-[9px] font-black text-brand-accent uppercase tracking-widest block mb-2">Modality Path</span>
                                        <p className="text-sm font-bold text-white uppercase tracking-wider">Universal Inclusion</p>
                                    </div>
                                    <div className="p-6 bg-white/5 rounded-3xl border border-white/10">
                                        <span className="text-[9px] font-black text-brand-accent uppercase tracking-widest block mb-2">Runtime Environment</span>
                                        <p className="text-sm font-bold text-white uppercase tracking-wider">Deno Edge Runtime</p>
                                    </div>
                                </div>
                                <button 
                                    disabled={isSynchronizing}
                                    className="w-full bg-white text-brand-dark font-black py-8 rounded-[3rem] uppercase text-sm tracking-[0.3em] hover:scale-[1.02] active:scale-95 transition-all shadow- federal"
                                >
                                    {isSynchronizing ? (
                                        <div className="flex items-center justify-center gap-4">
                                            <Icon name="cog" className="w-5 h-5 animate-spin" />
                                            SYNCING NETWORK...
                                        </div>
                                    ) : 'INITIALIZE NODE GATEWAY'}
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </section>

            {/* Participation Logic */}
            <section className="py-32 px-6 bg-white/[0.02] border-y border-white/5 relative">
                <div className="max-w-7xl mx-auto">
                    <div className="text-center mb-24">
                        <h2 className="text-xs font-black text-brand-accent uppercase tracking-[0.4em] mb-4">Uplink Triggers</h2>
                        <p className="text-4xl font-display font-black text-white uppercase tracking-tight leading-none">Participation Lifecycle</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                        {[
                            { 
                                title: 'Root Mounting', 
                                desc: 'Your business metadata is hashed and mounted to the Partner Network. The node remains active but idle.',
                                icon: 'link'
                            },
                            { 
                                title: 'Synchronized Idle', 
                                desc: 'System status is marked as "Listening." All businesses participate in the wait-cycle globally.',
                                icon: 'signal'
                            },
                            { 
                                title: 'Uplink Trigger', 
                                desc: 'A Deaf professional enters the gateway. VURI™ triggers the connection, and the node activates fully.',
                                icon: 'sparkles'
                            }
                        ].map((step, i) => (
                            <div key={i} className="p-12 bg-white/5 rounded-[3rem] border border-white/10 hover:border-brand-accent/30 transition-all group flex flex-col items-center text-center">
                                <div className="w-16 h-16 bg-brand-accent/10 rounded-2xl flex items-center justify-center text-brand-accent mb-8 group-hover:bg-brand-accent group-hover:text-brand-dark transition-all">
                                    <Icon name={step.icon as any} className="w-8 h-8" />
                                </div>
                                <h3 className="text-2xl font-black text-white uppercase tracking-tighter mb-4">{step.title}</h3>
                                <p className="text-sm text-slate-400 font-bold leading-relaxed uppercase tracking-widest">{step.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* B-Roll behavioral layer: technical code trace */}
            <section className="py-40 px-6 text-center">
                <div className="max-w-4xl mx-auto">
                    <div className="bg-[#0F172A] rounded-2xl p-10 font-mono text-[13px] leading-relaxed text-slate-500 overflow-x-auto border-2 border-slate-800 shadow-2xl text-left mb-12">
                        <div className="text-brand-accent/50 mb-4">// Gateway: Idle State Orchestration</div>
                        <div>{`while (node.status === 'Idle') {
    const uplink = await Partners.pollForClient(node.geoContext);
    
    if (uplink.modality === 'ASL_NATIVE') {
        return node.activateUplink(uplink.professionalId);
    }
    
    await wait(edge.LATENCY_CHECK_INTERVAL);
}`}</div>
                    </div>
                    <p className="text-xs font-black text-slate-500 uppercase tracking-[0.5em] mb-4">Proprietary MBTQ.dev Infrastructure Logic</p>
                    <p className="text-brand-muted font-bold text-sm uppercase tracking-widest opacity-60">
                        The gateway is always on. All businesses can participate. Success is triggered by human connection.
                    </p>
                </div>
            </section>
        </div>
    );
};
