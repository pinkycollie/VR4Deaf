
import React from 'react';
import { Icon } from '../ui/Icon';

const LifecycleState: React.FC<{ 
    label: string; 
    desc: string; 
    isActive?: boolean; 
    isDone?: boolean;
    color: string 
}> = ({ label, desc, isActive, isDone, color }) => (
    <div className={`flex flex-col gap-1 transition-all duration-300 ${isActive || isDone ? 'opacity-100' : 'opacity-70'}`}>
        <div className="flex items-center gap-3">
            <div className={`w-2.5 h-2.5 rounded-full ${isDone ? 'bg-status-green' : color} ${isActive ? 'ring-4 ring-blue-100 animate-pulse' : ''}`}></div>
            <span className={`text-xs font-bold uppercase tracking-tight ${isActive ? 'text-slate-900' : 'text-slate-700'}`}>{label}</span>
            {isDone && <Icon name="check" className="w-4 h-4 text-status-green" />}
        </div>
        <p className="text-[11px] font-semibold text-slate-500 uppercase leading-tight ml-5.5">{desc}</p>
    </div>
);

const PodNode: React.FC<{ 
    title: string; 
    alias: string; 
    formId?: string;
    desc: string; 
    states: { label: string; desc: string; isDone?: boolean; isActive?: boolean }[];
    type: 'workforce' | 'business' | 'dev'
}> = ({ title, alias, formId, desc, states, type }) => (
    <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm hover:border-slate-300 transition-all flex flex-col h-full relative group">
        <div className="absolute top-4 right-6 font-mono text-xs font-bold text-slate-300 uppercase tracking-widest">
            {formId || 'NODE'}
        </div>
        
        <div className="flex items-center gap-4 mb-6">
            <div className={`p-3 rounded-xl ${
                type === 'workforce' ? 'bg-slate-900 text-white' : 
                type === 'business' ? 'bg-blue-600 text-white' :
                'bg-slate-100 text-slate-900'
            }`}>
                <Icon name={type === 'dev' ? 'code-bracket' : 'specialist'} className="w-6 h-6" />
            </div>
            <div>
                <h3 className="text-xl font-bold text-slate-900 tracking-tight">{title}</h3>
                <p className="text-[10px] font-extrabold text-slate-400 uppercase tracking-[0.2em]">{alias}</p>
            </div>
        </div>

        <p className="text-slate-600 text-sm font-medium leading-relaxed mb-8 flex-grow">{desc}</p>
        
        <div className="space-y-4 pt-6 border-t border-slate-100">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Lifecycle Trajectory</h4>
            {states.map((s, i) => (
                <LifecycleState key={i} {...s} color={type === 'workforce' ? 'bg-slate-900' : type === 'business' ? 'bg-blue-600' : 'bg-slate-400'} />
            ))}
        </div>
    </div>
);

export const TheProcessView: React.FC = () => {
    return (
        <div className="bg-white min-h-screen text-slate-900 pb-32 font-sans">
            <header className="pt-20 pb-16 px-6 border-b border-slate-100 bg-slate-50/50">
                <div className="max-w-7xl mx-auto">
                    <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-200 text-slate-700 text-[10px] font-black uppercase tracking-widest rounded mb-6 border border-slate-300">
                        Operational Infrastructure
                    </div>
                    <h1 className="text-4xl md:text-5xl font-black text-slate-900 tracking-tight uppercase mb-4">
                        Pod <span className="text-blue-600">Protocol.</span>
                    </h1>
                    <p className="text-lg text-slate-600 font-medium max-w-2xl leading-relaxed">
                        Every role is an asset. Every workflow is a trajectory. A standardized framework for success in Vocational Rehabilitation.
                    </p>
                </div>
            </header>

            {/* Strategic Matching Section */}
            <section className="py-20 px-6 border-b border-slate-100">
                <div className="max-w-7xl mx-auto">
                    <div className="mb-12">
                        <h2 className="text-[10px] font-black text-blue-600 uppercase tracking-[0.3em] mb-2">Scale Protocol</h2>
                        <p className="text-3xl font-black text-slate-900 tracking-tight">Strategic Matching & Reuse</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {[
                            { 
                                t: "Reuse, Don't Replicate", 
                                d: "Adapting validated curricula, employer scripts, and accommodation plans rather than reinventing for every case.", 
                                i: "cube" 
                            },
                            { 
                                t: "Match by Similarity", 
                                d: "Leveraging correlations in communication modes, employment goals, and prior support barriers.", 
                                i: "users" 
                            },
                            { 
                                t: "Autonomy & Consent", 
                                d: "Participants opt-in via DeafAUTH to resource reuse and data sharing with referring partners.", 
                                i: "shield-check" 
                            }
                        ].map((principle, idx) => (
                            <div key={idx} className="bg-white p-8 rounded-2xl border border-slate-200 hover:border-slate-300 transition-all">
                                <div className="w-10 h-10 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-center text-slate-900 mb-6">
                                    <Icon name={principle.i as any} className="w-5 h-5" />
                                </div>
                                <h3 className="text-lg font-bold text-slate-900 mb-3">{principle.t}</h3>
                                <p className="text-sm text-slate-600 font-medium leading-relaxed">{principle.d}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Workforce Partners */}
            <section className="py-20 px-6">
                <div className="max-w-7xl mx-auto">
                    <div className="mb-12">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Institutional Root: jobpod.mbtq.dev</span>
                        <h2 className="text-3xl font-black text-slate-900 tracking-tight">Phase 1: Workforce Partners</h2>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        <PodNode 
                            title="Job Specialist" 
                            alias="The Accommodator" 
                            formId="VR3314" 
                            type="workforce"
                            desc="Identifies skill gaps and initializes Strategic Accommodations. Authorizes JST goals via state referral."
                            states={[
                                { label: "Activation", desc: "Referral Intake.", isDone: true },
                                { label: "Modality Mapping", desc: "Setting CIE Standards.", isActive: true },
                                { label: "Authorization", desc: "Unit Release.", isActive: false }
                            ]}
                        />
                         <PodNode 
                            title="Job Coach" 
                            alias="The Implementation Pod" 
                            formId="VR3315" 
                            type="workforce"
                            desc="Operational support engine. Converts session hours into immutable progress notes."
                            states={[
                                { label: "Task Analysis", desc: "Baseline Setup.", isDone: true },
                                { label: "Training", desc: "JST Unit Delivery.", isActive: true },
                                { label: "Stabilization", desc: "Support Fading.", isActive: false }
                            ]}
                        />
                        <PodNode 
                            title="Supervisor Node" 
                            alias="The Governor" 
                            formId="RSA-911" 
                            type="workforce"
                            desc="Audits protocol integrity. Verifies human specialty + AI logic for federal tranches."
                            states={[
                                { label: "Verification", desc: "Audit Trail Cleansing.", isDone: true },
                                { label: "Billing", desc: "GU unit control.", isActive: true },
                                { label: "Compliance", desc: "Quarterly Upload.", isActive: false }
                            ]}
                        />
                    </div>
                </div>
            </section>
        </div>
    );
};

export default TheProcessView;
