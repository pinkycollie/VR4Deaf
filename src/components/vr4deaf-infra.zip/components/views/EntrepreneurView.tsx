
import React, { useState } from 'react';
// Added UrlStatus to the imports from types.ts
import { Client, Milestone, MilestoneStatus, ClientDashboardMode, UserRole, AuthenticatedUser, UrlStatus } from '../../types';
import { Icon } from '../ui/Icon';
import { roleToPath } from '../../constants';
import { useClients } from '../../ClientContext';
import * as api from '../../services/apiService';

interface EntrepreneurViewProps {
  currentUser: AuthenticatedUser;
  client?: Client;
  showToast: (message: string) => void;
}

const InitializationView: React.FC<{ currentUser: AuthenticatedUser, showToast: (message: string) => void }> = ({ currentUser, showToast }) => {
    const { createClientForUser } = useClients();
    const [idea, setIdea] = useState('');
    const [ideaKeywords, setIdeaKeywords] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleGenerateIdea = async () => {
        setIsGenerating(true);
        try {
            const generatedIdea = await api.generateBusinessIdea(ideaKeywords);
            setIdea(generatedIdea);
        } catch (error) {
            showToast("Protocol mismatch during generation.");
        } finally {
            setIsGenerating(false);
        }
    };
    
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!idea) {
            showToast("Initialization payload required.");
            return;
        }
        setIsSubmitting(true);
        try {
            await createClientForUser(currentUser, idea);
            showToast("Node initialized. Strategic roadmap active.");
        } catch (error) {
            showToast("Sync Error.");
        } finally {
            setIsSubmitting(false);
        }
    }
    
    return (
         <div className="p-8 max-w-4xl mx-auto">
            <div className="bg-brand-primary/20 backdrop-blur-3xl p-12 rounded-[3rem] border border-white/5 shadow-2xl">
                 <div className="text-center mb-10">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-accent/10 border border-brand-accent/20 text-brand-accent text-[10px] font-black uppercase tracking-[0.4em] mb-4">
                        <Icon name="rocket-launch" className="w-3 h-3" />
                        Protocol Initialization
                    </div>
                    <h1 className="text-4xl font-black text-white tracking-tighter uppercase leading-none">Initialize <span className="text-brand-accent">Founder Node</span></h1>
                    <p className="text-brand-muted mt-4 font-medium">Uplink your strategic objective to begin the Success Protocol.</p>
                 </div>

                <form onSubmit={handleSubmit} className="space-y-8">
                    <div className="space-y-3">
                        <label className="text-[10px] font-black text-brand-muted uppercase tracking-widest ml-1">Strategic Objective</label>
                        <textarea 
                            value={idea} 
                            onChange={(e) => setIdea(e.target.value)} 
                            rows={3} 
                            className="w-full px-6 py-5 bg-brand-dark/50 border border-white/5 rounded-3xl text-white font-bold placeholder:text-white/10 focus:border-brand-accent outline-none transition-all resize-none" 
                            placeholder="e.g., Establishing a visual-first SaaS hub for ASL educators..."
                        />
                    </div>

                     <div className="p-8 bg-brand-accent/5 rounded-[2.5rem] border border-brand-accent/20 relative overflow-hidden group">
                        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:rotate-12 transition-transform duration-700">
                            <Icon name="cpu-chip" className="w-32 h-32 text-brand-accent" />
                        </div>
                        <h4 className="text-xs font-black text-white uppercase tracking-widest mb-4">VURI™ Neural Ideation</h4>
                        <div className="flex flex-col sm:flex-row items-center gap-4">
                            <input 
                                type="text" 
                                value={ideaKeywords} 
                                onChange={(e) => setIdeaKeywords(e.target.value)} 
                                className="w-full px-5 py-4 bg-brand-dark/50 border border-white/5 rounded-2xl text-sm font-bold text-white focus:border-brand-accent outline-none" 
                                placeholder="Core Keywords..." 
                            />
                            <button 
                                type="button" 
                                onClick={handleGenerateIdea} 
                                disabled={isGenerating} 
                                className="w-full sm:w-auto bg-brand-accent text-brand-dark font-black py-4 px-8 rounded-2xl uppercase text-[10px] tracking-widest hover:scale-105 transition-all shadow-glow-cyan"
                            >
                                {isGenerating ? 'Mapping...' : 'Generate Logic'}
                            </button>
                        </div>
                    </div>

                    <button 
                        type="submit" 
                        disabled={isSubmitting} 
                        className="w-full bg-white text-brand-dark font-black py-6 rounded-[2rem] uppercase tracking-widest hover:scale-[1.02] active:scale-95 transition-all"
                    >
                        {isSubmitting ? 'Syncing...' : 'Activate Strategic Protocol'}
                    </button>
                </form>
            </div>
        </div>
    );
}

const MilestoneNode: React.FC<{ milestone: Milestone, onVerify: () => void }> = ({ milestone, onVerify }) => {
    const statusMap = {
        [MilestoneStatus.PENDING]: { icon: 'pending' as const, color: 'text-brand-muted', bg: 'bg-white/5' },
        [MilestoneStatus.IN_PROGRESS]: { icon: 'progress' as const, color: 'text-status-blue', bg: 'bg-status-blue/10' },
        [MilestoneStatus.IN_REVIEW]: { icon: 'shield-exclamation' as const, color: 'text-status-yellow', bg: 'bg-status-yellow/10' },
        [MilestoneStatus.COMPLETED]: { icon: 'check' as const, color: 'text-status-green', bg: 'bg-status-green/10' },
        [MilestoneStatus.STUCK]: { icon: 'stuck' as const, color: 'text-status-red', bg: 'bg-status-red/10' },
    };
    const cfg = statusMap[milestone.status];

    return (
        <div className={`p-8 rounded-[2.5rem] border border-white/5 backdrop-blur-md transition-all hover:border-brand-accent/30 ${cfg.bg}`}>
            <div className="flex justify-between items-start mb-6">
                <div>
                    <h3 className="text-xl font-black text-white uppercase tracking-tight">{milestone.title}</h3>
                    <p className="text-xs text-brand-muted font-medium mt-1">{milestone.description}</p>
                </div>
                <div className={`flex items-center gap-2 text-[9px] font-black uppercase tracking-widest ${cfg.color}`}>
                    <Icon name={cfg.icon} className="w-4 h-4" />
                    {milestone.status}
                </div>
            </div>
            
            <div className="pt-6 border-t border-white/5 flex gap-3">
                <button 
                    onClick={onVerify} 
                    className="flex-grow bg-brand-accent text-brand-dark font-black py-3 rounded-xl uppercase text-[9px] tracking-widest hover:scale-105 transition-all shadow-glow-cyan"
                >
                    Uplink Documentation
                </button>
                <button className="p-3 rounded-xl bg-white/5 text-brand-muted hover:text-white transition-colors">
                    <Icon name="link" className="w-4 h-4" />
                </button>
            </div>
        </div>
    );
};

export const EntrepreneurView: React.FC<EntrepreneurViewProps> = ({ currentUser, client, showToast }) => {
  const { updateClient } = useClients();
  const [mode, setMode] = useState<ClientDashboardMode>(ClientDashboardMode.BUSINESS_OWNER);

  if (!client) {
      return <InitializationView currentUser={currentUser} showToast={showToast} />;
  }

  const handleMilestoneAction = async (id: string) => {
      const updated = client.milestones.map(m => m.id === id ? { ...m, status: MilestoneStatus.IN_REVIEW } : m);
      await updateClient({ ...client, milestones: updated });
      showToast("Node verification requested.");
  };

  return (
    <div className="bg-[#020617] min-h-screen text-brand-light pb-20">
        <header className="p-8 border-b border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-6">
                <div className="w-16 h-16 rounded-3xl bg-brand-accent text-brand-dark flex items-center justify-center font-black text-3xl shadow-glow-cyan">
                    {client.name[0]}
                </div>
                <div>
                    <h1 className="text-3xl font-black text-white uppercase tracking-tighter">{client.name}</h1>
                    <div className="flex items-center gap-3 mt-1">
                        <span className="text-[10px] font-black text-brand-accent uppercase tracking-widest">Founder Node Identity</span>
                        <div className="w-1 h-1 rounded-full bg-brand-muted/30"></div>
                        <span className="text-[10px] font-black text-brand-muted uppercase tracking-widest">{client.email}</span>
                    </div>
                </div>
            </div>

            <div className="flex bg-brand-primary/20 backdrop-blur-xl p-1.5 rounded-2xl border border-white/5">
                {Object.values(ClientDashboardMode).map(m => (
                    <button 
                        key={m} 
                        onClick={() => setMode(m)} 
                        className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${mode === m ? 'bg-brand-accent text-brand-dark shadow-glow-cyan' : 'text-brand-muted hover:text-white'}`}
                    >
                        {m}
                    </button>
                ))}
            </div>
        </header>

        <main className="p-8 max-w-[1600px] mx-auto space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Left: Strategic Summary */}
                <div className="lg:col-span-8 space-y-8">
                    <div className="bg-brand-primary/20 backdrop-blur-3xl p-10 rounded-[3rem] border border-white/5 relative overflow-hidden group">
                        <div className="absolute top-0 right-0 p-10 opacity-5 group-hover:rotate-12 transition-transform duration-1000">
                             <Icon name="rocket-launch" className="w-40 h-40 text-brand-accent" />
                        </div>
                        <div className="relative z-10">
                            <span className="text-[10px] font-black text-brand-accent uppercase tracking-[0.4em] mb-4 block">Current Strategic Objective</span>
                            <h2 className="text-4xl font-black text-white tracking-tighter uppercase mb-6 leading-tight">{client.businessIdea}</h2>
                            <div className="flex gap-4">
                                <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex items-center gap-3">
                                    <Icon name="shield-check" className="w-5 h-5 text-status-green" />
                                    <div>
                                        <div className="text-[9px] font-black text-brand-muted uppercase tracking-widest">Protocol Integrity</div>
                                        <div className="text-sm font-black text-white uppercase">Optimal</div>
                                    </div>
                                </div>
                                <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex items-center gap-3">
                                    <Icon name="currency-dollar" className="w-5 h-5 text-brand-accent" />
                                    <div>
                                        <div className="text-[9px] font-black text-brand-muted uppercase tracking-widest">Allocated GU</div>
                                        <div className="text-sm font-black text-white uppercase">4,200 Credits</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {client.milestones.map(m => (
                            <MilestoneNode key={m.id} milestone={m} onVerify={() => handleMilestoneAction(m.id)} />
                        ))}
                    </div>
                </div>

                {/* Right: Network Intelligence */}
                <div className="lg:col-span-4 space-y-8">
                    <div className="bg-brand-accent/5 p-10 rounded-[3rem] border border-brand-accent/20">
                        <div className="flex items-center gap-3 mb-6">
                            <Icon name="sparkles" className="w-8 h-8 text-brand-accent" />
                            <h3 className="text-xl font-black text-white uppercase tracking-tighter">Neural Insight</h3>
                        </div>
                        <p className="text-sm font-medium text-brand-muted leading-relaxed mb-8">
                            Your 'Strategic Plan' protocol is 85% complete. The system recommends initializing the 'Modality Hardware' procurement phase to unlock the next GU tranche.
                        </p>
                        <button className="w-full bg-white text-brand-dark font-black py-4 rounded-2xl uppercase text-[10px] tracking-widest hover:scale-105 transition-all">
                            View Protocol Docs
                        </button>
                    </div>

                    <div className="bg-brand-primary/20 backdrop-blur-3xl p-10 rounded-[3rem] border border-white/5">
                        <h3 className="text-xs font-black text-brand-muted uppercase tracking-[0.3em] mb-6">Modality Nodes</h3>
                        <div className="space-y-4">
                            {client.monitoredUrls?.map(u => (
                                <div key={u.id} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 group hover:border-brand-accent/30 transition-all">
                                    <div className="flex items-center gap-3">
                                        <Icon name="link" className="w-5 h-5 text-brand-muted group-hover:text-brand-accent" />
                                        <span className="text-[10px] font-black text-white uppercase tracking-widest">{u.label}</span>
                                    </div>
                                    <span className={`text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-tighter ${u.status === UrlStatus.ONLINE ? 'bg-status-green/20 text-status-green' : 'bg-status-red/20 text-status-red'}`}>
                                        {u.status}
                                    </span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
  );
};
