
import React from 'react';
import { Icon } from '../ui/Icon';

const DevOpsCard = ({ icon, title, description }: { icon: 'cog' | 'check' | 'shield-check' | 'cube', title: string, description: string }) => (
    <div className="bg-brand-primary/50 backdrop-blur-lg p-8 rounded-2xl shadow-2xl border border-brand-secondary h-full hover:border-brand-accent/50 hover:shadow-brand-accent/20 transition-all">
        <div className="w-16 h-16 mb-5 bg-brand-accent/10 rounded-full flex items-center justify-center ring-2 ring-brand-accent/30">
            <Icon name={icon} className="w-10 h-10 text-brand-accent" />
        </div>
        <h3 className="text-xl font-bold text-white mb-3">{title}</h3>
        <p className="text-brand-muted">{description}</p>
    </div>
);

export const AutoDevOpsView: React.FC = () => {
    return (
        <div className="bg-brand-dark">
            {/* Hero Section */}
            <section className="bg-brand-primary/50 text-white py-16 px-4 text-center rounded-b-2xl">
                <div className="w-16 h-16 mx-auto mb-4 bg-brand-accent/10 rounded-full flex items-center justify-center ring-2 ring-brand-accent/30">
                    <Icon name="cog" className="w-10 h-10 text-brand-accent animate-spin" style={{ animationDuration: '10s' }} />
                </div>
                <h1 className="text-4xl font-extrabold tracking-tight">Automated DevOps Pipeline</h1>
                <p className="mt-4 text-lg text-brand-muted max-w-3xl mx-auto">Our commitment to a secure, reliable, and cutting-edge platform powered by modern development practices.</p>
            </section>

            {/* Main Content */}
            <section className="py-20 px-4">
                <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    <DevOpsCard
                        icon="cog"
                        title="Continuous Integration & Delivery (CI/CD)"
                        description="Every code change is automatically built, tested, and prepared for deployment, ensuring rapid and reliable updates to the platform."
                    />
                    <DevOpsCard
                        icon="check"
                        title="Automated Testing"
                        description="A comprehensive suite of automated tests runs on every update, verifying functionality and preventing regressions before they reach users."
                    />
                    <DevOpsCard
                        icon="shield-check"
                        title="Continuous Security Scanning"
                        description="We automatically scan for vulnerabilities in our code and its dependencies, ensuring the platform remains secure against emerging threats."
                    />
                     <DevOpsCard
                        icon="cube"
                        title="Containerization & Orchestration"
                        description="We use Docker and Kubernetes to package and manage our services, ensuring high availability, scalability, and consistent deployments."
                    />
                </div>
            </section>
        </div>
    );
};

export default AutoDevOpsView;