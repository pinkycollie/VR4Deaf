
import React, { useState, useMemo, useEffect } from 'react';
import { Job } from '../../types';
import { Icon } from '../ui/Icon';
import * as api from '../../services/apiService';

interface PlacementViewProps {
  showToast: (message: string) => void;
  onSelectResource: (topic: string, title: string) => void;
}

const CareerNodeCard: React.FC<{ job: Job, onApply: (jobId: string, title: string) => void }> = ({ job, onApply }) => {
    const typeColors = {
        'Full-time': 'bg-brand-primary text-white border-brand-primary',
        'Part-time': 'bg-slate-100 text-slate-600 border-slate-200',
        'Contract': 'bg-brand-gold text-brand-primary border-brand-gold',
        'Remote': 'bg-status-green/10 text-status-green border-status-green/30',
    };

    return (
        <div className="bg-white p-10 rounded-[3rem] border border-slate-200 hover:border-brand-accent transition-all flex flex-col justify-between group shadow-sm hover:shadow-card overflow-hidden relative">
            <div className="absolute top-0 right-0 p-8 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity">
                <Icon name="briefcase" className="w-32 h-32" />
            </div>
            <div className="relative z-10">
                <div className="flex justify-between items-start mb-6">
                    <h3 className="text-2xl font-display font-black text-brand-primary uppercase tracking-tighter leading-none pr-8">{job.title}</h3>
                    <span className={`text-[9px] font-black px-3 py-1 rounded-full border uppercase tracking-widest ${typeColors[job.type as keyof typeof typeColors] || typeColors['Remote']}`}>{job.type}</span>
                </div>
                <div className="flex items-center gap-3 text-[10px] font-black text-slate-400 uppercase tracking-widest mb-8">
                    <span className="text-brand-accent">{job.company}</span>
                    <span className="w-1 h-1 rounded-full bg-slate-200"></span>
                    <span>{job.location}</span>
                </div>
                <p className="text-sm text-slate-500 font-bold uppercase tracking-tight leading-relaxed mb-10 h-16 overflow-hidden opacity-70 group-hover:opacity-100 transition-opacity">{job.description}</p>
            </div>
            <div className="space-y-6 relative z-10">
                <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">CIE Standards Met</span>
                    <div className="flex items-center gap-2">
                        <Icon name="check-badge" className="w-4 h-4 text-status-green" />
                        <span className="text-[10px] font-black text-status-green uppercase">Verified Trajectory</span>
                    </div>
                </div>
                <button 
                    onClick={() => onApply(job.id, job.title)} 
                    className="w-full bg-brand-primary text-white font-black py-5 rounded-2xl uppercase text-[11px] tracking-[0.3em] hover:bg-brand-secondary hover:scale-[1.02] active:scale-95 transition-all shadow-federal"
                >
                    Initialize Application Sync
                </button>
            </div>
        </div>
    );
};

export const PlacementView: React.FC<PlacementViewProps> = ({ showToast }) => {
    const [allJobs, setAllJobs] = useState<Job[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
    
    useEffect(() => {
        const fetchJobs = async () => {
            setIsLoading(true);
            const jobs = await api.getJobs();
            setAllJobs(jobs);
            setIsLoading(false);
        };
        fetchJobs();
    }, []);

    const jobTypes = useMemo(() => [...new Set(allJobs.map(j => j.type))], [allJobs]);

    const filteredJobs = useMemo(() => {
        return allJobs.filter(job => {
            const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) || job.company.toLowerCase().includes(searchTerm.toLowerCase());
            const matchesType = selectedTypes.length === 0 || selectedTypes.includes(job.type);
            return matchesSearch && matchesType;
        });
    }, [searchTerm, selectedTypes, allJobs]);

    const handleApply = async (jobId: string, jobTitle: string) => {
        try {
            await api.applyForJob(jobId);
            showToast(`Trajectory initialized for "${jobTitle}". System sync complete.`);
        } catch (error) {
            showToast(`Protocol sync error.`);
        }
    };

    return (
        <div className="bg-brand-light min-h-screen text-slate-800 pb-20 font-sans">
            <header className="relative py-32 px-6 border-b border-slate-200 bg-white overflow-hidden text-center">
                <div className="absolute top-0 left-0 w-full h-1.5 bg-brand-accent shadow-glow-cyan"></div>
                <div className="absolute inset-0 bg-grid-slate-100 opacity-40"></div>
                
                <div className="relative z-10 max-w-4xl mx-auto">
                    <div className="inline-flex items-center gap-3 px-5 py-2 rounded-full bg-brand-primary text-white text-[10px] font-black uppercase tracking-[0.4em] mb-10 shadow-federal">
                        <Icon name="briefcase" className="w-3.5 h-3.5 text-brand-accent" />
                        career.vr4deaf.org | TALENT DEPLOYMENT
                    </div>
                    <h1 className="text-6xl md:text-8xl font-display font-black text-brand-primary tracking-tighter uppercase mb-8 leading-none">
                        Career <span className="text-brand-accent">Pod.</span>
                    </h1>
                    <p className="text-xl md:text-2xl text-slate-400 font-bold uppercase tracking-tight leading-tight max-w-3xl mx-auto">
                        Authorized trajectories for Deaf professionals targeting competitive integrated employment.
                    </p>
                </div>
            </header>

            <div className="max-w-[1900px] mx-auto px-6 py-20">
                {/* Telemetry Dashboard for Career Mesh */}
                <div className="mb-20 grid grid-cols-2 md:grid-cols-4 gap-6">
                    {[
                        { label: 'RSA-911 Link', val: 'ACTIVE', color: 'text-status-green', icon: 'signal' },
                        { label: 'Verified Nodes', val: '420+', color: 'text-brand-accent', icon: 'users' },
                        { label: 'CIE Integrity', val: 'OPTIMAL', color: 'text-brand-gold', icon: 'shield-check' },
                        { label: 'Deployment Pulse', val: 'HIGH', color: 'text-brand-primary', icon: 'rocket-launch' }
                    ].map((stat, i) => (
                        <div key={i} className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm flex items-center gap-6">
                            <div className="p-4 rounded-2xl bg-brand-light text-slate-400">
                                <Icon name={stat.icon as any} className={`w-6 h-6 ${stat.color}`} />
                            </div>
                            <div>
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-2">{stat.label}</p>
                                <p className={`text-2xl font-display font-black uppercase tracking-tighter ${stat.color}`}>{stat.val}</p>
                            </div>
                        </div>
                    ))}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
                    {/* Refined Sidebar */}
                    <div className="lg:col-span-3 space-y-10">
                        <div className="bg-white p-10 rounded-[3.5rem] border border-slate-200 shadow-sm">
                            <h3 className="text-[10px] font-black text-brand-primary uppercase tracking-[0.4em] mb-10 italic">Search Topology</h3>
                            <div className="relative mb-12">
                                <input 
                                    type="text"
                                    placeholder="Enter Keyword..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="w-full bg-brand-light px-6 py-5 pl-14 rounded-2xl border border-slate-100 text-sm font-bold focus:border-brand-accent outline-none shadow-inner"
                                />
                                <Icon name="magnifying-glass" className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                            </div>

                            <h3 className="text-[10px] font-black text-brand-primary uppercase tracking-[0.4em] mb-6 italic">Modality Filters</h3>
                            <div className="space-y-3">
                                {jobTypes.map(type => (
                                    <button
                                        key={type}
                                        onClick={() => setSelectedTypes(prev => prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type])}
                                        className={`w-full text-left px-6 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border ${selectedTypes.includes(type) ? 'bg-brand-primary text-white border-brand-primary shadow-federal' : 'bg-white border-slate-100 text-slate-500 hover:bg-slate-50'}`}
                                    >
                                        {type}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="bg-brand-primary p-12 rounded-[3.5rem] text-white shadow-federal relative overflow-hidden group">
                            <div className="absolute top-0 right-0 p-8 opacity-[0.05] group-hover:rotate-12 transition-transform duration-1000">
                                <Icon name="shield-check" className="w-40 h-40 text-brand-gold" />
                            </div>
                            <h3 className="text-[10px] font-black text-brand-gold uppercase tracking-[0.4em] mb-8 italic">Policy Enforcement</h3>
                            <p className="text-sm font-bold uppercase tracking-widest leading-relaxed mb-10 opacity-70 group-hover:opacity-100 transition-opacity">
                                Every listing on this pod is audited for competitive integrated employment standards.
                            </p>
                            <button className="w-full bg-white text-brand-primary font-black py-4 rounded-2xl uppercase text-[10px] tracking-widest hover:bg-brand-gold hover:text-white transition-all shadow-sm">
                                Request Access Audit
                            </button>
                        </div>
                    </div>

                    {/* Results Mesh */}
                    <div className="lg:col-span-9">
                        <div className="bg-white p-8 rounded-[3rem] border border-slate-200 flex flex-col md:flex-row justify-between items-center gap-6 shadow-sm mb-12 relative overflow-hidden">
                             <div className="absolute top-0 right-0 p-12 opacity-[0.01]">
                                <Icon name="rocket-launch" className="w-64 h-64 text-brand-primary" />
                            </div>
                            <div className="flex items-center gap-6 relative z-10">
                                <div className="w-12 h-12 bg-status-green/10 rounded-full flex items-center justify-center">
                                    <div className="w-2.5 h-2.5 rounded-full bg-status-green animate-pulse shadow-glow-cyan"></div>
                                </div>
                                <div>
                                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Mesh Status</span>
                                    <span className="text-xs font-black text-brand-primary uppercase tracking-[0.1em]">Scout Protocol Synchronizing...</span>
                                </div>
                            </div>
                            <div className="px-6 py-2 bg-brand-light rounded-full border border-slate-100 relative z-10">
                                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{filteredJobs.length} Verified Target Nodes</span>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-10">
                            {isLoading ? (
                                <div className="col-span-full py-40 flex flex-col items-center gap-6">
                                    <Icon name="cog" className="w-16 h-16 text-brand-primary animate-spin" />
                                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.5em] animate-pulse">QUERYING TALENT MESH...</span>
                                </div>
                            ) : filteredJobs.length > 0 ? (
                                filteredJobs.map(job => (
                                    <CareerNodeCard key={job.id} job={job} onApply={handleApply} />
                                ))
                            ) : (
                                <div className="col-span-full py-40 text-center bg-white rounded-[4rem] border border-dashed border-slate-200 opacity-50">
                                    <Icon name="magnifying-glass" className="w-16 h-16 text-slate-300 mx-auto mb-8" />
                                    <p className="text-3xl font-display font-black text-slate-400 uppercase tracking-tighter">Zero Trajectories Found</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PlacementView;
