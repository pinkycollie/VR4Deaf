import React from 'react';
import { UserRole } from '../../types';
import { Icon } from '../ui/Icon';
import { roleToPath, EXTERNAL_INTAKE_URL, STATS_TRUTH } from '../../constants';

interface HomepageViewProps {
    navigate: (path: string) => void;
}

const HomepageView: React.FC<HomepageViewProps> = ({ navigate }) => {
    return (
        <div className="bg-white min-h-screen">
            <section className="relative pt-20 pb-32 px-4 sm:px-6 lg:px-8">
                <div className="max-w-5xl mx-auto flex flex-col items-center text-center">
                    <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 text-blue-700 text-[11px] font-bold uppercase tracking-wider rounded-full mb-8 border border-blue-100">
                        <div className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse"></div>
                        National Protocol Node v{STATS_TRUTH.WASM_LOGIC_VERSION}
                    </div>

                    <h1 className="text-4xl md:text-6xl font-extrabold text-slate-900 tracking-tight mb-6 leading-tight">
                        Vocational Rehabilitation <br/>Infrastructure for <span className="text-blue-600">Deaf Professionals.</span>
                    </h1>
                    
                    <p className="text-lg md:text-xl text-slate-600 font-medium max-w-2xl mx-auto mb-10 leading-relaxed">
                        Data-driven success systems designed for state agencies, specialized coaches, and competitive workforce outcomes.
                    </p>

                    <div className="flex flex-col sm:flex-row gap-4 w-full max-w-md">
                        <a 
                            href={EXTERNAL_INTAKE_URL}
                            className="flex-1 bg-blue-600 text-white font-bold py-3.5 px-8 rounded-lg transition-all hover:bg-blue-700 shadow-sm text-sm"
                        >
                            Initialize Intake
                        </a>
                        <button 
                            onClick={() => navigate(roleToPath(UserRole.THE_PROCESS))}
                            className="flex-1 bg-white border border-slate-200 text-slate-700 font-bold py-3.5 px-8 rounded-lg transition-all hover:bg-slate-50 text-sm"
                        >
                            View Framework
                        </button>
                    </div>

                    <div className="mt-20 flex flex-wrap justify-center gap-x-10 gap-y-4">
                        {['RSA-911 Compliant', 'HIPAA Secure', 'NIST AAL2', 'Wasm Logic'].map(tag => (
                            <span key={tag} className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400">{tag}</span>
                        ))}
                    </div>
                </div>
            </section>

            <section className="py-24 px-4 sm:px-6 lg:px-8 bg-slate-50 border-y border-slate-200">
                <div className="max-w-7xl mx-auto">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        <div className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm">
                            <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center mb-6">
                                <Icon name="chart-bar" className="w-6 h-6" />
                            </div>
                            <h3 className="text-lg font-bold text-slate-900 mb-3">Economic Impact</h3>
                            <p className="text-slate-600 text-sm leading-relaxed">
                                Bridging the {STATS_TRUTH.GLOBAL_PRODUCTIVITY_LOSS} annual loss in workforce potential identified by WHO standards.
                            </p>
                        </div>
                        <div className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm">
                            <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center mb-6">
                                <Icon name="rocket-launch" className="w-6 h-6" />
                            </div>
                            <h3 className="text-lg font-bold text-slate-900 mb-3">Outcome Velocity</h3>
                            <p className="text-slate-600 text-sm leading-relaxed">
                                Streamlining the intake-to-employment pipeline with a target velocity of {STATS_TRUTH.TARGET_PLACEMENT_VELOCITY}.
                            </p>
                        </div>
                        <div className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm">
                            <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center mb-6">
                                <Icon name="shield-check" className="w-6 h-6" />
                            </div>
                            <h3 className="text-lg font-bold text-slate-900 mb-3">Audit Readiness</h3>
                            <p className="text-slate-600 text-sm leading-relaxed">
                                Automated {STATS_TRUTH.RSA_COMPLIANCE_RATE} RSA-911 data integrity syncs for continuous state agency oversight.
                            </p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default HomepageView;