
import React from 'react';
import { Icon } from '../ui/Icon';
import { STATS_TRUTH } from '../../constants';

export const VersioningPolicyView: React.FC = () => {
    return (
        <div className="bg-[#F8FAFC] min-h-screen text-slate-800 pb-32 font-sans selection:bg-brand-accent/20">
            {/* Standard Header */}
            <header className="pt-32 pb-24 px-6 border-b border-slate-200 bg-white relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1.5 bg-brand-primary"></div>
                <div className="max-w-4xl mx-auto relative z-10">
                    <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded bg-[#0A2F5E] text-white text-[10px] font-black uppercase tracking-[0.4em] mb-12 shadow-sm">
                        <Icon name="cog" className="w-4 h-4 text-brand-gold" />
                        Institutional Standard: SemVer 2.0.0 Adherence
                    </div>
                    <h1 className="text-5xl md:text-8xl font-display font-black text-[#0A2F5E] tracking-tighter leading-[0.85] mb-10 uppercase">
                        Protocol <span className="text-brand-accent">Versioning.</span>
                    </h1>
                    <p className="text-2xl text-slate-500 font-bold leading-relaxed max-w-4xl italic">
                        "Transparency in technical progression ensuring backward compatibility for state agency tranches and secure professional nodes."
                    </p>
                </div>
            </header>

            <main className="py-24 px-6">
                <div className="max-w-4xl mx-auto space-y-20">
                    {/* The Core Logic Section */}
                    <section className="grid grid-cols-1 md:grid-cols-3 gap-10">
                        <div className="p-10 bg-white border border-slate-200 rounded-[2.5rem] shadow-sm flex flex-col items-center text-center">
                            <span className="text-4xl font-black text-brand-accent mb-4">MAJOR</span>
                            <h3 className="text-sm font-black text-[#0A2F5E] uppercase tracking-widest mb-4">Protocol Shifts</h3>
                            <p className="text-xs text-slate-400 font-bold leading-relaxed uppercase tracking-tight">
                                Incremented when incompatible API changes or structural protocol tranches are modified.
                            </p>
                        </div>
                        <div className="p-10 bg-[#0A2F5E] text-white border border-[#0A2F5E] rounded-[2.5rem] shadow-federal flex flex-col items-center text-center">
                            <span className="text-4xl font-black text-brand-gold mb-4">MINOR</span>
                            <h3 className="text-sm font-black uppercase tracking-widest mb-4">Service Tranches</h3>
                            <p className="text-xs text-white/60 font-bold leading-relaxed uppercase tracking-tight">
                                Incremented when adding functionality in a backward compatible manner (e.g. new state nodes).
                            </p>
                        </div>
                        <div className="p-10 bg-white border border-slate-200 rounded-[2.5rem] shadow-sm flex flex-col items-center text-center">
                            <span className="text-4xl font-black text-slate-300 mb-4">PATCH</span>
                            <h3 className="text-sm font-black text-[#0A2F5E] uppercase tracking-widest mb-4">Remediation</h3>
                            <p className="text-xs text-slate-400 font-bold leading-relaxed uppercase tracking-tight">
                                Incremented for backward compatible bug fixes and UI/UX accessibility patches.
                            </p>
                        </div>
                    </section>

                    {/* Technical Specification Summary */}
                    <section className="bg-white p-12 md:p-16 rounded-[3rem] border border-slate-200 shadow-sm relative overflow-hidden">
                        <h2 className="text-xs font-black text-brand-accent uppercase tracking-[0.5em] mb-10">Summary of Specification</h2>
                        <div className="prose prose-slate max-w-none space-y-6 text-sm leading-relaxed text-slate-600 font-medium">
                            <p>
                                Software using Semantic Versioning MUST declare a public API. This API is defined in our <strong>Developer Hub</strong>.
                            </p>
                            <p>
                                A normal version number MUST take the form <code className="text-brand-accent font-black">X.Y.Z</code> where X, Y, and Z are non-negative integers. X is the major version, Y is the minor version, and Z is the patch version. Each element MUST increase numerically. For instance: 1.9.0 &rarr; 1.10.0 &rarr; 1.11.0.
                            </p>
                            <div className="p-8 bg-slate-50 border border-slate-100 rounded-2xl">
                                <h4 className="text-[10px] font-black text-[#0A2F5E] uppercase tracking-[0.2em] mb-3">Institutional Constraint</h4>
                                <p className="text-xs italic text-slate-500">
                                    "The VR4Deaf Success Protocol (VURI™) strictly adheres to Semantic Versioning 2.0.0 to prevent dependency hell within state legacy system integrations."
                                </p>
                            </div>
                        </div>
                    </section>

                    {/* Why SemVer Callout */}
                    <section className="text-center py-10">
                        <Icon name="shield-check" className="w-16 h-16 text-brand-accent mx-auto mb-8" />
                        <h3 className="text-3xl font-display font-black text-[#0A2F5E] uppercase tracking-tight mb-6">Security & Predictability</h3>
                        <p className="text-lg text-slate-400 font-bold uppercase tracking-widest max-w-3xl mx-auto leading-relaxed">
                            By adhering to a formal versioning standard, we provide state auditors and federal partners with a clear, auditable timeline of system logic evolution.
                        </p>
                    </section>
                </div>
            </main>

            <footer className="mt-12 text-center">
                 <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.5em]">REFERENCE: SEMVER.ORG // CURRENT NODE VERSION: {STATS_TRUTH.WASM_LOGIC_VERSION}</p>
            </footer>
        </div>
    );
};
