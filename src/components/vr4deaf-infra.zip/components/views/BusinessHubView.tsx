import React from 'react';
import { Icon } from '../ui/Icon';
import { UserRole } from '../../types';
import { roleToPath } from '../../constants';

interface BusinessHubViewProps {
    navigate: (path: string) => void;
}

export const BusinessHubView: React.FC<BusinessHubViewProps> = ({ navigate }) => {
    return (
        <div className="bg-slate-50 min-h-screen text-slate-900 pb-24">
            <header className="pt-20 pb-12 px-4 sm:px-6 lg:px-8 border-b border-slate-200 bg-white">
                <div className="max-w-7xl mx-auto">
                    <div className="inline-flex items-center gap-2 text-blue-600 text-[10px] font-bold uppercase tracking-wider mb-4">
                        <Icon name="lightbulb" className="w-4 h-4" />
                        business.vr4deaf.org | Venture Hub
                    </div>
                    <h1 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight">Business Pod</h1>
                    <p className="text-base text-slate-500 font-medium max-w-2xl mt-1 leading-relaxed">
                        Authorized resources for independent Deaf founders and competitive workforce ventures.
                    </p>
                </div>
            </header>

            <section className="py-12 px-4 sm:px-6 lg:px-8">
                <div className="max-w-7xl mx-auto">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                        <div className="p-8 bg-slate-900 text-white rounded-xl shadow-lg flex flex-col justify-between min-h-[160px]">
                            <span className="text-[10px] font-bold uppercase tracking-widest opacity-60">Success Benchmark</span>
                            <div className="text-4xl font-black">98.4%</div>
                            <p className="text-[11px] font-medium opacity-80 uppercase tracking-tight">RSA-911 Compliance Standard</p>
                        </div>
                        <button 
                            onClick={() => navigate(roleToPath(UserRole.POLICY_PULSE))}
                            className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm text-left hover:bg-blue-50/30 hover:border-blue-200 flex flex-col justify-between min-h-[160px] transition-all group"
                        >
                            <div className="flex justify-between items-start">
                                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Live Telemetry</span>
                                <Icon name="signal" className="w-5 h-5 text-blue-600" />
                            </div>
                            <div className="text-2xl font-bold text-slate-900">Policy Pulse</div>
                            <p className="text-[11px] font-bold text-blue-600 group-hover:translate-x-1 transition-transform uppercase">Analyze Funding &rarr;</p>
                        </button>
                        <div className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between min-h-[160px]">
                            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Node Status</span>
                            <div className="flex items-center gap-3">
                                <div className="w-2.5 h-2.5 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.4)] animate-pulse"></div>
                                <div className="text-3xl font-black text-slate-900">ACTIVE</div>
                            </div>
                            <p className="text-[11px] font-medium text-slate-400 uppercase tracking-tight">Master Gateway Sync</p>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {[
                            { title: 'Formation', desc: 'Secure LLC/Entity root-mounting synchronized with state tranches.', icon: 'shield-check' as const },
                            { title: 'Capital Sync', desc: 'Secure revenue tranches with SSI/SSDI benefit protections.', icon: 'currency-dollar' as const },
                            { title: 'Procurement', desc: 'Direct state-authorized hardware and labor resource marketplace.', icon: 'shopping-cart' as const }
                        ].map(card => (
                            <div key={card.title} className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm flex flex-col">
                                <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center mb-6">
                                    <Icon name={card.icon} className="w-6 h-6" />
                                </div>
                                <h3 className="text-xl font-bold mb-3 text-slate-900">{card.title}</h3>
                                <p className="text-sm text-slate-600 leading-relaxed mb-8 flex-grow">{card.desc}</p>
                                <button className="w-full py-3 bg-slate-50 text-slate-900 border border-slate-200 text-xs font-bold rounded-lg hover:bg-slate-100 transition-colors uppercase tracking-widest">
                                    Initialize Protocol
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
            
            <section className="py-20 px-4 sm:px-6 lg:px-8 text-center bg-white border-t border-slate-200">
                <div className="max-w-4xl mx-auto">
                    <h2 className="text-2xl font-black mb-4">High-Growth Strategic Mesh</h2>
                    <p className="text-slate-500 mb-8 max-w-2xl mx-auto leading-relaxed">If your objective exceeds agency fee schedules, uplink to our private partner mesh for specialized scaling resources.</p>
                    <button className="bg-blue-600 text-white font-bold py-3.5 px-10 rounded-lg hover:bg-blue-700 transition-all shadow-sm text-sm uppercase tracking-widest">
                        Uplink to Magicians™
                    </button>
                </div>
            </section>
        </div>
    );
};

export default BusinessHubView;