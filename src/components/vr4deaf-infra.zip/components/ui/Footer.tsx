
import React from 'react';
import { Icon } from './Icon';
import { Logo } from './Logo';
import { UserRole } from '../../types';
import { roleToPath } from '../../constants';

interface FooterProps {
  navigate?: (path: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ navigate }) => {
  return (
    <footer className="bg-white text-slate-600 pt-32 pb-20 px-6 border-t border-slate-100 relative overflow-hidden">
        <div className="max-w-7xl mx-auto flex flex-col items-center relative z-10">
            
            <div className="grid grid-cols-1 md:grid-cols-12 gap-20 w-full mb-24 items-start">
                <div className="md:col-span-4 space-y-10">
                    <div className="flex items-center gap-5 cursor-pointer" onClick={() => navigate?.('/')}>
                        <div className="w-16 h-16 bg-white border border-slate-200 rounded-2xl shadow-federal p-3 flex items-center justify-center">
                            <Logo className="w-full h-full" />
                        </div>
                        <div>
                            <h2 className="text-[#0A2F5E] text-2xl font-display font-black uppercase tracking-tight leading-none">
                                VR4DEAF.ORG
                            </h2>
                            <span className="text-[11px] font-bold text-brand-accent uppercase tracking-[0.3em] mt-2 block">Vocational Rehabilitation Services</span>
                        </div>
                    </div>
                    <p className="text-sm leading-relaxed max-w-sm font-medium text-slate-500">
                        The centralized system of record for Vocational Rehabilitation (VR). NOT a Virtual Reality/AR platform. Purpose-built for employment outcomes and federal compliance.
                    </p>
                </div>

                <div className="md:col-span-5 grid grid-cols-2 gap-12 text-sm font-bold uppercase tracking-widest">
                    <div>
                        <h4 className="text-[12px] font-black text-[#0A2F5E] mb-10">Provision Nodes</h4>
                        <ul className="space-y-6">
                            <li><button onClick={() => navigate?.(roleToPath(UserRole.BUSINESS_HUB))} className="hover:text-brand-accent">Business Pod</button></li>
                            <li><button onClick={() => navigate?.(roleToPath(UserRole.JOB_PLACEMENT))} className="hover:text-brand-accent">Career Pod</button></li>
                            <li><button onClick={() => navigate?.(roleToPath(UserRole.STATE_PROGRAMS))} className="hover:text-brand-accent">State Directory</button></li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="text-[12px] font-black text-[#0A2F5E] mb-10">Infrastructure</h4>
                        <ul className="space-y-6">
                            <li><button onClick={() => navigate?.(roleToPath(UserRole.API_DOCS))} className="hover:text-brand-accent">API Gateway</button></li>
                            <li><button onClick={() => navigate?.(roleToPath(UserRole.SUCCESS_LEDGER))} className="hover:text-brand-accent text-brand-accent">Success Ledger</button></li>
                            <li><button onClick={() => navigate?.(roleToPath(UserRole.CHANGELOG))} className="hover:text-brand-accent">System Pulse</button></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div className="w-full pt-12 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-10">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">
                    &copy; {new Date().getFullYear()} VR4DEAF.ORG // VOCATIONAL REHABILITATION (VR) SUCCESS PROTOCOL V3.4
                </span>
                <div className="flex items-center gap-5 py-3 px-8 bg-slate-50 border border-slate-100 rounded-full">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">ENGINEERED BY</span>
                    <a href="https://mbtq.dev" target="_blank" className="text-xs font-black text-[#0A2F5E] hover:text-brand-accent tracking-tighter uppercase">MBTQ SOLUTIONS</a>
                </div>
            </div>
            
            <div className="mt-20 max-w-4xl text-center">
                <p className="text-[10px] text-slate-300 font-bold uppercase tracking-[0.4em]">
                    Institutional Disclaimer: Vocational Rehabilitation refers to services assisting individuals with disabilities in achieving employment goals. This platform strictly adheres to SemVer 2.0.0.
                </p>
            </div>
        </div>
    </footer>
  );
};
