
import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className = "h-10 w-auto" }) => {
  return (
    <svg 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg" 
      className={className}
    >
      {/* Institutional Deep Blue Shield (Base) */}
      <circle cx="50" cy="50" r="45" fill="#0A2F5E" />
      
      {/* Success Bridge Path (Golden Arch) */}
      <path 
        d="M20 75 C20 40, 80 40, 80 75" 
        stroke="#C5A059" 
        strokeWidth="6" 
        strokeLinecap="round"
        fill="none"
      />

      {/* Upward Trajectory Arrow */}
      <path 
        d="M50 45 L50 20 M40 30 L50 20 L60 30" 
        stroke="#FFFFFF" 
        strokeWidth="5" 
        strokeLinecap="round" 
        strokeLinejoin="round" 
      />
      
      {/* Symbolic "Hands" Framing Success */}
      <path 
        d="M30 65 Q40 60 50 65 Q60 70 70 65" 
        stroke="#C5A059" 
        strokeWidth="4" 
        strokeLinecap="round"
        fill="none"
        opacity="0.6"
      />
      
      {/* Central Connectivity Node */}
      <circle cx="50" cy="45" r="3" fill="#FFFFFF" />

      {/* Fine Detail Accents */}
      <circle cx="20" cy="75" r="2" fill="#C5A059" />
      <circle cx="80" cy="75" r="2" fill="#C5A059" />
    </svg>
  );
};
