
import React, { useState, useEffect } from 'react';
import { Icon } from './Icon';

export const FontSizeController: React.FC = () => {
    const [size, setSize] = useState(16);
    const [isOpen, setIsOpen] = useState(false);

    useEffect(() => {
        document.documentElement.style.fontSize = `${size}px`;
    }, [size]);

    return (
        <div className="fixed bottom-6 left-6 z-[100] flex flex-col items-start gap-4 pointer-events-none">
            {isOpen && (
                <div className="pointer-events-auto bg-brand-primary/95 backdrop-blur-2xl border-2 border-brand-accent/30 p-6 shadow-glow-cyan animate-fade-in-up flex flex-col items-center gap-6 clip-edge min-w-[100px]">
                    <div className="text-[10px] font-black text-brand-accent uppercase tracking-[0.4em] mb-2">SCALE</div>
                    
                    <button 
                        onClick={() => setSize(s => Math.min(s + 1, 24))}
                        className="w-14 h-14 bg-white/5 border border-white/10 flex items-center justify-center hover:bg-brand-accent hover:text-brand-dark transition-all text-xl font-black italic shadow-soft"
                        aria-label="Increase font size"
                    >
                        A+
                    </button>
                    
                    <div className="h-40 w-2.5 bg-black/40 rounded-none relative overflow-hidden border border-white/5">
                        <div 
                            className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-brand-accent to-brand-pink transition-all duration-300 shadow-glow-pink" 
                            style={{ height: `${((size - 12) / 12) * 100}%` }}
                        />
                    </div>
                    
                    <button 
                        onClick={() => setSize(s => Math.max(s - 1, 12))}
                        className="w-14 h-14 bg-white/5 border border-white/10 flex items-center justify-center hover:bg-brand-pink hover:text-white transition-all text-sm font-bold shadow-soft"
                        aria-label="Decrease font size"
                    >
                        A-
                    </button>
                    
                    <div className="text-[11px] font-black text-white bg-brand-accent/20 px-3 py-1 italic tracking-widest">{size}PX</div>
                </div>
            )}
            
            <button 
                onClick={() => setIsOpen(!isOpen)}
                className="pointer-events-auto w-16 h-16 bg-brand-primary border-2 border-brand-accent/50 flex items-center justify-center shadow-glow-cyan hover:scale-110 transition-all transform active:scale-95 group relative clip-edge overflow-hidden"
                aria-label="Toggle font size controller"
            >
                <div className="absolute inset-0 bg-brand-accent/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div className="text-white font-black group-hover:text-brand-accent transition-colors text-xl italic tracking-tighter">Aa</div>
            </button>
        </div>
    );
};
