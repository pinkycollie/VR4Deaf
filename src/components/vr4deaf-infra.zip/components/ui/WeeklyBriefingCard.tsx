import React from 'react';
import { Icon } from './Icon';
import { WeeklyBriefing } from '../../types';

interface WeeklyBriefingCardProps {
    briefing: WeeklyBriefing | null;
    isLoading: boolean;
    title: string;
}

export const WeeklyBriefingCard: React.FC<WeeklyBriefingCardProps> = ({ briefing, isLoading, title }) => {
    if (isLoading) {
        return (
            <div className="bg-brand-primary/50 backdrop-blur-lg p-6 sm:p-8 rounded-2xl shadow-2xl border border-brand-secondary text-center">
                <Icon name="cog" className="w-8 h-8 text-brand-accent animate-spin mx-auto" />
                <p className="mt-4 text-brand-muted">VURI™ is preparing your weekly briefing...</p>
            </div>
        );
    }

    if (!briefing) {
        return null;
    }

    return (
        <div className="bg-brand-primary/50 backdrop-blur-lg p-6 sm:p-8 rounded-2xl shadow-2xl border border-brand-accent/50">
            <div className="flex items-center gap-4 mb-6">
                <Icon name="sparkles" className="w-10 h-10 text-brand-accent flex-shrink-0" />
                <div>
                    <h2 className="text-2xl font-bold text-white">{title}</h2>
                    <p className="text-brand-muted">Your AI-powered summary for this week.</p>
                </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Highlights */}
                <div className="space-y-3">
                    <h3 className="flex items-center gap-2 font-semibold text-brand-light">
                        <Icon name="arrow-up-circle" className="w-6 h-6 text-status-green" />
                        <span>Highlights</span>
                    </h3>
                    <ul className="space-y-2 pl-2">
                        {briefing.highlights.map((item, index) => (
                            <li key={index} className="text-sm text-brand-light/90">{item}</li>
                        ))}
                    </ul>
                </div>

                {/* Suggestions */}
                <div className="space-y-3">
                    <h3 className="flex items-center gap-2 font-semibold text-brand-light">
                        <Icon name="lightbulb" className="w-6 h-6 text-status-blue" />
                        <span>AI Suggestions</span>
                    </h3>
                    <ul className="space-y-2 pl-2">
                        {briefing.suggestions.map((item, index) => (
                            <li key={index} className="text-sm text-brand-light/90">{item}</li>
                        ))}
                    </ul>
                </div>

                {/* Attention Items */}
                 <div className="space-y-3">
                    <h3 className="flex items-center gap-2 font-semibold text-brand-light">
                        <Icon name="flag" className="w-6 h-6 text-status-red" />
                        <span>Needs Attention</span>
                    </h3>
                    {briefing.attentionItems.length > 0 ? (
                         <ul className="space-y-2 pl-2">
                            {briefing.attentionItems.map((item, index) => (
                                <li key={index} className="text-sm text-brand-light/90">
                                    <strong>{item.clientName}:</strong> {item.reason}
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="text-sm text-brand-muted pl-2">All clients are on track!</p>
                    )}
                </div>
            </div>
        </div>
    );
};