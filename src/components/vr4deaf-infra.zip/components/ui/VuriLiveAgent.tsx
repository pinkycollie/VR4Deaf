
import React, { useState, useEffect } from 'react';
import { Icon } from './Icon';
import { VuriAdvice } from '../../types';
import * as api from '../../services/apiService';

interface VuriLiveAgentProps {
    viewName: string;
    contextData?: any;
}

export const VuriLiveAgent: React.FC<VuriLiveAgentProps> = ({ viewName, contextData }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [advice, setAdvice] = useState<VuriAdvice | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        if (isOpen && !advice) {
            handleFetchAdvice();
        }
    }, [isOpen]);

    const handleFetchAdvice = async () => {
        setIsLoading(true);
        try {
            const result = await api.generateContextualAdvice(viewName, contextData);
            setAdvice(result);
        } catch (error) {
            console.error(error);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="fixed bottom-24 right-6 z-50 flex flex-col items-end pointer-events-none">
            {isOpen && (
                <div className="pointer-events-auto mb-4 w-80 sm:w-96 bg-brand-primary/90 backdrop-blur-xl border border-brand-accent/30 rounded-2xl shadow-2xl overflow-hidden animate-fade-in-up">
                    <div className="bg-brand-accent/20 p-4 border-b border-brand-accent/30 flex justify-between items-center">
                        <div className="flex items-center gap-2">
                            <Icon name="sparkles" className="w-5 h-5 text-brand-accent" />
                            <h3 className="font-bold text-brand-light">VURI™ Live Co-Pilot</h3>
                        </div>
                        <button onClick={() => setIsOpen(false)} className="text-brand-muted hover:text-white">
                            <Icon name="x-mark" className="w-5 h-5" />
                        </button>
                    </div>
                    
                    <div className="p-5 space-y-4 max-h-[60vh] overflow-y-auto">
                        {isLoading ? (
                            <div className="py-10 flex flex-col items-center justify-center gap-3">
                                <Icon name="cpu-chip" className="w-10 h-10 text-brand-accent animate-spin" />
                                <p className="text-sm text-brand-muted">VURI is analyzing your context...</p>
                            </div>
                        ) : advice ? (
                            <>
                                <div>
                                    <h4 className="text-xs font-bold text-brand-accent uppercase tracking-wider mb-2">Current Insight</h4>
                                    <p className="text-brand-light text-sm italic">"{advice.insight}"</p>
                                </div>
                                <div className="p-3 bg-brand-dark/50 rounded-lg border border-brand-secondary">
                                    <h4 className="text-xs font-bold text-brand-muted uppercase tracking-wider mb-1">Summary</h4>
                                    <p className="text-brand-light text-sm">{advice.summary}</p>
                                </div>
                                <div>
                                    <h4 className="text-xs font-bold text-brand-accent uppercase tracking-wider mb-3">Recommended Actions</h4>
                                    <div className="space-y-2">
                                        {advice.actions.map((action, i) => (
                                            <div key={i} className="flex items-center justify-between p-2 rounded bg-brand-secondary/30 border border-brand-secondary group hover:border-brand-accent/50 transition-colors">
                                                <span className="text-sm text-brand-light">{action.label}</span>
                                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                                                    action.priority === 'high' ? 'bg-status-red/20 text-status-red' :
                                                    action.priority === 'medium' ? 'bg-status-yellow/20 text-status-yellow' :
                                                    'bg-status-blue/20 text-status-blue'
                                                }`}>
                                                    {action.priority}
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <button onClick={handleFetchAdvice} className="w-full py-2 text-xs font-semibold text-brand-muted hover:text-brand-accent transition-colors">
                                    Refresh Insights
                                </button>
                            </>
                        ) : (
                            <p className="text-center py-4 text-brand-muted">No insights available right now.</p>
                        )}
                    </div>
                </div>
            )}
            
            <button 
                onClick={() => setIsOpen(!isOpen)} 
                className="pointer-events-auto w-16 h-16 bg-brand-accent text-brand-dark rounded-full shadow-glow-cyan flex items-center justify-center transition-all transform hover:scale-110 active:scale-95 group relative"
            >
                <div className="absolute inset-0 bg-brand-accent rounded-full animate-ping opacity-20"></div>
                <Icon name="sparkles" className={`w-8 h-8 transition-transform ${isOpen ? 'rotate-90' : ''}`} />
            </button>
        </div>
    );
};
