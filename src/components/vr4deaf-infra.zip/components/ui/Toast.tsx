
import React, { useState, useEffect } from 'react';

interface ToastProps {
  message: string;
  show: boolean;
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, show, onClose }) => {
  useEffect(() => {
    if (show) {
      const timer = setTimeout(() => {
        onClose();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [show, onClose]);

  if (!show) {
    return null;
  }

  return (
    <div className="fixed bottom-5 right-5 bg-brand-primary/80 backdrop-blur-sm text-white py-3 px-6 rounded-xl shadow-lg border border-brand-accent/50 animate-fade-in-up z-50">
      <p>{message}</p>
    </div>
  );
};