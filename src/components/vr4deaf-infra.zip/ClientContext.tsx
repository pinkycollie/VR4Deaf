import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { Client, MonitoredUrl, UrlStatus, AuthenticatedUser } from './types';
import * as api from './services/apiService';

interface ClientContextType {
    clients: Client[];
    isLoading: boolean;
    addClient: (clientData: Pick<Client, 'name' | 'email' | 'businessIdea'>) => Promise<Client>;
    createClientForUser: (user: AuthenticatedUser, businessIdea: string) => Promise<Client>;
    updateClient: (updatedClient: Client) => Promise<Client>;
    addMonitoredUrl: (clientId: string, label: string, url: string) => Promise<void>;
    updateMonitoredUrlStatus: (clientId: string, urlId: string, status: UrlStatus) => Promise<void>;
}

const ClientContext = createContext<ClientContextType | undefined>(undefined);

export const ClientProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [clients, setClients] = useState<Client[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    const refreshClients = useCallback(async () => {
        const fetchedClients = await api.getClients();
        setClients(fetchedClients);
    }, []);

    useEffect(() => {
        setIsLoading(true);
        refreshClients().finally(() => setIsLoading(false));
    }, [refreshClients]);

    const addClient = async (clientData: Pick<Client, 'name' | 'email' | 'businessIdea'>) => {
        const newClient = await api.addClient(clientData);
        await refreshClients();
        return newClient;
    };

    const createClientForUser = async (user: AuthenticatedUser, businessIdea: string) => {
        const clientData = {
            name: user.displayName,
            email: user.email,
            businessIdea: businessIdea,
        };
        const newClient = await api.addClient(clientData);
        await refreshClients();
        return newClient;
    }

    const updateClient = async (updatedClient: Client) => {
        const result = await api.updateClient(updatedClient);
        await refreshClients();
        return result;
    };

    const addMonitoredUrl = async (clientId: string, label: string, url: string) => {
        const client = clients.find(c => c.id === clientId);
        if (!client) throw new Error("Client not found");

        const newUrl: MonitoredUrl = { id: `url-${Date.now()}`, label, url, status: UrlStatus.PENDING };
        const updatedUrls = [...(client.monitoredUrls || []), newUrl];
        await updateClient({ ...client, monitoredUrls: updatedUrls });
    };

    const updateMonitoredUrlStatus = async (clientId: string, urlId: string, status: UrlStatus) => {
        const client = clients.find(c => c.id === clientId);
        if (!client || !client.monitoredUrls) throw new Error("Client or URLs not found");

        const updatedUrls = client.monitoredUrls.map(u => u.id === urlId ? { ...u, status } : u);
        await updateClient({ ...client, monitoredUrls: updatedUrls });
    };

    const value = {
        clients,
        isLoading,
        addClient,
        createClientForUser,
        updateClient,
        addMonitoredUrl,
        updateMonitoredUrlStatus,
    };

    return <ClientContext.Provider value={value}>{children}</ClientContext.Provider>;
};

export const useClients = (): ClientContextType => {
    const context = useContext(ClientContext);
    if (context === undefined) {
        throw new Error('useClients must be used within a ClientProvider');
    }
    return context;
};