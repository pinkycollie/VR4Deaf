
import React, { useState, useCallback, useEffect, createContext, useContext } from 'react';
import { UserRole, AuthenticatedUser, AppLanguage } from './types';
import { PUBLIC_PAGES, roleToPath, pathToRole, EXTERNAL_INTAKE_URL, US_STATES, slugifyState } from './constants';
import { supabase } from './services/supabase';
import { VRPartnerView } from './components/views/VRPartnerView';
import { EntrepreneurView } from './components/views/EntrepreneurView';
import { BusinessSpecialistView } from './components/views/BusinessSpecialistView';
import HomepageView from './components/views/HomepageView';
import { TheProcessView } from './components/views/ServicesView';
import { StateProgramsView } from './components/views/StateProgramsView';
import { EmployerView } from './components/views/EmployerView';
import PlacementView from './components/views/PlacementView';
import { Icon } from './components/ui/Icon';
import { Toast } from './components/ui/Toast';
import { AIToolkitView } from './components/views/AIToolkitView';
import { ChangelogView } from './components/views/ChangelogView';
import ApiDocsView from './components/views/ApiDocsView';
import AutoDevOpsView from './components/views/AutoDevOpsView';
import EcosystemDirectoryView from './components/views/EcosystemDirectoryView';
import { Footer } from './components/ui/Footer';
import PlatformArchitectureView from './components/views/PlatformArchitectureView';
import MyAccountView from './components/views/MyAccountView';
import EcosystemView from './components/views/EcosystemView';
import VendorJourneyView from './components/views/VendorJourneyView';
import VRCounselorJourneyView from './components/views/VRCounselorJourneyView';
import DeveloperJourneyView from './components/views/DeveloperJourneyView';
import { HousingView } from './components/views/HousingView';
import { ClientProvider, useClients } from './ClientContext';
import VRCounselorDashboardView from './components/views/VRCounselorDashboardView';
import AIStoreBlueprintView from './components/views/AIStoreBlueprintView';
import SitemapJourneysView from './components/views/SitemapJourneysView';
import FinancialFlowView from './components/views/FinancialFlowView';
import PricingView from './components/views/PricingView';
import SettingsView from './components/views/SettingsView';
import FounderStoryView from './components/views/FounderStoryView';
import BusinessMagicianView from './components/views/BusinessMagicianView';
import { ComplianceHubView } from './components/views/ComplianceHubView';
import { ExpansionVisionView } from './components/views/ExpansionVisionView';
import { AgencyCommandCenterView } from './components/views/AgencyCommandCenterView';
import { WhyHumanAIView } from './components/views/WhyHumanAIView';
import { WebhookManagementView } from './components/views/WebhookManagementView';
import { CompleteProtocolSchemeView } from './components/views/CompleteProtocolSchemeView';
import { Logo } from './components/ui/Logo';
import { FontSizeController } from './components/ui/FontSizeController';
import { CareerResourceGeneratorView } from './components/views/CareerResourceGeneratorView';
import { WhitePaperView } from './components/views/WhitePaperView';
import { MeshGatewayView } from './components/views/MeshGatewayView';
import BusinessHubView from './components/views/BusinessHubView';
import { StateDetailView } from './components/views/StateDetailView';
import { InstitutionalReportView } from './components/views/InstitutionalReportView';
import { VersioningPolicyView } from './components/views/VersioningPolicyView';
import { SuccessLedgerView } from './components/views/SuccessLedgerView';
import { PolicyPulseView } from './components/views/PolicyPulseView';
import StoreView from './components/views/StoreView';
import { ProviderIntegrityView } from './components/views/ProviderIntegrityView';
import { GovernanceNodeView } from './components/views/GovernanceNodeView';
import { GoogleDriveView } from './components/views/GoogleDriveView';

const LanguageContext = createContext<{
    lang: AppLanguage;
    setLang: (l: AppLanguage) => void;
}>({
    lang: AppLanguage.EN,
    setLang: () => {},
});

export const useTranslation = () => useContext(LanguageContext);

const RedirectingView: React.FC = () => {
    useEffect(() => { window.location.href = EXTERNAL_INTAKE_URL; }, []);
    return (
        <div className="flex flex-col justify-center items-center h-screen bg-slate-50">
            <Icon name="cog" className="w-10 h-10 text-slate-300 animate-spin mb-4" />
            <span className="text-sm font-medium text-slate-500">Connecting to secure intake node...</span>
        </div>
    );
};

const Header: React.FC<{
  pathname: string;
  navigate: (path: string) => void;
  currentUser: AuthenticatedUser | null;
  lang: AppLanguage;
  setLang: (l: AppLanguage) => void;
}> = ({ pathname, navigate, currentUser, lang, setLang }) => {
    const [isScrolled, setIsScrolled] = useState(false);
    useEffect(() => {
        const handleScroll = () => setIsScrolled(window.scrollY > 10);
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-200 border-b ${isScrolled ? 'bg-white/95 backdrop-blur-md border-slate-200 py-2 shadow-sm' : 'bg-white border-transparent py-4'}`}>
            <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-6">
                <div className="flex items-center gap-3 cursor-pointer shrink-0" onClick={() => navigate('/')}>
                    <Logo className="h-7 w-auto text-blue-600" />
                    <span className="font-bold text-slate-900 text-lg tracking-tight">VR4DEAF</span>
                </div>
                
                <div className="hidden xl:flex items-center gap-1 overflow-x-auto no-scrollbar py-1">
                    {PUBLIC_PAGES.map(role => {
                        const path = roleToPath(role);
                        const isActive = pathname === path || (path === '/' && pathname === '');
                        return (
                            <button
                                key={role}
                                onClick={() => navigate(path)}
                                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${isActive ? 'bg-slate-100 text-blue-600' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'}`}
                            >
                                {role}
                            </button>
                        );
                    })}
                </div>

                <div className="flex items-center gap-3 shrink-0">
                    <select 
                        value={lang} 
                        onChange={(e) => setLang(e.target.value as AppLanguage)}
                        className="text-xs font-bold text-slate-500 bg-slate-50 border border-slate-200 rounded-md px-2 py-1.5 focus:ring-1 focus:ring-blue-500 outline-none"
                    >
                        <option value={AppLanguage.EN}>EN</option>
                        <option value={AppLanguage.ES}>ES</option>
                        <option value={AppLanguage.ASL}>ASL</option>
                    </select>
                    {currentUser ? (
                         <button onClick={() => navigate(roleToPath(UserRole.MY_ACCOUNT))} className="px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-bold transition-all hover:bg-slate-800">
                             Dashboard
                         </button>
                    ) : (
                         <a href={EXTERNAL_INTAKE_URL} className="px-4 py-2 rounded-lg bg-blue-600 text-white text-xs font-bold transition-all hover:bg-blue-700 whitespace-nowrap">
                            Sign In
                         </a>
                    )}
                </div>
            </nav>
        </header>
    );
};

const AppContent: React.FC = () => {
    const { clients, isLoading } = useClients();
    const [currentUser, setCurrentUser] = useState<AuthenticatedUser | null>(null);
    const [toast, setToast] = useState({ message: '', show: false });
    const [pathname, setPathname] = useState(window.location.hash.substring(1) || '/');
    const [lang, setLang] = useState<AppLanguage>(AppLanguage.EN);
    const [activeResource, setActiveResource] = useState<{topic: string, title: string} | null>(null);

    useEffect(() => {
        const onHashChange = () => {
            setPathname(window.location.hash.substring(1) || '/');
            setActiveResource(null);
            window.scrollTo(0, 0);
        };
        window.addEventListener('hashchange', onHashChange);
        return () => window.removeEventListener('hashchange', onHashChange);
    }, []);

    useEffect(() => {
        const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
            if (session?.user) {
                const u = session.user;
                setCurrentUser({
                    uid: u.id, email: u.email || '', 
                    displayName: u.user_metadata.displayName || 'Professional Node',
                    primaryRole: u.user_metadata.primaryRole || UserRole.ENTREPRENEUR,
                    vendorRole: u.user_metadata.vendorRole,
                });
            } else { setCurrentUser(null); }
        });
        return () => subscription.unsubscribe();
    }, []);

    const navigate = (path: string) => { window.location.hash = path; };
    const showGlobalToast = (message: string) => setToast({ message, show: true });

    const renderView = () => {
        if (isLoading) return <div className="flex flex-col justify-center items-center h-96"><Icon name="cog" className="w-8 h-8 text-slate-200 animate-spin" /></div>;
        const currentRole = pathToRole(pathname);

        if (activeResource) {
            return (
                <div className="max-w-4xl mx-auto px-4 py-12">
                    <button onClick={() => setActiveResource(null)} className="mb-6 flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-slate-900 transition-colors">
                        <Icon name="back-arrow" className="w-4 h-4" /> Back to Resources
                    </button>
                    <CareerResourceGeneratorView topic={activeResource.topic} title={activeResource.title} onBack={() => setActiveResource(null)} showToast={showGlobalToast} />
                </div>
            );
        }

        const stateBase = roleToPath(UserRole.STATE_PROGRAMS);
        if (pathname.startsWith(stateBase + '/')) {
            const stateSlug = pathname.replace(stateBase + '/', '');
            const foundState = US_STATES.find(s => slugifyState(s) === stateSlug);
            if (foundState) return <StateDetailView stateName={foundState} onBack={() => navigate(stateBase)} />;
        }

        switch (currentRole) {
            case UserRole.VR_PARTNER: return <VRPartnerView showToast={showGlobalToast} />;
            case UserRole.VR_COUNSELOR: return <VRCounselorDashboardView showToast={showGlobalToast} />;
            case UserRole.ENTREPRENEUR: return currentUser ? <EntrepreneurView currentUser={currentUser} client={clients[0]} showToast={showGlobalToast} /> : <RedirectingView />;
            case UserRole.MY_ACCOUNT: return currentUser ? <MyAccountView user={currentUser} onLogout={() => supabase.auth.signOut()} showToast={showGlobalToast} /> : <RedirectingView />;
            case UserRole.SETTINGS: return currentUser ? <SettingsView /> : <RedirectingView />;
            case UserRole.THE_PROCESS: return <TheProcessView />;
            case UserRole.STATE_PROGRAMS: return <StateProgramsView showToast={showGlobalToast} navigate={navigate} />;
            case UserRole.STORE: return <StoreView navigate={navigate} />;
            case UserRole.AI_TOOLKITS: return <AIToolkitView navigate={navigate} />;
            case UserRole.ECOSYSTEM_DIRECTORY: return <EcosystemDirectoryView showToast={showGlobalToast} />;
            case UserRole.JOB_PLACEMENT: return <PlacementView showToast={showGlobalToast} onSelectResource={(topic, title) => setActiveResource({topic, title})} />;
            case UserRole.COMPLIANCE_HUB: return <ComplianceHubView />;
            case UserRole.COMMAND_CENTER: return <AgencyCommandCenterView />;
            case UserRole.API_DOCS: return <ApiDocsView />;
            case UserRole.PLATFORM_ARCHITECTURE: return <PlatformArchitectureView />;
            case UserRole.CHANGELOG: return <ChangelogView />;
            case UserRole.HOUSING: return <HousingView />;
            case UserRole.EMPLOYER_JOURNEY: return <EmployerView navigate={navigate} />;
            case UserRole.WHITE_PAPER: return <WhitePaperView />;
            case UserRole.SUCCESS_LEDGER: return <SuccessLedgerView />;
            case UserRole.POLICY_PULSE: return <PolicyPulseView />;
            case UserRole.BUSINESS_HUB: return <BusinessHubView navigate={navigate} />;
            case UserRole.VERSION_POLICY: return <VersioningPolicyView />;
            case UserRole.PROTOCOL_SCHEME: return <CompleteProtocolSchemeView />;
            case UserRole.FOUNDER_STORY: return <FounderStoryView isModal={false} onClose={() => {}} />;
            case UserRole.WHY_HUMAN_AI: return <WhyHumanAIView />;
            case UserRole.MESH_GATEWAY: return <MeshGatewayView showToast={showGlobalToast} />;
            case UserRole.AI_STORE_BLUEPRINT: return <AIStoreBlueprintView />;
            case UserRole.FINANCIAL_SYSTEM: return <FinancialFlowView />;
            case UserRole.EXPANSION_VISION: return <ExpansionVisionView />;
            case UserRole.BUSINESS_MAGICIAN: return <BusinessMagicianView />;
            case UserRole.VENDOR_JOURNEY: return <VendorJourneyView />;
            case UserRole.VR_COUNSELOR_JOURNEY: return <VRCounselorJourneyView />;
            case UserRole.DEVELOPER_JOURNEY: return <DeveloperJourneyView navigate={navigate} />;
            case UserRole.JOURNEYS: return <SitemapJourneysView navigate={navigate} />;
            case UserRole.ECOSYSTEM: return <EcosystemView />;
            case UserRole.PROVIDER_INTEGRITY: return <ProviderIntegrityView />;
            case UserRole.GOVERNANCE_NODE: return <GovernanceNodeView />;
            case UserRole.GOOGLE_DRIVE: return <GoogleDriveView showToast={showGlobalToast} />;
            case UserRole.HOME:
            default: return <HomepageView navigate={navigate} />;
        }
    };

    return (
        <LanguageContext.Provider value={{ lang, setLang }}>
            <div className="min-h-screen bg-white flex flex-col font-sans">
                <Header pathname={pathname} navigate={navigate} currentUser={currentUser} lang={lang} setLang={setLang} />
                <main className="flex-grow pt-20">
                    {renderView()}
                </main>
                <Footer navigate={navigate} />
                <FontSizeController />
                <Toast message={toast.message} show={toast.show} onClose={() => setToast({ ...toast, show: false })} />
            </div>
        </LanguageContext.Provider>
    );
};

const App: React.FC = () => (
    <ClientProvider>
        <AppContent />
    </ClientProvider>
);
export default App;
