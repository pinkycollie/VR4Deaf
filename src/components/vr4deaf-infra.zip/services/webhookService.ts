
import { VR4DeafEventType, WebhookSubscription, WebhookEventLog } from '../types';

let subscriptions: WebhookSubscription[] = [
    {
        id: 'sub-1',
        url: 'https://api.specialist-hub.io/webhooks',
        events: [VR4DeafEventType.VR_CASE_CREATED, VR4DeafEventType.VR_CASE_ASSIGNED],
        status: 'Active',
        lastPulse: new Date().toISOString(),
        secret: 'vr4_whsec_99182x'
    }
];

let eventLogs: WebhookEventLog[] = [];

const networkDelay = (ms: number) => new Promise(res => setTimeout(res, ms));

export const getSubscriptions = async (): Promise<WebhookSubscription[]> => {
    await networkDelay(300);
    return [...subscriptions];
};

export const addSubscription = async (url: string, events: VR4DeafEventType[]): Promise<WebhookSubscription> => {
    await networkDelay(800);
    const newSub: WebhookSubscription = {
        id: `sub-${Date.now()}`,
        url,
        events,
        status: 'Active',
        lastPulse: 'Never',
        secret: `vr4_whsec_${Math.random().toString(36).substring(7)}`
    };
    subscriptions.push(newSub);
    return newSub;
};

export const removeSubscription = async (id: string): Promise<void> => {
    await networkDelay(500);
    subscriptions = subscriptions.filter(s => s.id !== id);
};

export const simulateEvent = async (type: VR4DeafEventType): Promise<WebhookEventLog> => {
    await networkDelay(1000);
    
    let data: any = {
        case_id: "VR-9912",
        client_name: "Alex Rivera",
        agency: "TWC Texas Hub"
    };

    if (type === VR4DeafEventType.PROVIDER_REGISTERED) {
        data = {
            provider_id: `prov-${Math.random().toString(36).substring(7)}`,
            provider_name: "DeafLink Specialists LLC",
            specialty: "Vocational Coaching",
            registration_date: new Date().toISOString(),
            integrity_score: 1.0,
            compliance_status: "Verified"
        };
    }

    const newLog: WebhookEventLog = {
        id: `log-${Date.now()}`,
        type,
        timestamp: new Date().toISOString(),
        payload: {
            event: type,
            data: data
        },
        responseCode: 200
    };
    eventLogs = [newLog, ...eventLogs].slice(0, 50);
    
    // Update last pulse for relevant subs
    subscriptions = subscriptions.map(s => 
        s.events.includes(type) ? { ...s, lastPulse: newLog.timestamp } : s
    );
    
    return newLog;
};

export const getEventLogs = async (): Promise<WebhookEventLog[]> => {
    return [...eventLogs];
};
