import { createClient } from '@supabase/supabase-js';

// These should be loaded from environment variables in a real-world application.
// For this environment, we are using the known public values for the project.
const supabaseUrl = "https://hhgmgvhrmebkiscphirp.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhoZ21ndmhybWVia2lzY3BoaXJwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDY4MjY3ODUsImV4cCI6MjAyMjQwMjc4NX0.B0C4b5u_3132h2a5y372tT_yq0L2o0w_sXi_ouEc";

if (!supabaseUrl || !supabaseAnonKey) {
    console.error("Supabase URL and Anon Key are required.");
    // In a real app, you might want to throw an error or handle this state.
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Added a console log to confirm connection status on initialization.
console.info("Supabase client initialized successfully. Connection is active.");