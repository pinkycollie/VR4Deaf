
/**
 * @file services/apiService.ts
 * @description Primary interface between the React frontend and simulated backend/Gemini Engine.
 */
import { GoogleGenAI, Type } from "@google/genai";
import { UrlStatus, Client, Job, MilestoneStatus, UserRole, WeeklyBriefing, VuriAdvice, ComplianceMetric, AgencyTrack, AgencyOutcome, DigitalTwin, StateDetails, StateAnalytics } from '../types';
import { MOCK_CLIENTS, MOCK_JOBS, MOCK_MILESTONES_TEMPLATE } from '../constants';
import * as wasm from './wasmEngine';

let clientsDB: Client[] = [...MOCK_CLIENTS];

const networkDelay = (ms: number) => new Promise(res => setTimeout(res, ms));

const getAIClient = () => new GoogleGenAI({ apiKey: process.env.API_KEY as string });

const SYSTEM_INSTRUCTION = `
You are the VURI™ Master Protocol Node for Vocational Rehabilitation (VR).
MISSION: Data-driven professional success for Deaf clients.
CORE RULES: VR means employment services, not virtual reality.
No creative writing, no italics, no flowery language. Provide concise, professional documentation.
All calculations use Generative Units (GU). 1 GU = $2.50.
`;

export const getStateAnalytics = async (state: string): Promise<StateAnalytics> => {
    const ai = getAIClient();
    const schema = {
        type: Type.OBJECT,
        properties: {
            placementRate: { type: Type.NUMBER },
            engagementScore: { type: Type.NUMBER },
            avgVelocityDays: { type: Type.NUMBER },
            activeTranches: { type: Type.NUMBER },
            complianceRating: { type: Type.STRING }
        },
        required: ['placementRate', 'engagementScore', 'avgVelocityDays', 'activeTranches', 'complianceRating']
    };
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Synthesize realistic VR success analytics for ${state}. High integrity data only.`,
            config: { systemInstruction: SYSTEM_INSTRUCTION, responseMimeType: "application/json", responseSchema: schema }
        });
        return JSON.parse(response.text || '{}');
    } catch (e) {
        return { placementRate: 88, engagementScore: 92, avgVelocityDays: 42, activeTranches: 140, complianceRating: "Optimal" };
    }
};

export const getClients = async (): Promise<Client[]> => {
    await networkDelay(300);
    return JSON.parse(JSON.stringify(clientsDB));
};

export const addClient = async (clientData: Pick<Client, 'name' | 'email' | 'businessIdea'>): Promise<Client> => {
    await networkDelay(500);
    if (!wasm.verifySystemIdentity()) throw new Error("PROTOCOL_MISMATCH");
    const newClient: Client = {
        id: `client-${Date.now()}`,
        ...clientData,
        vrPartnerId: 'vr-1', specialistId: 'bs-1', intakeDate: new Date().toISOString().split('T')[0],
        milestones: MOCK_MILESTONES_TEMPLATE.map((m, i) => ({ ...m, id: `m-${Date.now()}-${i}`, status: MilestoneStatus.PENDING })),
        monitoredUrls: [],
    };
    clientsDB = [newClient, ...clientsDB];
    return newClient;
};

export const updateClient = async (updatedClient: Client): Promise<Client> => {
    clientsDB = clientsDB.map(c => c.id === updatedClient.id ? updatedClient : c);
    return updatedClient;
};

export const getLatestPolicyNews = async (): Promise<{ text: string, links: { uri: string, title: string }[] }> => {
    const ai = getAIClient();
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: 'Current federal Vocational Rehabilitation (VR) policy updates, 2024 funding tranches, and Deaf workforce initiatives. Provide three specific news points.',
            config: { tools: [{ googleSearch: {} }] },
        });
        const links: { uri: string, title: string }[] = [];
        response.candidates?.[0]?.groundingMetadata?.groundingChunks?.forEach((c: any) => {
            if (c.web) links.push({ uri: c.web.uri, title: c.web.title });
        });
        return { text: response.text || "Data unavailable.", links };
    } catch (e) { return { text: "Search node timeout.", links: [] }; }
};

export const findNearbyOffices = async (state: string, lat?: number, lng?: number): Promise<any[]> => {
    const ai = getAIClient();
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Official Vocational Rehabilitation offices in ${state}. Use grounding for exact addresses.`,
            config: {
                tools: [{ googleMaps: {} }],
                toolConfig: { retrievalConfig: { latLng: lat && lng ? { latitude: lat, longitude: lng } : undefined } }
            }
        });
        return response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    } catch (e) { return []; }
};

export const generateInstitutionalReport = async (client: Client): Promise<{ reportBody: string; metadata: any }> => {
    const ai = getAIClient();
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: `Institutional analysis for ${client.name}. Strategy: ${client.businessIdea}. Adhere to RSA-911 standards.`,
            config: { systemInstruction: SYSTEM_INSTRUCTION, temperature: 0.1 }
        });
        const calc = wasm.calculateGUAllocation(client.milestones.length);
        return {
            reportBody: response.text || "Report error.",
            metadata: {
                reportId: `ART-${Math.random().toString(36).substring(7).toUpperCase()}`,
                integrityHash: calc.integrityHash,
                timestamp: calc.timestamp,
                wasmVersion: calc.version
            }
        };
    } catch (e) { return { reportBody: "Synthesis node failure.", metadata: {} }; }
};

export const getLedgerEntries = async (): Promise<any[]> => {
    await networkDelay(300);
    return [
        { id: 'TX-9912-A', type: 'GU_ALLOCATION', units: 4200, hash: 'sha256:82f...911', status: 'verified', timestamp: new Date().toISOString() },
        { id: 'TX-9912-B', type: 'MILESTONE_IPE', units: 0, hash: 'sha256:d3a...f21', status: 'signed', timestamp: new Date(Date.now() - 86400000).toISOString() },
    ];
};

export const generateDigitalTwin = async (client: Client): Promise<DigitalTwin> => {
    const ai = getAIClient();
    const schema = {
        type: Type.OBJECT,
        properties: {
            persona: { type: Type.STRING },
            tone: { type: Type.STRING },
            trajectorySummary: { type: Type.STRING },
            predictedObstacles: { type: Type.ARRAY, items: { type: Type.STRING } },
            recommendedModality: { type: Type.STRING }
        },
        required: ['persona', 'tone', 'trajectorySummary', 'predictedObstacles', 'recommendedModality']
    };
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Profile for ${client.name}: ${client.businessIdea}. Standard professional tone.`,
            config: { systemInstruction: SYSTEM_INSTRUCTION, responseMimeType: "application/json", responseSchema: schema }
        });
        return JSON.parse(response.text || '{}');
    } catch (e) {
        return { persona: "Founder Node", tone: "Professional", trajectorySummary: "Analysis unavailable.", predictedObstacles: [], recommendedModality: "Standard" };
    }
};

export const getComplianceMetrics = async (): Promise<ComplianceMetric[]> => {
    await networkDelay(500);
    return [
        { label: 'RSA-911 Data Integrity', value: '98.4%', status: 'optimal', description: 'Reporting sync accuracy.' },
        { label: 'GU Utilization', value: '72%', status: 'warning', description: 'Budgeted tranches vs outcomes.' },
    ];
};

export const predictAgencyOutcome = async (track: AgencyTrack, resources: number): Promise<AgencyOutcome> => {
    const ai = getAIClient();
    const schema = {
        type: Type.OBJECT,
        properties: {
            projectedSuccess: { type: Type.STRING },
            riskLevel: { type: Type.STRING, enum: ['Low', 'Medium', 'High'] },
            bottlenecks: { type: Type.ARRAY, items: { type: Type.STRING } },
            recommendations: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ['projectedSuccess', 'riskLevel', 'bottlenecks', 'recommendations']
    };
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: `Predict outcome for track: ${track} at ${resources}% resources.`,
            config: { systemInstruction: SYSTEM_INSTRUCTION, responseMimeType: "application/json", responseSchema: schema }
        });
        return JSON.parse(response.text || '{}');
    } catch (e) {
        return { projectedSuccess: "Unknown", riskLevel: "Medium", bottlenecks: [], recommendations: [] };
    }
};

export const analyzeAslVideoIntake = async (): Promise<{ name: string; email: string; businessIdea: string; }> => {
    const ai = getAIClient();
    const schema = {
        type: Type.OBJECT,
        properties: { name: { type: Type.STRING }, email: { type: Type.STRING }, businessIdea: { type: Type.STRING } },
        required: ['name', 'email', 'businessIdea']
    };
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: "Extract professional identity from visual modality. High precision required.",
            config: { systemInstruction: SYSTEM_INSTRUCTION, responseMimeType: "application/json", responseSchema: schema }
        });
        return JSON.parse(response.text || '{}');
    } catch (e) { return { name: "Identity Node", email: "identity@node.org", businessIdea: "Professional trajectory." }; }
};

export const analyzeAslGlossIntake = async (gloss: string): Promise<{ name: string; email: string; businessIdea: string; }> => {
    const ai = getAIClient();
    const schema = {
        type: Type.OBJECT,
        properties: { name: { type: Type.STRING }, email: { type: Type.STRING }, businessIdea: { type: Type.STRING } },
        required: ['name', 'email', 'businessIdea']
    };
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Standardize this ASL gloss: ${gloss}. Map to demographics.`,
            config: { systemInstruction: SYSTEM_INSTRUCTION, responseMimeType: "application/json", responseSchema: schema }
        });
        return JSON.parse(response.text || '{}');
    } catch (e) { return { name: "Identity Node", email: "identity@node.org", businessIdea: "Professional trajectory." }; }
};

export const generateWeeklyBriefing = async (role: UserRole, clients: Client[]): Promise<WeeklyBriefing> => {
    const ai = getAIClient();
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Summarize caseload for ${role} with ${clients.length} nodes. List priorities.`,
            config: {
                systemInstruction: SYSTEM_INSTRUCTION,
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        highlights: { type: Type.ARRAY, items: { type: Type.STRING } },
                        suggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
                        attentionItems: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { clientName: { type: Type.STRING }, reason: { type: Type.STRING } } } }
                    },
                    required: ['highlights', 'suggestions', 'attentionItems']
                }
            }
        });
        return JSON.parse(response.text || '{"highlights":[], "suggestions":[], "attentionItems":[]}');
    } catch (e) { return { highlights: [" Caseload synchronized."], suggestions: [], attentionItems: [] }; }
};

export const generateContextualAdvice = async (view: string, data: any): Promise<VuriAdvice> => {
    const ai = getAIClient();
    const schema = {
        type: Type.OBJECT,
        properties: {
            summary: { type: Type.STRING },
            actions: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { label: { type: Type.STRING }, priority: { type: Type.STRING, enum: ['low', 'medium', 'high'] } } } },
            insight: { type: Type.STRING }
        },
        required: ['summary', 'actions', 'insight']
    };
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `View: ${view}. Context: ${JSON.stringify(data)}. Provide professional advisory.`,
            config: { systemInstruction: SYSTEM_INSTRUCTION, responseMimeType: "application/json", responseSchema: schema }
        });
        return JSON.parse(response.text || '{}');
    } catch (e) { return { summary: "System active.", actions: [], insight: "Ready." }; }
};

export const getJobs = async (): Promise<Job[]> => {
    const ai = getAIClient();
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: 'Retrieve 6 current job openings for Deaf professionals in remote tech or specialized admin. Professional CIE standards only.',
            config: {
                systemInstruction: SYSTEM_INSTRUCTION,
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        jobs: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { id: { type: Type.STRING }, title: { type: Type.STRING }, company: { type: Type.STRING }, location: { type: Type.STRING }, type: { type: Type.STRING }, description: { type: Type.STRING }, url: { type: Type.STRING } } } }
                    }
                }
            }
        });
        return JSON.parse(response.text || '{"jobs":[]}').jobs;
    } catch (e) { return MOCK_JOBS; }
};

export const generateBusinessIdea = async (keywords: string): Promise<string> => {
    const ai = getAIClient();
    const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Professional venture concept from: ${keywords}. 2 sentences max.`,
        config: { systemInstruction: SYSTEM_INSTRUCTION, maxOutputTokens: 100 }
    });
    return response.text?.trim() || "Concept verified.";
};

export const checkUrlStatus = async (url: string): Promise<UrlStatus> => {
    await networkDelay(1000);
    return Math.random() > 0.1 ? UrlStatus.ONLINE : UrlStatus.OFFLINE;
};

export const applyForJob = async (id: string): Promise<void> => { await networkDelay(500); return; };

export const generateCareerResource = async (topic: string, title: string): Promise<string> => {
    const ai = getAIClient();
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Professional documentation: ${topic} - ${title}. Objective: Workforce readiness.`,
            config: { systemInstruction: SYSTEM_INSTRUCTION }
        });
        return response.text || "Documentation unavailable.";
    } catch (e) { return "Node timeout."; }
};

export const submitFeedback = async (topic: string, title: string, rating: 'good' | 'bad', comment: string): Promise<{ success: boolean; analysis?: string }> => {
    const ai = getAIClient();
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Analyze feedback: "${comment}". Impact on ${title}.`,
            config: { systemInstruction: SYSTEM_INSTRUCTION, maxOutputTokens: 50 }
        });
        return { success: true, analysis: response.text?.trim() };
    } catch (e) { return { success: true }; }
};

export const getStateDetails = async (state: string): Promise<StateDetails> => {
    const ai = getAIClient();
    const schema = {
        type: Type.OBJECT,
        properties: {
            programName: { type: Type.STRING },
            description: { type: Type.STRING },
            contactInfo: { type: Type.OBJECT, properties: { phone: { type: Type.STRING }, email: { type: Type.STRING }, website: { type: Type.STRING }, officeAddress: { type: Type.STRING } }, required: ['phone', 'email', 'website', 'officeAddress'] },
            successStories: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { title: { type: Type.STRING }, story: { type: Type.STRING }, outcome: { type: Type.STRING } } } }
        },
        required: ['programName', 'description', 'contactInfo', 'successStories']
    };
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Institutional program details for ${state} Vocational Rehabilitation.`,
            config: { systemInstruction: SYSTEM_INSTRUCTION, responseMimeType: "application/json", responseSchema: schema }
        });
        return JSON.parse(response.text || '{}');
    } catch (e) {
        return { programName: `${state} VR Services`, description: "Institutional support.", contactInfo: { phone: "(555) 012-3456", email: "info@vr.gov", website: "https://vr.gov", officeAddress: "123 Gov St" }, successStories: [] };
    }
};
